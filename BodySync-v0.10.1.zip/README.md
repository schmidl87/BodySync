# Body Sync 0.10.0

## Änderungen
- Startseite: Tagesform und Vitalwerte kompakt nebeneinander.
- Tagesform wird auf Startseite und Analyse aus derselben zentralen Berechnung angezeigt.
- Vitalwerte als horizontale, kompakte Karten mit persönlicher Basislinie, wenn genügend Verlauf vorhanden ist.
- Schlaf in Stunden und Minuten statt Minutenanzeige.
- HRV und SpO₂ werden über einen längeren Health-Connect-Zeitraum gesucht.
- Gewicht-Detailseite erweitert um BMI, FFMI, Fettmasse, FMI, Körperfett, Magermasse, Körperwasser und Knochenmasse, soweit echte Health-Connect-Daten vorhanden sind.
- Keine erfundenen Körperwerte: fehlende Daten bleiben „—“.
- BMI bleibt als klassischer Größen-/Gewichtsindex sichtbar. FFMI/FMI sind zusätzliche Körperkompositionskennzahlen.
- Neues transparentes diagonales DNA-/Datenstrang-App-Icon.
- Package ID bleibt com.bodysync.app, damit Updates über bestehende Installationen möglich bleiben.


## 0.10.1 – Health Connect Quota Fix
- Entfernt den automatischen 365-Tage-Import bei jedem App-Start/Resume.
- Tägliche Aggregationen werden in einer gemeinsamen Health-Connect-Anfrage gelesen.
- Workout-Detaildaten werden pro Datentyp gesammelt statt pro Workout einzeln abgefragt.
- Hintergrund-Synchronisierung auf 30 Minuten gesetzt und bestehende 15-Minuten-Arbeit ersetzt.
- Refresh beim App-Start/Resume wird gegen doppelte unmittelbare Requests gedrosselt.
- Health-Connect-Quota-Fehler führen nicht mehr zu einer rohen Exception auf der Startseite.
- Bestehende lokale Historie bleibt erhalten.
