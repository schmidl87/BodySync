package com.bodysync.app

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.*
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import kotlin.math.roundToInt

private data class MetricAccumulator(
    var count: Int = 0,
    var sum: Double = 0.0,
) {
    fun add(value: Double) { count++; sum += value }
    fun avg(): Double? = if (count == 0) null else sum / count
}

data class SleepBreakdown(
    val start: Instant,
    val end: Instant,
    val totalMinutes: Long,
    val deepMinutes: Long,
    val lightMinutes: Long,
    val remMinutes: Long,
    val awakeMinutes: Long,
    val source: String
)

data class WorkoutSummary(
    val type: String,
    val start: Instant,
    val end: Instant,
    val durationMinutes: Long,
    val distanceKm: Double? = null,
    val avgSpeedKmh: Double? = null,
    val maxSpeedKmh: Double? = null,
    val avgPowerW: Double? = null,
    val maxPowerW: Double? = null,
    val elevationM: Double? = null,
    val calories: Double? = null,
    val avgHeartRate: Int? = null,
    val maxHeartRate: Int? = null,
    val source: String = "",
    val avgCadenceRpm: Double? = null,
    val maxCadenceRpm: Double? = null
)

data class HealthSnapshot(
    val steps: Long? = null,
    val heartRateAvg: Int? = null,
    val restingHeartRate: Int? = null,
    val hrvMs: Double? = null,
    val respiratoryRate: Double? = null,
    val activeCalories: Int? = null,
    val totalCalories: Int? = null,
    val restingCalories: Int? = null,
    val activeCaloriesIsRecentFallback: Boolean = false,
    val respiratoryRateIsRecentFallback: Boolean = false,
    val oxygenIsRecentFallback: Boolean = false,
    val vo2IsRecentFallback: Boolean = false,
    val sleep: SleepBreakdown? = null,
    val weightKg: Double? = null,
    val bodyFatPercent: Double? = null,
    val leanBodyMassKg: Double? = null,
    val bodyWaterKg: Double? = null,
    val boneMassKg: Double? = null,
    val heightCm: Double? = null,
    val oxygenPercent: Double? = null,
    val vo2Max: Double? = null,
    val distanceKm: Double? = null,
    val skinTemperatureDelta: Double? = null,
    val workouts: Int = 0,
    val sources: Int = 0,
    val lastSync: Instant? = null,
    val workoutList: List<WorkoutSummary> = emptyList()
)

class HealthConnectManager private constructor(private val client: HealthConnectClient, private val appContext: Context) {
    companion object {
        const val PROVIDER_PACKAGE = "com.google.android.apps.healthdata"
        fun availability(context: Context): Int = HealthConnectClient.getSdkStatus(context, PROVIDER_PACKAGE)
        fun create(context: Context): HealthConnectManager = HealthConnectManager(HealthConnectClient.getOrCreate(context), context.applicationContext)
    }

    internal fun contextForHistory(): Context = appContext

    val permissions: Set<String> = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(RestingHeartRateRecord::class),
        HealthPermission.getReadPermission(HeartRateVariabilityRmssdRecord::class),
        HealthPermission.getReadPermission(RespiratoryRateRecord::class),
        HealthPermission.getReadPermission(OxygenSaturationRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class),
        HealthPermission.getReadPermission(ExerciseSessionRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getReadPermission(SpeedRecord::class),
        HealthPermission.getReadPermission(PowerRecord::class),
        HealthPermission.getReadPermission(ElevationGainedRecord::class),
        HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(TotalCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(BasalMetabolicRateRecord::class),
        HealthPermission.getReadPermission(WeightRecord::class),
        HealthPermission.getReadPermission(BodyFatRecord::class),
        HealthPermission.getReadPermission(LeanBodyMassRecord::class),
        HealthPermission.getReadPermission(BodyWaterMassRecord::class),
        HealthPermission.getReadPermission(BoneMassRecord::class),
        HealthPermission.getReadPermission(HeightRecord::class),
        HealthPermission.getReadPermission(Vo2MaxRecord::class),
        HealthPermission.getReadPermission(StepsCadenceRecord::class),
        HealthPermission.getReadPermission(CyclingPedalingCadenceRecord::class),
        HealthPermission.getReadPermission(FloorsClimbedRecord::class),
        HealthPermission.getReadPermission(SkinTemperatureRecord::class),
        "android.permission.health.READ_HEALTH_DATA_HISTORY"
    )

    suspend fun grantedPermissions(): Set<String> = client.permissionController.getGrantedPermissions()

    suspend fun readSnapshot(): HealthSnapshot {
        val now = Instant.now()
        val zone = ZoneId.systemDefault()
        val todayStart = now.atZone(zone).toLocalDate().atStartOfDay(zone).toInstant()
        val dayRange = TimeRangeFilter.between(todayStart, now)
        val historyStart = now.minusSeconds(30L * 24L * 60L * 60L)
        val historyRange = TimeRangeFilter.between(historyStart, now)
        val origins = mutableSetOf<String>()

        fun origin(record: Record) { origins += record.metadata.dataOrigin.packageName }

        var steps = 0L
        var activeKcalToday = 0.0
        var totalKcalToday = 0.0
        var restingKcalToday = 0.0
        var distanceKm = 0.0
        var bmrWatts: Double? = null
        val hr = MetricAccumulator()
        val hrv = MetricAccumulator()
        var latestHrv: HeartRateVariabilityRmssdRecord? = null
        val resp = MetricAccumulator()
        var latestRespiratory: RespiratoryRateRecord? = null
        val spo2 = MetricAccumulator()
        var latestSpo2: OxygenSaturationRecord? = null
        var latestVo2: Vo2MaxRecord? = null
        val resting = MetricAccumulator()

        // Combine all daily aggregate metrics into one Health Connect request.
        // This materially reduces API quota usage compared with one request per metric.
        val dailyAggregate = client.aggregate(
            AggregateRequest(
                setOf(
                    StepsRecord.COUNT_TOTAL,
                    DistanceRecord.DISTANCE_TOTAL,
                    HeartRateRecord.BPM_AVG,
                    ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL,
                    TotalCaloriesBurnedRecord.ENERGY_TOTAL,
                    BasalMetabolicRateRecord.BASAL_CALORIES_TOTAL
                ),
                dayRange
            )
        )
        steps = dailyAggregate[StepsRecord.COUNT_TOTAL] ?: 0L
        dailyAggregate[HeartRateRecord.BPM_AVG]?.let { hr.add(it.toDouble()) }
        distanceKm = dailyAggregate[DistanceRecord.DISTANCE_TOTAL]?.inKilometers ?: 0.0
        activeKcalToday = dailyAggregate[ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL]?.inKilocalories ?: 0.0
        totalKcalToday = dailyAggregate[TotalCaloriesBurnedRecord.ENERGY_TOTAL]?.inKilocalories ?: 0.0
        restingKcalToday = dailyAggregate[BasalMetabolicRateRecord.BASAL_CALORIES_TOTAL]?.inKilocalories ?: 0.0
        client.readRecords(ReadRecordsRequest(RestingHeartRateRecord::class, dayRange)).records.forEach { r -> origin(r); resting.add(r.beatsPerMinute.toDouble()) }
        val hrvRange = TimeRangeFilter.between(now.minusSeconds(30L * 24L * 60L * 60L), now)
        client.readRecords(ReadRecordsRequest(HeartRateVariabilityRmssdRecord::class, hrvRange)).records.forEach { r ->
            origin(r)
            hrv.add(r.heartRateVariabilityMillis)
            if (latestHrv == null || r.time.isAfter(latestHrv!!.time)) latestHrv = r
        }
        val respiratoryRange = TimeRangeFilter.between(now.minusSeconds(7L * 24L * 60L * 60L), now)
        client.readRecords(ReadRecordsRequest(RespiratoryRateRecord::class, respiratoryRange)).records.forEach { r ->
            origin(r)
            resp.add(r.rate)
            if (latestRespiratory == null || r.time.isAfter(latestRespiratory!!.time)) latestRespiratory = r
        }
        val oxygenRange = TimeRangeFilter.between(now.minusSeconds(30L * 24L * 60L * 60L), now)
        client.readRecords(ReadRecordsRequest(OxygenSaturationRecord::class, oxygenRange)).records.forEach { r ->
            origin(r)
            spo2.add(r.percentage.value)
            if (latestSpo2 == null || r.time.isAfter(latestSpo2!!.time)) latestSpo2 = r
        }
        var skinTemperatureDelta: Double? = null
        runCatching {
            val skinRange = TimeRangeFilter.between(now.minusSeconds(36L * 60L * 60L), now)
            val skinAggregate = client.aggregate(AggregateRequest(setOf(SkinTemperatureRecord.TEMPERATURE_DELTA_AVG), skinRange))
            skinTemperatureDelta = skinAggregate[SkinTemperatureRecord.TEMPERATURE_DELTA_AVG]?.inCelsius
            client.readRecords(ReadRecordsRequest(SkinTemperatureRecord::class, skinRange)).records.forEach { origin(it) }
        }
        client.readRecords(ReadRecordsRequest(BasalMetabolicRateRecord::class, historyRange)).records.forEach { r -> origin(r); if (bmrWatts == null || r.time.isAfter(now.minusSeconds(30L * 24L * 60L * 60L))) bmrWatts = r.basalMetabolicRate.inWatts }

        val sleeps = client.readRecords(ReadRecordsRequest(SleepSessionRecord::class, TimeRangeFilter.between(now.minusSeconds(48L * 60L * 60L), now))).records
        sleeps.forEach { origin(it) }
        val latestSleep = sleeps.filter { it.endTime.isAfter(now.minusSeconds(36L * 60L * 60L)) }.maxByOrNull { it.endTime }
        val sleep = latestSleep?.let { session ->
            var deep = 0L; var light = 0L; var rem = 0L; var awake = 0L; var sleeping = 0L
            session.stages.forEach { stage ->
                val minutes = Duration.between(stage.startTime, stage.endTime).toMinutes().coerceAtLeast(0)
                when (stage.stage) {
                    SleepSessionRecord.STAGE_TYPE_DEEP -> deep += minutes
                    SleepSessionRecord.STAGE_TYPE_LIGHT -> light += minutes
                    SleepSessionRecord.STAGE_TYPE_REM -> rem += minutes
                    SleepSessionRecord.STAGE_TYPE_AWAKE,
                    SleepSessionRecord.STAGE_TYPE_AWAKE_IN_BED,
                    SleepSessionRecord.STAGE_TYPE_OUT_OF_BED -> awake += minutes
                    SleepSessionRecord.STAGE_TYPE_SLEEPING -> sleeping += minutes
                }
            }
            val total = (deep + light + rem + sleeping).takeIf { it > 0 } ?: Duration.between(session.startTime, session.endTime).toMinutes().coerceAtLeast(0)
            SleepBreakdown(session.startTime, session.endTime, total, deep, light, rem, awake, session.metadata.dataOrigin.packageName)
        }

        var latestWeight: WeightRecord? = null
        var latestBodyFat: BodyFatRecord? = null
        var latestLeanMass: LeanBodyMassRecord? = null
        var latestWaterMass: BodyWaterMassRecord? = null
        var latestBoneMass: BoneMassRecord? = null
        var latestHeight: HeightRecord? = null
        client.readRecords(ReadRecordsRequest(WeightRecord::class, historyRange)).records.forEach { r -> origin(r); if (latestWeight == null || r.time.isAfter(latestWeight!!.time)) latestWeight = r }
        client.readRecords(ReadRecordsRequest(BodyFatRecord::class, historyRange)).records.forEach { r -> origin(r); if (latestBodyFat == null || r.time.isAfter(latestBodyFat!!.time)) latestBodyFat = r }
        client.readRecords(ReadRecordsRequest(LeanBodyMassRecord::class, historyRange)).records.forEach { r -> origin(r); if (latestLeanMass == null || r.time.isAfter(latestLeanMass!!.time)) latestLeanMass = r }
        client.readRecords(ReadRecordsRequest(BodyWaterMassRecord::class, historyRange)).records.forEach { r -> origin(r); if (latestWaterMass == null || r.time.isAfter(latestWaterMass!!.time)) latestWaterMass = r }
        client.readRecords(ReadRecordsRequest(BoneMassRecord::class, historyRange)).records.forEach { r -> origin(r); if (latestBoneMass == null || r.time.isAfter(latestBoneMass!!.time)) latestBoneMass = r }
        client.readRecords(ReadRecordsRequest(HeightRecord::class, historyRange)).records.forEach { r -> origin(r); if (latestHeight == null || r.time.isAfter(latestHeight!!.time)) latestHeight = r }
        client.readRecords(ReadRecordsRequest(Vo2MaxRecord::class, historyRange)).records.forEach { r -> origin(r); if (latestVo2 == null || r.time.isAfter(latestVo2!!.time)) latestVo2 = r }

        val workouts = client.readRecords(ReadRecordsRequest(ExerciseSessionRecord::class, historyRange)).records.sortedByDescending { it.startTime }
        workouts.forEach { origin(it) }
        // Load workout detail records in bulk. Reading every metric separately for every workout
        // caused hundreds of Health Connect calls and could exhaust the API quota.
        val workoutSummaries = readWorkoutSummaries(workouts.take(50), historyRange, ::origin)

        // Daily energy is strictly bounded to the current calendar day.
        // Never carry calories from a previous day into today's dashboard.
        val activeBase = activeKcalToday.takeIf { it > 0.0 }
        val totalCaloriesValue = totalKcalToday.takeIf { it > 0.0 }
        val restingCaloriesValue = restingKcalToday.takeIf { it > 0.0 }
            ?: if (totalCaloriesValue != null && activeBase != null) (totalCaloriesValue - activeBase).coerceAtLeast(0.0) else null
        val finalTotalCalories = totalCaloriesValue
            ?: if (activeBase != null && restingCaloriesValue != null) activeBase + restingCaloriesValue else null
        val activeCaloriesValue = activeBase
            ?: if (finalTotalCalories != null && restingCaloriesValue != null) (finalTotalCalories - restingCaloriesValue).coerceAtLeast(0.0) else null
        val respiratoryValue = latestRespiratory?.rate ?: resp.avg()
        val respiratoryFallback = latestRespiratory?.time?.let { it.isBefore(todayStart) } ?: false

        return HealthSnapshot(
            steps = steps.takeIf { it > 0 },
            heartRateAvg = hr.avg()?.roundToInt(),
            restingHeartRate = resting.avg()?.roundToInt(),
            hrvMs = latestHrv?.heartRateVariabilityMillis ?: hrv.avg(),
            respiratoryRate = respiratoryValue,
            activeCalories = activeCaloriesValue?.roundToInt(),
            totalCalories = finalTotalCalories?.roundToInt(),
            restingCalories = restingCaloriesValue?.roundToInt(),
            activeCaloriesIsRecentFallback = false,
            respiratoryRateIsRecentFallback = respiratoryFallback,
            oxygenIsRecentFallback = latestSpo2?.time?.let { it.isBefore(todayStart) } ?: false,
            vo2IsRecentFallback = latestVo2?.time?.let { it.isBefore(todayStart) } ?: false,
            sleep = sleep,
            weightKg = latestWeight?.weight?.inKilograms,
            bodyFatPercent = latestBodyFat?.percentage?.value,
            leanBodyMassKg = latestLeanMass?.mass?.inKilograms,
            bodyWaterKg = latestWaterMass?.mass?.inKilograms,
            boneMassKg = latestBoneMass?.mass?.inKilograms,
            heightCm = latestHeight?.height?.inMeters?.times(100.0),
            oxygenPercent = latestSpo2?.percentage?.value ?: spo2.avg(),
            vo2Max = latestVo2?.vo2MillilitersPerMinuteKilogram,
            distanceKm = distanceKm.takeIf { it > 0 },
            skinTemperatureDelta = skinTemperatureDelta,
            workouts = workouts.size,
            sources = origins.size,
            lastSync = now,
            workoutList = workoutSummaries
        )
    }

    suspend fun importHistory(days: Long = 365L) {
        val now = Instant.now()
        val zone = ZoneId.systemDefault()
        val startDate = now.atZone(zone).toLocalDate().minusDays(days - 1)
        val db = BodySyncDatabase(appContext)
        try {
            var date = startDate
            val today = now.atZone(zone).toLocalDate()
            while (!date.isAfter(today)) {
                val start = date.atStartOfDay(zone).toInstant()
                val end = if (date == today) now else date.plusDays(1).atStartOfDay(zone).toInstant()
                val range = TimeRangeFilter.between(start, end)
                runCatching {
                    val steps = client.aggregate(AggregateRequest(setOf(StepsRecord.COUNT_TOTAL), range))[StepsRecord.COUNT_TOTAL]
                    val distance = client.aggregate(AggregateRequest(setOf(DistanceRecord.DISTANCE_TOTAL), range))[DistanceRecord.DISTANCE_TOTAL]?.inKilometers
                    val totalCal = client.aggregate(AggregateRequest(setOf(TotalCaloriesBurnedRecord.ENERGY_TOTAL), range))[TotalCaloriesBurnedRecord.ENERGY_TOTAL]?.inKilocalories
                    val activeCal = client.aggregate(AggregateRequest(setOf(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL), range))[ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL]?.inKilocalories
                    val restingCal = client.aggregate(AggregateRequest(setOf(BasalMetabolicRateRecord.BASAL_CALORIES_TOTAL), range))[BasalMetabolicRateRecord.BASAL_CALORIES_TOTAL]?.inKilocalories
                    val hrAvg = client.aggregate(AggregateRequest(setOf(HeartRateRecord.BPM_AVG), range))[HeartRateRecord.BPM_AVG]
                    val rhr = client.readRecords(ReadRecordsRequest(RestingHeartRateRecord::class, range)).records.maxByOrNull { it.time }
                    val hrv = client.readRecords(ReadRecordsRequest(HeartRateVariabilityRmssdRecord::class, range)).records.maxByOrNull { it.time }
                    val resp = client.readRecords(ReadRecordsRequest(RespiratoryRateRecord::class, range)).records.maxByOrNull { it.time }
                    val spo2 = client.readRecords(ReadRecordsRequest(OxygenSaturationRecord::class, range)).records.maxByOrNull { it.time }
                    val vo2 = client.readRecords(ReadRecordsRequest(Vo2MaxRecord::class, range)).records.maxByOrNull { it.time }
                    val skin = runCatching {
                        client.aggregate(AggregateRequest(setOf(SkinTemperatureRecord.TEMPERATURE_DELTA_AVG), range))[SkinTemperatureRecord.TEMPERATURE_DELTA_AVG]?.inCelsius
                    }.getOrNull()
                    val sleepSessions = client.readRecords(ReadRecordsRequest(SleepSessionRecord::class, TimeRangeFilter.between(start.minusSeconds(18*3600), end))).records
                    val sleep = sleepSessions.filter { it.endTime.isAfter(start) && it.startTime.isBefore(end) }.maxByOrNull { it.endTime }?.let { session ->
                        val deep = session.stages.filter { it.stage == SleepSessionRecord.STAGE_TYPE_DEEP }.sumOf { Duration.between(it.startTime, it.endTime).toMinutes() }
                        val light = session.stages.filter { it.stage == SleepSessionRecord.STAGE_TYPE_LIGHT }.sumOf { Duration.between(it.startTime, it.endTime).toMinutes() }
                        val rem = session.stages.filter { it.stage == SleepSessionRecord.STAGE_TYPE_REM }.sumOf { Duration.between(it.startTime, it.endTime).toMinutes() }
                        val awake = session.stages.filter { it.stage == SleepSessionRecord.STAGE_TYPE_AWAKE || it.stage == SleepSessionRecord.STAGE_TYPE_AWAKE_IN_BED || it.stage == SleepSessionRecord.STAGE_TYPE_OUT_OF_BED }.sumOf { Duration.between(it.startTime, it.endTime).toMinutes() }
                        val total = (deep + light + rem).takeIf { it > 0 } ?: Duration.between(session.startTime, session.endTime).toMinutes().coerceAtLeast(0)
                        SleepBreakdown(session.startTime, session.endTime, total, deep, light, rem, awake, session.metadata.dataOrigin.packageName)
                    }
                    val workoutCount = client.readRecords(ReadRecordsRequest(ExerciseSessionRecord::class, range)).records.size
                    val snapshot = HealthSnapshot(
                        steps = steps?.takeIf { it > 0 },
                        heartRateAvg = hrAvg?.toDouble()?.roundToInt(),
                        restingHeartRate = rhr?.beatsPerMinute?.toDouble()?.roundToInt(),
                        hrvMs = hrv?.heartRateVariabilityMillis,
                        respiratoryRate = resp?.rate,
                        activeCalories = activeCal?.toDouble()?.roundToInt(),
                        totalCalories = totalCal?.toDouble()?.roundToInt(),
                        restingCalories = restingCal?.toDouble()?.roundToInt(),
                        sleep = sleep,
                        oxygenPercent = spo2?.percentage?.value,
                        vo2Max = vo2?.vo2MillilitersPerMinuteKilogram,
                        distanceKm = distance?.takeIf { it > 0 },
                        skinTemperatureDelta = skin,
                        workouts = workoutCount,
                        lastSync = end
                    )
                    db.saveSnapshot(snapshot)
                }
                date = date.plusDays(1)
            }
        } finally { db.close() }
    }

    private suspend fun readWorkoutSummaries(
        sessions: List<ExerciseSessionRecord>,
        range: TimeRangeFilter,
        origin: (Record) -> Unit
    ): List<WorkoutSummary> {
        if (sessions.isEmpty()) return emptyList()

        val distances = client.readRecords(ReadRecordsRequest(DistanceRecord::class, range)).records
        val speeds = client.readRecords(ReadRecordsRequest(SpeedRecord::class, range)).records
        val powers = client.readRecords(ReadRecordsRequest(PowerRecord::class, range)).records
        val elevations = client.readRecords(ReadRecordsRequest(ElevationGainedRecord::class, range)).records
        val calories = client.readRecords(ReadRecordsRequest(ActiveCaloriesBurnedRecord::class, range)).records
        val hrs = client.readRecords(ReadRecordsRequest(HeartRateRecord::class, range)).records
        val cadences = client.readRecords(ReadRecordsRequest(CyclingPedalingCadenceRecord::class, range)).records

        distances.forEach(origin); speeds.forEach(origin); powers.forEach(origin); elevations.forEach(origin)
        calories.forEach(origin); hrs.forEach(origin); cadences.forEach(origin)

        fun overlaps(start: Instant, end: Instant, session: ExerciseSessionRecord): Boolean =
            start.isBefore(session.endTime) && end.isAfter(session.startTime)

        return sessions.map { session ->
            val d = distances.filter { overlaps(it.startTime, it.endTime, session) }
            val s = speeds.filter { overlaps(it.startTime, it.endTime, session) }
            val p = powers.filter { overlaps(it.startTime, it.endTime, session) }
            val e = elevations.filter { overlaps(it.startTime, it.endTime, session) }
            val c = calories.filter { overlaps(it.startTime, it.endTime, session) }
            val h = hrs.filter { overlaps(it.startTime, it.endTime, session) }
            val cad = cadences.filter { overlaps(it.startTime, it.endTime, session) }

            val speedValues = s.flatMap { it.samples }.map { it.speed.inMetersPerSecond * 3.6 }
            val powerValues = p.flatMap { it.samples }.map { it.power.inWatts }
            val hrValues = h.flatMap { it.samples }.map { it.beatsPerMinute.toDouble() }
            val cadenceValues = cad.flatMap { it.samples }.map { it.revolutionsPerMinute.toDouble() }

            WorkoutSummary(
                type = exerciseTypeName(session.exerciseType),
                start = session.startTime,
                end = session.endTime,
                durationMinutes = Duration.between(session.startTime, session.endTime).toMinutes().coerceAtLeast(0),
                distanceKm = d.sumOf { it.distance.inKilometers }.takeIf { it > 0 },
                avgSpeedKmh = speedValues.takeIf { it.isNotEmpty() }?.average(),
                maxSpeedKmh = speedValues.maxOrNull(),
                avgPowerW = powerValues.takeIf { it.isNotEmpty() }?.average(),
                maxPowerW = powerValues.maxOrNull(),
                elevationM = e.sumOf { it.elevation.inMeters }.takeIf { it > 0 },
                calories = c.sumOf { it.energy.inKilocalories }.takeIf { it > 0 },
                avgHeartRate = hrValues.takeIf { it.isNotEmpty() }?.average()?.roundToInt(),
                maxHeartRate = hrValues.maxOrNull()?.roundToInt(),
                source = session.metadata.dataOrigin.packageName,
                avgCadenceRpm = cadenceValues.takeIf { it.isNotEmpty() }?.average(),
                maxCadenceRpm = cadenceValues.maxOrNull()
            )
        }
    }

    private suspend fun readWorkout(session: ExerciseSessionRecord, origin: (Record) -> Unit): WorkoutSummary {
        val range = TimeRangeFilter.between(session.startTime, session.endTime)
        val distances = client.readRecords(ReadRecordsRequest(DistanceRecord::class, range)).records
        val speeds = client.readRecords(ReadRecordsRequest(SpeedRecord::class, range)).records
        val powers = client.readRecords(ReadRecordsRequest(PowerRecord::class, range)).records
        val elevations = client.readRecords(ReadRecordsRequest(ElevationGainedRecord::class, range)).records
        val calories = client.readRecords(ReadRecordsRequest(ActiveCaloriesBurnedRecord::class, range)).records
        val hrs = client.readRecords(ReadRecordsRequest(HeartRateRecord::class, range)).records
        val cadences = client.readRecords(ReadRecordsRequest(CyclingPedalingCadenceRecord::class, range)).records
        distances.forEach(origin); speeds.forEach(origin); powers.forEach(origin); elevations.forEach(origin); calories.forEach(origin); hrs.forEach(origin); cadences.forEach(origin)
        val speedValues = speeds.flatMap { it.samples }.map { it.speed.inMetersPerSecond * 3.6 }
        val powerValues = powers.flatMap { it.samples }.map { it.power.inWatts }
        val hrValues = hrs.flatMap { it.samples }.map { it.beatsPerMinute.toDouble() }
        val cadenceValues = cadences.flatMap { it.samples }.map { it.revolutionsPerMinute.toDouble() }
        return WorkoutSummary(
            type = exerciseTypeName(session.exerciseType), start = session.startTime, end = session.endTime,
            durationMinutes = Duration.between(session.startTime, session.endTime).toMinutes().coerceAtLeast(0),
            distanceKm = distances.sumOf { it.distance.inKilometers }.takeIf { it > 0 },
            avgSpeedKmh = speedValues.takeIf { it.isNotEmpty() }?.average(), maxSpeedKmh = speedValues.maxOrNull(),
            avgPowerW = powerValues.takeIf { it.isNotEmpty() }?.average(), maxPowerW = powerValues.maxOrNull(),
            elevationM = elevations.sumOf { it.elevation.inMeters }.takeIf { it > 0 },
            calories = calories.sumOf { it.energy.inKilocalories }.takeIf { it > 0 },
            avgHeartRate = hrValues.takeIf { it.isNotEmpty() }?.average()?.roundToInt(), maxHeartRate = hrValues.maxOrNull()?.roundToInt(),
            source = session.metadata.dataOrigin.packageName,
            avgCadenceRpm = cadenceValues.takeIf { it.isNotEmpty() }?.average(), maxCadenceRpm = cadenceValues.maxOrNull()
        )
    }

    private fun exerciseTypeName(type: Int): String = when (type) {
        ExerciseSessionRecord.EXERCISE_TYPE_BIKING -> "Radfahren"
        ExerciseSessionRecord.EXERCISE_TYPE_RUNNING -> "Laufen"
        ExerciseSessionRecord.EXERCISE_TYPE_WALKING -> "Gehen"
        ExerciseSessionRecord.EXERCISE_TYPE_HIKING -> "Wandern"
        ExerciseSessionRecord.EXERCISE_TYPE_SWIMMING_POOL -> "Schwimmen"
        ExerciseSessionRecord.EXERCISE_TYPE_STRENGTH_TRAINING -> "Krafttraining"
        ExerciseSessionRecord.EXERCISE_TYPE_ELLIPTICAL -> "Crosstrainer"
        else -> "Training"
    }
}
