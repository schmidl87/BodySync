# Body Sync v0.6.0

Foundation + visible personal history release.

- Local SQLite history stores health snapshots from foreground and background sync.
- Tappable metrics open personal history screens with a simple trend chart.
- Health Connect permission re-check is available in More, useful after new data types were added.
- Health overview shows total and active calories more clearly.
- Missing values remain honest when the connected source does not provide a record.
- Prepared for future AI explanations, Recovery/Body Sync rings, Fitness Age and external sources such as Withings, Wahoo, Strava and Speediance.
