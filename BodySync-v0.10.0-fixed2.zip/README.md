# Body Sync 0.10.0

## Änderungen
- Startseite: Tagesform und Vitalwerte kompakt nebeneinander.
- Tagesform wird auf Startseite und Analyse aus derselben zentralen Berechnung angezeigt.
- Vitalwerte als horizontale, kompakte Karten mit persönlicher Basislinie, wenn genügend Verlauf vorhanden ist.
- Schlaf in Stunden und Minuten statt Minutenanzeige.
- HRV und SpO₂ werden über einen längeren Health-Connect-Zeitraum gesucht.
- Gewicht-Detailseite erweitert um BMI, FFMI, Fettmasse, FMI, Körperfett, Magermasse, Körperwasser und Knochenmasse, soweit echte Health-Connect-Daten vorhanden sind.
- Keine erfundenen Körperwerte: fehlende Daten bleiben „—“.
- BMI bleibt als klassischer Größen-/Gewichtsindex sichtbar. FFMI/FMI sind zusätzliche Körperkompositionskennzahlen.
- Neues transparentes diagonales DNA-/Datenstrang-App-Icon.
- Package ID bleibt com.bodysync.app, damit Updates über bestehende Installationen möglich bleiben.
