package com.bodysync.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.time.Duration
import java.time.Instant
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.launch

private val Bg = Color(0xFF080A0D)
private val Card = Color(0xFF12161B)
private val Muted = Color(0xFF8E98A6)
private val Accent = Color(0xFFB7FF4A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        scheduleBackgroundSync(this)
        setContent { BodySyncApp() }
    }
}

private enum class Tab(val label: String) {
    TODAY("Heute"), HEALTH("Health"), TRAINING("Training"), ANALYSIS("Analyse"), MORE("Mehr")
}

@Composable
fun BodySyncApp() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf(Tab.TODAY) }
    var manager by remember { mutableStateOf<HealthConnectManager?>(null) }
    var snapshot by remember { mutableStateOf<HealthSnapshot?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var availability by remember { mutableStateOf(HealthConnectClient.SDK_UNAVAILABLE) }
    var permissionState by remember { mutableStateOf("Noch nicht verbunden") }

    val permissionLauncher = rememberLauncherForActivityResult(
        PermissionController.createRequestPermissionResultContract()
    ) { _ ->
        scope.launch {
            manager?.let { m ->
                permissionState = permissionStatus(m)
                if (permissionState == "Verbunden" || permissionState == "Teilweise verbunden") {
                    loadSnapshot(m, context, { loading = it }, { error = it }) { snapshot = it }
                }
            }
        }
    }

    fun connect() {
        scope.launch {
            val status = HealthConnectManager.availability(context)
            availability = status
            if (status != HealthConnectClient.SDK_AVAILABLE) {
                openHealthConnectStore(context)
                return@launch
            }
            val m = runCatching { HealthConnectManager.create(context) }.getOrNull()
            manager = m
            if (m == null) {
                error = "Health Connect konnte nicht gestartet werden."
                return@launch
            }
            permissionLauncher.launch(m.permissions + "android.permission.health.READ_HEALTH_DATA_IN_BACKGROUND")
        }
    }

    fun refresh() {
        scope.launch {
            availability = HealthConnectManager.availability(context)
            if (availability != HealthConnectClient.SDK_AVAILABLE) {
                permissionState = "Health Connect nicht verfügbar"
                openHealthConnectStore(context)
                return@launch
            }
            val m = manager ?: runCatching { HealthConnectManager.create(context) }.getOrNull()
            manager = m
            if (m == null) {
                error = "Health Connect konnte nicht gestartet werden."
                return@launch
            }
            permissionState = permissionStatus(m)
            if (permissionState != "Nicht verbunden") {
                loadSnapshot(m, context, { loading = it }, { error = it }) { snapshot = it }
            }
        }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) refresh()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(Unit) { refresh() }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Card) {
                Tab.values().forEach { tab ->
                    NavigationBarItem(
                        selected = selected == tab,
                        onClick = { selected = tab },
                        icon = { Text(iconFor(tab), fontSize = 17.sp) },
                        label = { Text(tab.label) }
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (selected) {
                Tab.TODAY -> TodayScreen(snapshot, permissionState, loading, error, ::connect, ::refresh)
                Tab.HEALTH -> HealthScreen(snapshot, loading, ::refresh)
                Tab.TRAINING -> TrainingScreen(snapshot)
                Tab.ANALYSIS -> AnalysisScreen(snapshot)
                Tab.MORE -> MoreScreen(manager, availability, permissionState, permissionLauncher, ::refresh, context)
            }
        }
    }
}

private suspend fun permissionStatus(manager: HealthConnectManager): String {
    val granted = manager.grantedPermissions()
    return when {
        granted.containsAll(manager.permissions) -> "Verbunden"
        granted.intersect(manager.permissions).isNotEmpty() -> "Teilweise verbunden"
        else -> "Nicht verbunden"
    }
}

private suspend fun loadSnapshot(
    manager: HealthConnectManager,
    context: Context,
    setLoading: (Boolean) -> Unit,
    setError: (String?) -> Unit,
    setSnapshot: (HealthSnapshot) -> Unit
) {
    setLoading(true)
    setError(null)
    runCatching { manager.readSnapshot(30) }
        .onSuccess { setSnapshot(it) }
        .onFailure { setError(friendlyError(it)) }
    setLoading(false)
}

private fun scheduleBackgroundSync(context: Context) {
    val request = PeriodicWorkRequestBuilder<HealthSyncWorker>(15, TimeUnit.MINUTES).build()
    WorkManager.getInstance(context).enqueueUniquePeriodicWork(
        "BodySyncHealthSync",
        ExistingPeriodicWorkPolicy.KEEP,
        request
    )
}

@Composable
private fun TodayScreen(
    snapshot: HealthSnapshot?,
    permissionState: String,
    loading: Boolean,
    error: String?,
    onConnect: () -> Unit,
    onRefresh: () -> Unit
) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Text("Heute", fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Text("Body Sync", color = Muted)
            Spacer(Modifier.height(18.dp))
        }
        item {
            Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("HEALTH CONNECT", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(permissionState, color = if (permissionState == "Verbunden") Accent else Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(12.dp))
                    if (permissionState == "Nicht verbunden") Button(onClick = onConnect) { Text("Health Connect verbinden") }
                    else OutlinedButton(onClick = onRefresh) { Text("Jetzt synchronisieren") }
                }
            }
            Spacer(Modifier.height(14.dp))
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Metric("Schritte", snapshot?.steps?.toString() ?: "—", Modifier.weight(1f))
                Metric("Ø Puls", snapshot?.heartRateAvg?.let { "$it bpm" } ?: "—", Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Metric("Aktiv", snapshot?.activeCalories?.let { "$it kcal" } ?: "—", Modifier.weight(1f))
                Metric("Gesamt", snapshot?.totalCalories?.let { "$it kcal" } ?: "—", Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Metric("Ruhe", snapshot?.restingCalories?.let { "$it kcal" } ?: "—", Modifier.weight(1f))
                Metric("Distanz", snapshot?.distanceKm?.let { "%.1f km".format(it) } ?: "—", Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Metric("Schlaf", snapshot?.sleepMinutes?.let(::formatSleep) ?: "—", Modifier.weight(1f))
                Metric("VO₂max", snapshot?.vo2Max?.let { "%.1f".format(it) } ?: "—", Modifier.weight(1f))
            }
            Spacer(Modifier.height(14.dp))
        }
        if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        if (error != null) item { Text(error, color = Color(0xFFFF9B9B), modifier = Modifier.padding(vertical = 10.dp)) }
        item {
            Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("SYNC", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("Automatische Synchronisierung aktiv", fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                    Text("Beim Öffnen und anschließend regelmäßig im Hintergrund werden neue Health-Connect-Daten eingelesen.", color = Muted)
                }
            }
        }
    }
}

@Composable
private fun HealthScreen(snapshot: HealthSnapshot?, loading: Boolean, onRefresh: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Text("Health", fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Text("30-Tage-Datenbasis aus Health Connect", color = Muted)
            Spacer(Modifier.height(16.dp))
        }
        item { DetailMetric("Schritte", snapshot?.steps?.toString() ?: "—") }
        item { DetailMetric("Aktive Kalorien", snapshot?.activeCalories?.let { "$it kcal" } ?: "—") }
        item { DetailMetric("Gesamtkalorien", snapshot?.totalCalories?.let { "$it kcal" } ?: "—") }
        item { DetailMetric("Ruhekalorien / BMR", snapshot?.restingCalories?.let { "$it kcal/Tag" } ?: "—") }
        item { DetailMetric("Ø Herzfrequenz", snapshot?.heartRateAvg?.let { "$it bpm" } ?: "—") }
        item { DetailMetric("Ruhepuls", snapshot?.restingHeartRate?.let { "$it bpm" } ?: "—") }
        item { DetailMetric("HRV", snapshot?.hrvMs?.let { "%.1f ms".format(it) } ?: "—") }
        item { DetailMetric("Atemfrequenz", snapshot?.respiratoryRate?.let { "%.1f /min".format(it) } ?: "—") }
        item { DetailMetric("SpO₂", snapshot?.oxygenPercent?.let { "%.1f %%".format(it) } ?: "—") }
        item { DetailMetric("Gewicht", snapshot?.weightKg?.let { "%.1f kg".format(it) } ?: "—") }
        item { DetailMetric("Größe", snapshot?.heightCm?.let { "%.0f cm".format(it) } ?: "—") }
        item { DetailMetric("VO₂max", snapshot?.vo2Max?.let { "%.1f ml/kg/min".format(it) } ?: "—") }
        item { DetailMetric("Distanz", snapshot?.distanceKm?.let { "%.1f km".format(it) } ?: "—") }
        item { Spacer(Modifier.height(6.dp)); OutlinedButton(onClick = onRefresh) { Text("Jetzt synchronisieren") } }
    }
}

@Composable
private fun TrainingScreen(snapshot: HealthSnapshot?) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Text("Training", fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Text("Trainings der letzten 30 Tage", color = Muted)
            Spacer(Modifier.height(16.dp))
        }
        if (snapshot?.workoutList.isNullOrEmpty()) {
            item { DetailMetric("Workouts", "Keine Trainingsdaten") }
        } else {
            items(snapshot!!.workoutList) { workout -> WorkoutCard(workout) }
        }
    }
}

@Composable
private fun WorkoutCard(workout: WorkoutSummary) {
    Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text(workout.type, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Text(workout.start.toString().replace("T", " ").take(16), color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            val values = mutableListOf<String>()
            values += "${workout.durationMinutes} min"
            workout.distanceKm?.let { values += "%.1f km".format(it) }
            workout.avgSpeedKmh?.let { values += "%.1f km/h".format(it) }
            workout.avgPowerW?.let { values += "%.0f W Ø".format(it) }
            workout.maxPowerW?.let { values += "%.0f W max".format(it) }
            workout.elevationM?.let { values += "+%.0f m".format(it) }
            workout.calories?.let { values += "%.0f kcal".format(it) }
            workout.avgHeartRate?.let { values += "$it bpm Ø" }
            workout.maxHeartRate?.let { values += "$it bpm max" }
            Text(values.joinToString(" · "), color = Color.White)
        }
    }
}

@Composable
private fun AnalysisScreen(snapshot: HealthSnapshot?) {
    SimpleScreen("Analyse", "Die Datenbasis ist jetzt deutlich größer. Als Nächstes kommen Recovery, Training Load, Trends und Fitness Age.\n\nWorkouts: ${snapshot?.workouts ?: 0}\nQuellen: ${snapshot?.sources ?: 0}")
}

@Composable
private fun MoreScreen(
    manager: HealthConnectManager?,
    availability: Int,
    permissionState: String,
    launcher: androidx.activity.result.ActivityResultLauncher<Set<String>>,
    onRefresh: () -> Unit,
    context: Context
) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Mehr", fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp)) {
                Text("Health Connect", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Text("Status: $permissionState", color = Muted)
                Spacer(Modifier.height(12.dp))
                Button(enabled = manager != null, onClick = { manager?.let { launcher.launch(it.permissions + "android.permission.health.READ_HEALTH_DATA_IN_BACKGROUND") } }) {
                    Text("Berechtigungen verwalten")
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { openHealthConnectSettings(context) }) { Text("Health-Connect-Einstellungen") }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = onRefresh) { Text("Jetzt synchronisieren") }
                Spacer(Modifier.height(10.dp))
                Text("Body Sync synchronisiert beim Öffnen und regelmäßig im Hintergrund. Die Datenbasis ist für spätere Quellen wie Strava, Wahoo und Speediance vorbereitet.", color = Muted)
            }
        }
        if (availability != HealthConnectClient.SDK_AVAILABLE) {
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = { openHealthConnectStore(context) }) { Text("Health Connect installieren / aktualisieren") }
        }
    }
}

@Composable
private fun SimpleScreen(title: String, subtitle: String) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text(title, fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(subtitle, color = Muted)
        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp)) {
                Text("Nächste Ebene", fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                Text("Body Sync baut jetzt auf der erweiterten Datenbasis auf.", color = Muted)
            }
        }
    }
}

@Composable
private fun Metric(title: String, value: String, modifier: Modifier) {
    Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(22.dp), modifier = modifier) {
        Column(Modifier.padding(18.dp)) {
            Text(title, color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(7.dp))
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun DetailMetric(title: String, value: String) {
    Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
        Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = Muted)
            Text(value, fontWeight = FontWeight.Bold)
        }
    }
}

private fun iconFor(tab: Tab): String = when (tab) {
    Tab.TODAY -> "⌂"
    Tab.HEALTH -> "♥"
    Tab.TRAINING -> "↗"
    Tab.ANALYSIS -> "◔"
    Tab.MORE -> "⋯"
}

private fun formatSleep(minutes: Long): String = "${minutes / 60}h ${minutes % 60}m"

private fun friendlyError(t: Throwable): String = when {
    t is SecurityException || t.message?.contains("permission", true) == true -> "Health Connect hat nicht alle benötigten Berechtigungen freigegeben. Öffne 'Mehr → Berechtigungen verwalten'."
    else -> t.message ?: "Health Connect konnte nicht gelesen werden."
}

private fun openHealthConnectSettings(context: Context) {
    runCatching {
        context.startActivity(Intent(HealthConnectClient.ACTION_HEALTH_CONNECT_SETTINGS))
    }.onFailure { openHealthConnectStore(context) }
}

private fun openHealthConnectStore(context: Context) {
    val packageName = HealthConnectManager.PROVIDER_PACKAGE
    runCatching {
        context.startActivity(Intent(Intent.ACTION_VIEW).apply { data = Uri.parse("market://details?id=$packageName") })
    }.onFailure {
        context.startActivity(Intent(Intent.ACTION_VIEW).apply { data = Uri.parse("https://play.google.com/store/apps/details?id=$packageName") })
    }
}
