package com.bodysync.app

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.*
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import java.time.Duration
import java.time.Instant
import kotlin.math.roundToInt

private data class MetricAccumulator(
    var count: Int = 0,
    var sum: Double = 0.0,
    var min: Double = Double.POSITIVE_INFINITY,
    var max: Double = Double.NEGATIVE_INFINITY
) {
    fun add(value: Double) { count++; sum += value; min = kotlin.math.min(min, value); max = kotlin.math.max(max, value) }
    fun avg(): Double? = if (count == 0) null else sum / count
}

data class WorkoutSummary(
    val type: String,
    val start: Instant,
    val durationMinutes: Long,
    val distanceKm: Double? = null,
    val avgSpeedKmh: Double? = null,
    val avgPowerW: Double? = null,
    val maxPowerW: Double? = null,
    val elevationM: Double? = null,
    val calories: Double? = null,
    val avgHeartRate: Int? = null,
    val maxHeartRate: Int? = null,
    val source: String = "",
    val avgCadenceRpm: Double? = null,
    val maxCadenceRpm: Double? = null
)

data class HealthSnapshot(
    val steps: Long? = null,
    val heartRateAvg: Int? = null,
    val restingHeartRate: Int? = null,
    val hrvMs: Double? = null,
    val respiratoryRate: Double? = null,
    val activeCalories: Int? = null,
    val totalCalories: Int? = null,
    val restingCalories: Int? = null,
    val sleepMinutes: Long? = null,
    val weightKg: Double? = null,
    val heightCm: Double? = null,
    val oxygenPercent: Double? = null,
    val vo2Max: Double? = null,
    val distanceKm: Double? = null,
    val workouts: Int = 0,
    val sources: Int = 0,
    val lastSync: Instant? = null,
    val workoutList: List<WorkoutSummary> = emptyList()
)

class HealthConnectManager private constructor(private val client: HealthConnectClient) {
    companion object {
        const val PROVIDER_PACKAGE = "com.google.android.apps.healthdata"
        fun availability(context: Context): Int = HealthConnectClient.getSdkStatus(context, PROVIDER_PACKAGE)
        fun create(context: Context): HealthConnectManager = HealthConnectManager(HealthConnectClient.getOrCreate(context))
    }

    val permissions: Set<String> = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(RestingHeartRateRecord::class),
        HealthPermission.getReadPermission(HeartRateVariabilityRmssdRecord::class),
        HealthPermission.getReadPermission(RespiratoryRateRecord::class),
        HealthPermission.getReadPermission(OxygenSaturationRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class),
        HealthPermission.getReadPermission(ExerciseSessionRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getReadPermission(SpeedRecord::class),
        HealthPermission.getReadPermission(PowerRecord::class),
        HealthPermission.getReadPermission(ElevationGainedRecord::class),
        HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(TotalCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(BasalMetabolicRateRecord::class),
        HealthPermission.getReadPermission(WeightRecord::class),
        HealthPermission.getReadPermission(HeightRecord::class),
        HealthPermission.getReadPermission(Vo2MaxRecord::class),
        HealthPermission.getReadPermission(StepsCadenceRecord::class),
        HealthPermission.getReadPermission(CyclingPedalingCadenceRecord::class),
        HealthPermission.getReadPermission(FloorsClimbedRecord::class)
    )

    suspend fun grantedPermissions(): Set<String> = client.permissionController.getGrantedPermissions()

    suspend fun readSnapshot(days: Long = 30): HealthSnapshot {
        val end = Instant.now()
        val start = end.minus(Duration.ofDays(days))
        val range = TimeRangeFilter.between(start, end)
        val origins = mutableSetOf<String>()

        var steps = 0L
        var activeKcal = 0.0
        var totalKcal = 0.0
        var sleepMinutes = 0L
        var distanceKm = 0.0
        var latestWeight: WeightRecord? = null
        var latestHeight: HeightRecord? = null
        var latestVo2: Vo2MaxRecord? = null
        var bmrWatts: Double? = null
        val hr = MetricAccumulator()
        val hrv = MetricAccumulator()
        val resp = MetricAccumulator()
        val spo2 = MetricAccumulator()
        val resting = MetricAccumulator()

        fun origin(record: Record) { origins += record.metadata.dataOrigin.packageName }

        client.readRecords(ReadRecordsRequest(StepsRecord::class, range)).records.forEach { steps += it.count; origin(it) }
        client.readRecords(ReadRecordsRequest(HeartRateRecord::class, range)).records.forEach { r -> origin(r); r.samples.forEach { hr.add(it.beatsPerMinute.toDouble()) } }
        client.readRecords(ReadRecordsRequest(RestingHeartRateRecord::class, range)).records.forEach { r -> origin(r); resting.add(r.beatsPerMinute.toDouble()) }
        client.readRecords(ReadRecordsRequest(HeartRateVariabilityRmssdRecord::class, range)).records.forEach { r -> origin(r); hrv.add(r.heartRateVariabilityMillis) } 
        client.readRecords(ReadRecordsRequest(RespiratoryRateRecord::class, range)).records.forEach { r -> origin(r); resp.add(r.rate) }
        client.readRecords(ReadRecordsRequest(OxygenSaturationRecord::class, range)).records.forEach { r -> origin(r); spo2.add(r.percentage.value) }
        client.readRecords(ReadRecordsRequest(ActiveCaloriesBurnedRecord::class, range)).records.forEach { r -> origin(r); activeKcal += r.energy.inKilocalories }
        client.readRecords(ReadRecordsRequest(TotalCaloriesBurnedRecord::class, range)).records.forEach { r -> origin(r); totalKcal += r.energy.inKilocalories }
        client.readRecords(ReadRecordsRequest(DistanceRecord::class, range)).records.forEach { r -> origin(r); distanceKm += r.distance.inKilometers }
        client.readRecords(ReadRecordsRequest(SleepSessionRecord::class, range)).records.forEach { r -> origin(r); sleepMinutes += Duration.between(r.startTime, r.endTime).toMinutes() }
        client.readRecords(ReadRecordsRequest(WeightRecord::class, range)).records.forEach { r -> origin(r); if (latestWeight == null || r.time.isAfter(latestWeight!!.time)) latestWeight = r }
        client.readRecords(ReadRecordsRequest(HeightRecord::class, range)).records.forEach { r -> origin(r); if (latestHeight == null || r.time.isAfter(latestHeight!!.time)) latestHeight = r }
        client.readRecords(ReadRecordsRequest(Vo2MaxRecord::class, range)).records.forEach { r -> origin(r); if (latestVo2 == null || r.time.isAfter(latestVo2!!.time)) latestVo2 = r }
        client.readRecords(ReadRecordsRequest(BasalMetabolicRateRecord::class, range)).records.forEach { r -> origin(r); bmrWatts = r.basalMetabolicRate.inWatts }

        val workouts = client.readRecords(ReadRecordsRequest(ExerciseSessionRecord::class, range)).records.sortedByDescending { it.startTime }
        workouts.forEach { origin(it) }

        val workoutSummaries = workouts.take(50).map { session ->
            val sessionRange = TimeRangeFilter.between(session.startTime, session.endTime)
            val distances = client.readRecords(ReadRecordsRequest(DistanceRecord::class, sessionRange)).records
            val speeds = client.readRecords(ReadRecordsRequest(SpeedRecord::class, sessionRange)).records
            val powers = client.readRecords(ReadRecordsRequest(PowerRecord::class, sessionRange)).records
            val elevations = client.readRecords(ReadRecordsRequest(ElevationGainedRecord::class, sessionRange)).records
            val calories = client.readRecords(ReadRecordsRequest(ActiveCaloriesBurnedRecord::class, sessionRange)).records
            val hrs = client.readRecords(ReadRecordsRequest(HeartRateRecord::class, sessionRange)).records
            val cadences = client.readRecords(ReadRecordsRequest(CyclingPedalingCadenceRecord::class, sessionRange)).records
            val powerSamples = powers.flatMap { it.samples }
            val speedSamples = speeds.flatMap { it.samples }
            val heartSamples = hrs.flatMap { it.samples }
            val cadenceSamples = cadences.flatMap { it.samples }
            val distance = distances.sumOf { it.distance.inKilometers }
            val speedAvg = speedSamples.map { it.speed.inMetersPerSecond * 3.6 }.takeIf { it.isNotEmpty() }?.average()
            val powerValues = powerSamples.map { it.power.inWatts }
            val hrValues = heartSamples.map { it.beatsPerMinute.toDouble() }
            val cadenceValues = cadenceSamples.map { it.revolutionsPerMinute.toDouble() }
            WorkoutSummary(
                type = exerciseTypeName(session.exerciseType),
                start = session.startTime,
                durationMinutes = Duration.between(session.startTime, session.endTime).toMinutes(),
                distanceKm = distance.takeIf { it > 0 },
                avgSpeedKmh = speedAvg,
                avgPowerW = powerValues.takeIf { it.isNotEmpty() }?.average(),
                maxPowerW = powerValues.maxOrNull(),
                elevationM = elevations.sumOf { it.elevation.inMeters }.takeIf { it > 0 },
                calories = calories.sumOf { it.energy.inKilocalories }.takeIf { it > 0 },
                avgHeartRate = hrValues.takeIf { it.isNotEmpty() }?.average()?.roundToInt(),
                maxHeartRate = hrValues.maxOrNull()?.roundToInt(),
                source = session.metadata.dataOrigin.packageName,
                avgCadenceRpm = cadenceValues.takeIf { it.isNotEmpty() }?.average(),
                maxCadenceRpm = cadenceValues.maxOrNull()
            )
        }

        val restingCalories = bmrWatts?.let { it * 86400.0 / 4184.0 }
        return HealthSnapshot(
            steps = steps.takeIf { it > 0 },
            heartRateAvg = hr.avg()?.roundToInt(),
            restingHeartRate = resting.avg()?.roundToInt(),
            hrvMs = hrv.avg(),
            respiratoryRate = resp.avg(),
            activeCalories = activeKcal.roundToInt().takeIf { it > 0 },
            totalCalories = totalKcal.roundToInt().takeIf { it > 0 },
            restingCalories = restingCalories?.roundToInt(),
            sleepMinutes = sleepMinutes.takeIf { it > 0 },
            weightKg = latestWeight?.weight?.inKilograms,
            heightCm = latestHeight?.height?.inMeters?.times(100.0),
            oxygenPercent = spo2.avg(),
            vo2Max = latestVo2?.vo2MillilitersPerMinuteKilogram,
            distanceKm = distanceKm.takeIf { it > 0 },
            workouts = workouts.size,
            sources = origins.size,
            lastSync = Instant.now(),
            workoutList = workoutSummaries
        )
    }

    private fun exerciseTypeName(type: Int): String = when (type) {
        ExerciseSessionRecord.EXERCISE_TYPE_BIKING -> "Radfahren"
        ExerciseSessionRecord.EXERCISE_TYPE_RUNNING -> "Laufen"
        ExerciseSessionRecord.EXERCISE_TYPE_WALKING -> "Gehen"
        ExerciseSessionRecord.EXERCISE_TYPE_HIKING -> "Wandern"
        ExerciseSessionRecord.EXERCISE_TYPE_SWIMMING_POOL -> "Schwimmen"
        ExerciseSessionRecord.EXERCISE_TYPE_STRENGTH_TRAINING -> "Krafttraining"
        ExerciseSessionRecord.EXERCISE_TYPE_ELLIPTICAL -> "Crosstrainer"
        else -> "Training"
    }
}
