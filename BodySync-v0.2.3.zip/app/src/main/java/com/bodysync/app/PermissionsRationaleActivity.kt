package com.bodysync.app

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class PermissionsRationaleActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val text = TextView(this).apply {
            text = "Body Sync nutzt Health Connect, um Gesundheits- und Fitnessdaten wie Schritte, Herzfrequenz, Schlaf, aktive Kalorien, Gewicht, Sauerstoffsättigung und Training anzuzeigen. Die Daten werden nur für die Funktionen von Body Sync verwendet und auf dem Gerät verarbeitet. Du kannst die Berechtigungen jederzeit in den Health-Connect-Einstellungen ändern."
            textSize = 18f
            setPadding(48, 48, 48, 48)
        }
        setContentView(text)
    }
}
