package com.bodysync.app

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.OxygenSaturationRecord
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.WeightRecord
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import java.time.Duration
import java.time.Instant
import kotlin.math.roundToInt

data class HealthSnapshot(
    val steps: Long? = null,
    val heartRate: Int? = null,
    val activeCalories: Int? = null,
    val sleepMinutes: Long? = null,
    val weightKg: Double? = null,
    val oxygenPercent: Double? = null,
    val workouts: Int? = null,
    val sourceCount: Int = 0
)

class HealthConnectManager private constructor(private val client: HealthConnectClient) {

    companion object {
        const val PROVIDER_PACKAGE = "com.google.android.apps.healthdata"

        fun availability(context: Context): Int =
            HealthConnectClient.getSdkStatus(context, PROVIDER_PACKAGE)

        fun create(context: Context): HealthConnectManager =
            HealthConnectManager(HealthConnectClient.getOrCreate(context))
    }

    val permissions: Set<String> = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class),
        HealthPermission.getReadPermission(ExerciseSessionRecord::class),
        HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(WeightRecord::class),
        HealthPermission.getReadPermission(OxygenSaturationRecord::class)
    )

    suspend fun grantedPermissions(): Set<String> =
        client.permissionController.getGrantedPermissions()

    suspend fun hasAnyPermission(): Boolean =
        grantedPermissions().intersect(permissions).isNotEmpty()

    suspend fun hasAllPermissions(): Boolean =
        grantedPermissions().containsAll(permissions)

    suspend fun readLastSevenDays(): HealthSnapshot {
        val end = Instant.now()
        val start = end.minus(Duration.ofDays(7))
        val range = TimeRangeFilter.between(start, end)

        var steps = 0L
        var heartSum = 0.0
        var heartCount = 0
        var calories = 0.0
        var sleepMinutes = 0L
        var latestWeight: Double? = null
        var latestWeightTime: Instant? = null
        var oxygenSum = 0.0
        var oxygenCount = 0
        var workouts = 0
        val origins = mutableSetOf<String>()

        client.readRecords(ReadRecordsRequest(StepsRecord::class, range)).records.forEach {
            steps += it.count
            origins += it.metadata.dataOrigin.packageName
        }

        client.readRecords(ReadRecordsRequest(HeartRateRecord::class, range)).records.forEach { record ->
            origins += record.metadata.dataOrigin.packageName
            record.samples.forEach {
                heartSum += it.beatsPerMinute
                heartCount++
            }
        }

        client.readRecords(ReadRecordsRequest(ActiveCaloriesBurnedRecord::class, range)).records.forEach {
            calories += it.energy.inKilocalories
            origins += it.metadata.dataOrigin.packageName
        }

        client.readRecords(ReadRecordsRequest(SleepSessionRecord::class, range)).records.forEach {
            sleepMinutes += Duration.between(it.startTime, it.endTime).toMinutes()
            origins += it.metadata.dataOrigin.packageName
        }

        client.readRecords(ReadRecordsRequest(WeightRecord::class, range)).records.forEach {
            if (latestWeightTime == null || it.time.isAfter(latestWeightTime)) {
                latestWeightTime = it.time
                latestWeight = it.weight.inKilograms
            }
            origins += it.metadata.dataOrigin.packageName
        }

        client.readRecords(ReadRecordsRequest(OxygenSaturationRecord::class, range)).records.forEach {
            oxygenSum += it.percentage.value
            oxygenCount++
            origins += it.metadata.dataOrigin.packageName
        }

        val exerciseRecords = client.readRecords(
            ReadRecordsRequest(ExerciseSessionRecord::class, range)
        ).records
        workouts = exerciseRecords.size
        exerciseRecords.forEach { origins += it.metadata.dataOrigin.packageName }

        return HealthSnapshot(
            steps = steps.takeIf { it > 0 },
            heartRate = if (heartCount > 0) (heartSum / heartCount).roundToInt() else null,
            activeCalories = if (calories > 0) calories.roundToInt() else null,
            sleepMinutes = sleepMinutes.takeIf { it > 0 },
            weightKg = latestWeight,
            oxygenPercent = if (oxygenCount > 0) oxygenSum / oxygenCount else null,
            workouts = workouts.takeIf { it > 0 },
            sourceCount = origins.size
        )
    }
}
