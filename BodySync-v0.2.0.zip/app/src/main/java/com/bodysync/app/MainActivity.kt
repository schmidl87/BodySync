package com.bodysync.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContract
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.*
import kotlinx.coroutines.launch

private val Bg = Color(0xFF080A0D)
private val Card = Color(0xFF12161B)
private val Muted = Color(0xFF8E98A6)
private val Accent = Color(0xFFB7FF4A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BodySyncApp() }
    }
}

private enum class Tab(val label: String) {
    TODAY("Heute"), HEALTH("Health"), TRAINING("Training"), ANALYSIS("Analyse"), MORE("Mehr")
}

@Composable
fun BodySyncApp() {
    var selected by remember { mutableStateOf(Tab.TODAY) }
    var manager by remember { mutableStateOf<HealthConnectManager?>(null) }
    var snapshot by remember { mutableStateOf<HealthSnapshot?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = PermissionController.createRequestPermissionResultContract()
    ) {
        scope.launch {
            val m = manager ?: return@launch
            if (m.hasPermissions()) {
                loading = true
                error = null
                snapshot = runCatching { m.readLastSevenDays() }
                    .onFailure { error = it.message ?: "Health-Connect-Daten konnten nicht gelesen werden." }
                    .getOrNull()
                loading = false
            }
        }
    }

    LaunchedEffect(Unit) {
        val m = HealthConnectManager(context)
        manager = m
        runCatching {
            if (m.hasPermissions()) {
                loading = true
                snapshot = m.readLastSevenDays()
                loading = false
            }
        }.onFailure {
            error = it.message ?: "Health Connect ist noch nicht verfügbar."
            loading = false
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Card, primary = Accent,
        onPrimary = Color.Black, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0D1014)) {
                    Tab.entries.forEach { tab ->
                        NavigationBarItem(
                            selected = selected == tab,
                            onClick = { selected = tab },
                            icon = { Text(if (tab == Tab.TODAY) "⌂" else if (tab == Tab.HEALTH) "♥" else if (tab == Tab.TRAINING) "◉" else if (tab == Tab.ANALYSIS) "⌁" else "⚙") },
                            label = { Text(tab.label) }
                        )
                    }
                }
            }
        ) { padding ->
            when (selected) {
                Tab.TODAY -> TodayScreen(snapshot, loading, error) {
                    manager?.let { m ->
                        scope.launch {
                            if (m.hasPermissions()) {
                                loading = true
                                snapshot = runCatching { m.readLastSevenDays() }
                                    .onFailure { error = it.message ?: "Fehler beim Lesen." }
                                    .getOrNull()
                                loading = false
                            } else {
                                permissionLauncher.launch(m.permissions)
                            }
                        }
                    }
                }
                Tab.HEALTH -> HealthScreen(snapshot)
                Tab.TRAINING -> TrainingScreen(snapshot)
                Tab.ANALYSIS -> AnalysisScreen()
                Tab.MORE -> MoreScreen(manager, permissionLauncher)
            }
        }
    }
}

@Composable
private fun TodayScreen(
    snapshot: HealthSnapshot?,
    loading: Boolean,
    error: String?,
    onConnect: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 22.dp, bottom = 20.dp)
    ) {
        item {
            Text("BODY SYNC", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Muted)
            Text("Heute", fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(18.dp))
        }
        item {
            Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(22.dp)) {
                    Text("HEALTH CONNECT", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    if (snapshot == null) {
                        Text("Deine echten Gesundheitsdaten sind noch nicht verbunden.", fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = onConnect) { Text("Health Connect verbinden") }
                    } else {
                        Text("Daten synchronisiert", fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
                        Text("${snapshot.sourceCount} Datenquellen erkannt · letzte 7 Tage", color = Muted)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Metric("Schritte", snapshot?.steps?.toString() ?: "—", Modifier.weight(1f))
                Metric("Ø Puls", snapshot?.heartRate?.let { "$it bpm" } ?: "—", Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Metric("Schlaf", snapshot?.sleepMinutes?.let { formatSleep(it) } ?: "—", Modifier.weight(1f))
                Metric("Training", snapshot?.workouts?.toString() ?: "—", Modifier.weight(1f))
            }
            Spacer(Modifier.height(14.dp))
        }
        if (loading) item { LinearProgressIndicator(modifier = Modifier.fillMaxWidth()) }
        if (error != null) item {
            Text(error, color = Color(0xFFFF9B9B), modifier = Modifier.padding(vertical = 10.dp))
        }
        item {
            Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("KI-ANALYSE", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("Die KI kommt als nächste Ebene.", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Text("Sobald deine Daten sauber zusammengeführt sind, analysiert Body Sync Recovery, Training, Trends und Fitness Age.", color = Muted)
                }
            }
        }
    }
}

@Composable private fun HealthScreen(snapshot: HealthSnapshot?) {
    SimpleScreen("Gesundheit", "Deine Gesundheitsdaten aus Health Connect.")
    // Detailed cards will be expanded in the next build.
}

@Composable private fun TrainingScreen(snapshot: HealthSnapshot?) {
    SimpleScreen("Training", "Trainingsdaten werden hier quellenübergreifend zusammengeführt.")
}

@Composable private fun AnalysisScreen() {
    SimpleScreen("Analyse", "Hier entstehen später Recovery, Training Load, Trends und Fitness Age.")
}

@Composable private fun MoreScreen(
    manager: HealthConnectManager?,
    launcher: androidx.activity.result.ActivityResultLauncher<Set<String>>
) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Mehr", fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp)) {
                Text("Datenquellen", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text("Health Connect ist die erste aktive Datenquelle. Strava, Wahoo und Speediance folgen.", color = Muted)
                Spacer(Modifier.height(12.dp))
                Button(enabled = manager != null, onClick = { manager?.let { launcher.launch(it.permissions) } }) {
                    Text("Health-Connect-Berechtigungen")
                }
            }
        }
    }
}

@Composable private fun SimpleScreen(title: String, subtitle: String) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text(title, fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(subtitle, color = Muted)
        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp)) {
                Text("Noch keine Demo-Daten", fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                Text("Diese Ansicht wird mit deinen echten Daten gefüllt.", color = Muted)
            }
        }
    }
}

@Composable private fun Metric(title: String, value: String, modifier: Modifier) {
    Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(22.dp), modifier = modifier) {
        Column(Modifier.padding(18.dp)) {
            Text(title, color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(7.dp))
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
    }
}

private fun formatSleep(minutes: Long): String {
    val h = minutes / 60
    val m = minutes % 60
    return "${h}h ${m}m"
}
