# Body Sync

Version 0.2.0

Body Sync is a modern Android fitness and health hub.

## This build
- Real Health Connect permission flow
- Reads the last 7 days of steps, heart rate, sleep, active calories, weight, oxygen saturation and exercise sessions
- Shows real values instead of hard-coded demo metrics once permission is granted
- Functional bottom navigation
- Clear foundation for source prioritization, duplicate detection and AI analysis

Health Connect 1.1.0 is used as the stable client baseline.
