package com.bodysync.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg=Color(0xFF080A0D); private val Card=Color(0xFF12161B)
private val Muted=Color(0xFF8E98A6); private val Accent=Color(0xFFB7FF4A)

class MainActivity: ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{BodySyncApp()}}
}
@Composable fun BodySyncApp(){
 MaterialTheme(colorScheme=darkColorScheme(background=Bg,surface=Card,primary=Accent,onPrimary=Color.Black,onBackground=Color.White,onSurface=Color.White)){
  Scaffold(containerColor=Bg,bottomBar={
   NavigationBar(containerColor=Color(0xFF0D1014)){
    NavigationBarItem(true,{},icon={Text("⌂")},label={Text("Heute")})
    NavigationBarItem(false,{},icon={Text("♥")},label={Text("Health")})
    NavigationBarItem(false,{},icon={Text("◉")},label={Text("Training")})
    NavigationBarItem(false,{},icon={Text("⌁")},label={Text("Analyse")})
    NavigationBarItem(false,{},icon={Text("⚙")},label={Text("Mehr")})
   }
  }){p->
   Column(Modifier.fillMaxSize().padding(p).padding(20.dp)){
    Text("BODY SYNC",fontSize=14.sp,fontWeight=FontWeight.Bold,color=Muted)
    Text("Heute",fontSize=32.sp,fontWeight=FontWeight.Bold)
    Spacer(Modifier.height(18.dp))
    Card(colors=CardDefaults.cardColors(Card),shape=RoundedCornerShape(28.dp),modifier=Modifier.fillMaxWidth()){
     Column(Modifier.padding(22.dp)){
      Text("RECOVERY",color=Muted,fontSize=13.sp,fontWeight=FontWeight.Bold)
      Row(verticalAlignment=Alignment.Bottom){Text("78",fontSize=64.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.width(10.dp));Text("GOOD",color=Accent,fontWeight=FontWeight.Bold,modifier=Modifier.padding(bottom=12.dp))}
      Text("Deine Basis für Training und Regeneration.",color=Muted)
     }
    }
    Spacer(Modifier.height(14.dp))
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)){
     Metric("HRV","58 ms","+8 %",Modifier.weight(1f));Metric("Ruhepuls","57","−3 bpm",Modifier.weight(1f))
    }
    Spacer(Modifier.height(14.dp))
    Card(colors=CardDefaults.cardColors(Card),shape=RoundedCornerShape(24.dp),modifier=Modifier.fillMaxWidth()){
     Column(Modifier.padding(20.dp)){Text("HEUTE",color=Muted,fontSize=12.sp,fontWeight=FontWeight.Bold);Text("Moderates Training",fontSize=21.sp,fontWeight=FontWeight.SemiBold);Text("KI-Analyse wird hier später Gesundheits- und Trainingsdaten zusammenführen.",color=Muted)}
    }
   }
  }
 }
}
@Composable private fun Metric(t:String,v:String,c:String,m:Modifier){
 Card(colors=CardDefaults.cardColors(Card),shape=RoundedCornerShape(22.dp),modifier=m){
  Column(Modifier.padding(18.dp)){Text(t,color=Muted,fontSize=12.sp,fontWeight=FontWeight.Bold);Text(v,fontSize=25.sp,fontWeight=FontWeight.Bold);Text(c,color=Accent,fontSize=13.sp)}
 }
}
