# Body Sync v0.4.0

Sleep & Workout Detail release.

- Reworked sleep aggregation: latest night instead of summing 30 days.
- Sleep stages: awake, light, deep, REM, unknown.
- Clickable workout list with detailed workout view.
- More polished dashboard UI with cards, status, sleep timeline and workout summaries.
- Today metrics use today's time window; workout history remains 30 days.
- Expanded workout details: distance, speed, power, elevation, calories, heart rate, cadence and source where Health Connect provides them.
- Background sync via WorkManager remains enabled.
