package com.bodysync.app

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.*
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import java.time.Instant

class HealthSyncWorker(appContext: Context, workerParams: WorkerParameters) : CoroutineWorker(appContext, workerParams) {
    override suspend fun doWork(): Result {
        return runCatching {
            if (HealthConnectManager.availability(applicationContext) != HealthConnectClient.SDK_AVAILABLE) return Result.success()
            val manager = HealthConnectManager.create(applicationContext)
            val granted = manager.grantedPermissions()
            if (granted.intersect(manager.permissions).isEmpty()) return Result.success()
            manager.readSnapshot(30)
            applicationContext.getSharedPreferences("bodysync_sync", Context.MODE_PRIVATE)
                .edit()
                .putLong("last_background_sync", Instant.now().toEpochMilli())
                .apply()
            Result.success()
        }.getOrElse { Result.retry() }
    }
}
