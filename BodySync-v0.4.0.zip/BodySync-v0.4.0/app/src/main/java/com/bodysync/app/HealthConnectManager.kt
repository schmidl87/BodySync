package com.bodysync.app

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.*
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.math.roundToInt

private data class MetricAccumulator(var count: Int = 0, var sum: Double = 0.0) {
    fun add(value: Double) { count++; sum += value }
    fun avg(): Double? = if (count == 0) null else sum / count
}

data class SleepStageSummary(val label: String, val minutes: Long, val type: Int)
data class SleepSummary(
    val start: Instant,
    val end: Instant,
    val totalMinutes: Long,
    val awakeMinutes: Long,
    val lightMinutes: Long,
    val deepMinutes: Long,
    val remMinutes: Long,
    val unknownMinutes: Long,
    val stages: List<SleepStageSummary>,
    val source: String
)

data class WorkoutSummary(
    val id: String,
    val type: String,
    val start: Instant,
    val durationMinutes: Long,
    val distanceKm: Double? = null,
    val avgSpeedKmh: Double? = null,
    val maxSpeedKmh: Double? = null,
    val avgPowerW: Double? = null,
    val maxPowerW: Double? = null,
    val elevationM: Double? = null,
    val calories: Double? = null,
    val avgHeartRate: Int? = null,
    val maxHeartRate: Int? = null,
    val source: String = "",
    val avgCadenceRpm: Double? = null,
    val maxCadenceRpm: Double? = null
)

data class HealthSnapshot(
    val steps: Long? = null,
    val heartRateAvg: Int? = null,
    val restingHeartRate: Int? = null,
    val hrvMs: Double? = null,
    val respiratoryRate: Double? = null,
    val activeCalories: Int? = null,
    val totalCalories: Int? = null,
    val restingCalories: Int? = null,
    val sleepMinutes: Long? = null,
    val weightKg: Double? = null,
    val heightCm: Double? = null,
    val oxygenPercent: Double? = null,
    val vo2Max: Double? = null,
    val distanceKm: Double? = null,
    val floors: Double? = null,
    val workouts: Int = 0,
    val sources: Int = 0,
    val lastSync: Instant? = null,
    val sleep: SleepSummary? = null,
    val workoutList: List<WorkoutSummary> = emptyList()
)

class HealthConnectManager private constructor(private val client: HealthConnectClient) {
    companion object {
        const val PROVIDER_PACKAGE = "com.google.android.apps.healthdata"
        fun availability(context: Context): Int = HealthConnectClient.getSdkStatus(context, PROVIDER_PACKAGE)
        fun create(context: Context): HealthConnectManager = HealthConnectManager(HealthConnectClient.getOrCreate(context))
    }

    val permissions: Set<String> = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(RestingHeartRateRecord::class),
        HealthPermission.getReadPermission(HeartRateVariabilityRmssdRecord::class),
        HealthPermission.getReadPermission(RespiratoryRateRecord::class),
        HealthPermission.getReadPermission(OxygenSaturationRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class),
        HealthPermission.getReadPermission(ExerciseSessionRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getReadPermission(SpeedRecord::class),
        HealthPermission.getReadPermission(PowerRecord::class),
        HealthPermission.getReadPermission(ElevationGainedRecord::class),
        HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(TotalCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(BasalMetabolicRateRecord::class),
        HealthPermission.getReadPermission(WeightRecord::class),
        HealthPermission.getReadPermission(HeightRecord::class),
        HealthPermission.getReadPermission(Vo2MaxRecord::class),
        HealthPermission.getReadPermission(CyclingPedalingCadenceRecord::class),
        HealthPermission.getReadPermission(FloorsClimbedRecord::class)
    )

    suspend fun grantedPermissions(): Set<String> = client.permissionController.getGrantedPermissions()

    suspend fun readSnapshot(days: Long = 30): HealthSnapshot {
        val now = Instant.now()
        val zone = ZoneId.systemDefault()
        val todayStart = ZonedDateTime.now(zone).toLocalDate().atStartOfDay(zone).toInstant()
        val historyStart = now.minus(Duration.ofDays(days))
        val todayRange = TimeRangeFilter.between(todayStart, now)
        val historyRange = TimeRangeFilter.between(historyStart, now)
        val origins = mutableSetOf<String>()

        fun origin(record: Record) { origins += record.metadata.dataOrigin.packageName }

        var steps = 0L
        client.readRecords(ReadRecordsRequest(StepsRecord::class, todayRange)).records.forEach { steps += it.count; origin(it) }

        val hr = MetricAccumulator()
        client.readRecords(ReadRecordsRequest(HeartRateRecord::class, todayRange)).records.forEach { r -> origin(r); r.samples.forEach { hr.add(it.beatsPerMinute.toDouble()) } }
        val resting = MetricAccumulator()
        client.readRecords(ReadRecordsRequest(RestingHeartRateRecord::class, historyRange)).records.forEach { r -> origin(r); resting.add(r.beatsPerMinute.toDouble()) }
        val hrv = MetricAccumulator()
        client.readRecords(ReadRecordsRequest(HeartRateVariabilityRmssdRecord::class, todayRange)).records.forEach { r -> origin(r); hrv.add(r.heartRateVariabilityMillis) }
        val resp = MetricAccumulator()
        client.readRecords(ReadRecordsRequest(RespiratoryRateRecord::class, todayRange)).records.forEach { r -> origin(r); resp.add(r.rate) }
        val spo2 = MetricAccumulator()
        client.readRecords(ReadRecordsRequest(OxygenSaturationRecord::class, todayRange)).records.forEach { r -> origin(r); spo2.add(r.percentage.value) }

        var activeKcal = 0.0
        client.readRecords(ReadRecordsRequest(ActiveCaloriesBurnedRecord::class, todayRange)).records.forEach { r -> origin(r); activeKcal += r.energy.inKilocalories }
        var totalKcal = 0.0
        client.readRecords(ReadRecordsRequest(TotalCaloriesBurnedRecord::class, todayRange)).records.forEach { r -> origin(r); totalKcal += r.energy.inKilocalories }
        var bmrWatts: Double? = null
        client.readRecords(ReadRecordsRequest(BasalMetabolicRateRecord::class, historyRange)).records.forEach { r -> origin(r); bmrWatts = r.basalMetabolicRate.inWatts }
        val restingCalories = bmrWatts?.let { it * 86400.0 / 4184.0 }

        var distanceKm = 0.0
        client.readRecords(ReadRecordsRequest(DistanceRecord::class, todayRange)).records.forEach { r -> origin(r); distanceKm += r.distance.inKilometers }
        var floors = 0.0
        client.readRecords(ReadRecordsRequest(FloorsClimbedRecord::class, todayRange)).records.forEach { r -> origin(r); floors += r.floors }

        val latestWeight = client.readRecords(ReadRecordsRequest(WeightRecord::class, historyRange)).records.maxByOrNull { it.time }?.also(::origin)
        val latestHeight = client.readRecords(ReadRecordsRequest(HeightRecord::class, historyRange)).records.maxByOrNull { it.time }?.also(::origin)
        val latestVo2 = client.readRecords(ReadRecordsRequest(Vo2MaxRecord::class, historyRange)).records.maxByOrNull { it.time }?.also(::origin)

        val sleepRecords = client.readRecords(ReadRecordsRequest(SleepSessionRecord::class, historyRange)).records
        sleepRecords.forEach(::origin)
        val latestSleep = sleepRecords
            .filter { it.endTime.isAfter(now.minus(Duration.ofHours(36))) }
            .maxByOrNull { it.endTime }
            ?: sleepRecords.maxByOrNull { it.endTime }
        val sleepSummary = latestSleep?.let { summarizeSleep(it) }

        val workouts = client.readRecords(ReadRecordsRequest(ExerciseSessionRecord::class, historyRange)).records.sortedByDescending { it.startTime }
        workouts.forEach(::origin)
        val workoutSummaries = workouts.take(40).map { session -> readWorkout(session) }

        return HealthSnapshot(
            steps = steps.takeIf { it > 0 },
            heartRateAvg = hr.avg()?.roundToInt(),
            restingHeartRate = resting.avg()?.roundToInt(),
            hrvMs = hrv.avg(),
            respiratoryRate = resp.avg(),
            activeCalories = activeKcal.roundToInt().takeIf { it > 0 },
            totalCalories = totalKcal.roundToInt().takeIf { it > 0 },
            restingCalories = restingCalories?.roundToInt(),
            sleepMinutes = sleepSummary?.totalMinutes,
            weightKg = latestWeight?.weight?.inKilograms,
            heightCm = latestHeight?.height?.inMeters?.times(100.0),
            oxygenPercent = spo2.avg(),
            vo2Max = latestVo2?.vo2MillilitersPerMinuteKilogram,
            distanceKm = distanceKm.takeIf { it > 0 },
            floors = floors.takeIf { it > 0 },
            workouts = workouts.size,
            sources = origins.size,
            lastSync = Instant.now(),
            sleep = sleepSummary,
            workoutList = workoutSummaries
        )
    }

    private suspend fun readWorkout(session: ExerciseSessionRecord): WorkoutSummary {
        val range = TimeRangeFilter.between(session.startTime, session.endTime)
        val distances = client.readRecords(ReadRecordsRequest(DistanceRecord::class, range)).records
        val speeds = client.readRecords(ReadRecordsRequest(SpeedRecord::class, range)).records
        val powers = client.readRecords(ReadRecordsRequest(PowerRecord::class, range)).records
        val elevations = client.readRecords(ReadRecordsRequest(ElevationGainedRecord::class, range)).records
        val calories = client.readRecords(ReadRecordsRequest(ActiveCaloriesBurnedRecord::class, range)).records
        val hrs = client.readRecords(ReadRecordsRequest(HeartRateRecord::class, range)).records
        val cadences = client.readRecords(ReadRecordsRequest(CyclingPedalingCadenceRecord::class, range)).records

        val speedValues = speeds.flatMap { it.samples }.map { it.speed.inMetersPerSecond * 3.6 }
        val powerValues = powers.flatMap { it.samples }.map { it.power.inWatts }
        val hrValues = hrs.flatMap { it.samples }.map { it.beatsPerMinute.toDouble() }
        val cadenceValues = cadences.flatMap { it.samples }.map { it.revolutionsPerMinute.toDouble() }

        return WorkoutSummary(
            id = session.metadata.id,
            type = exerciseTypeName(session.exerciseType),
            start = session.startTime,
            durationMinutes = Duration.between(session.startTime, session.endTime).toMinutes(),
            distanceKm = distances.sumOf { it.distance.inKilometers }.takeIf { it > 0 },
            avgSpeedKmh = speedValues.takeIf { it.isNotEmpty() }?.average(),
            maxSpeedKmh = speedValues.maxOrNull(),
            avgPowerW = powerValues.takeIf { it.isNotEmpty() }?.average(),
            maxPowerW = powerValues.maxOrNull(),
            elevationM = elevations.sumOf { it.elevation.inMeters }.takeIf { it > 0 },
            calories = calories.sumOf { it.energy.inKilocalories }.takeIf { it > 0 },
            avgHeartRate = hrValues.takeIf { it.isNotEmpty() }?.average()?.roundToInt(),
            maxHeartRate = hrValues.maxOrNull()?.roundToInt(),
            source = session.metadata.dataOrigin.packageName,
            avgCadenceRpm = cadenceValues.takeIf { it.isNotEmpty() }?.average(),
            maxCadenceRpm = cadenceValues.maxOrNull()
        )
    }

    private fun summarizeSleep(session: SleepSessionRecord): SleepSummary {
        var awake = 0L
        var light = 0L
        var deep = 0L
        var rem = 0L
        var unknown = 0L
        session.stages.forEach { stage ->
            val minutes = Duration.between(stage.startTime, stage.endTime).toMinutes().coerceAtLeast(0)
            when (stage.stage) {
                SleepSessionRecord.STAGE_TYPE_AWAKE,
                SleepSessionRecord.STAGE_TYPE_AWAKE_IN_BED,
                SleepSessionRecord.STAGE_TYPE_OUT_OF_BED -> awake += minutes
                SleepSessionRecord.STAGE_TYPE_LIGHT -> light += minutes
                SleepSessionRecord.STAGE_TYPE_DEEP -> deep += minutes
                SleepSessionRecord.STAGE_TYPE_REM -> rem += minutes
                else -> unknown += minutes
            }
        }
        val total = Duration.between(session.startTime, session.endTime).toMinutes().coerceAtLeast(0)
        val stageList = listOf(
            SleepStageSummary("Wach", awake, SleepSessionRecord.STAGE_TYPE_AWAKE),
            SleepStageSummary("Leicht", light, SleepSessionRecord.STAGE_TYPE_LIGHT),
            SleepStageSummary("Tief", deep, SleepSessionRecord.STAGE_TYPE_DEEP),
            SleepStageSummary("REM", rem, SleepSessionRecord.STAGE_TYPE_REM),
            SleepStageSummary("Unbekannt", unknown, SleepSessionRecord.STAGE_TYPE_UNKNOWN)
        ).filter { it.minutes > 0 }
        return SleepSummary(session.startTime, session.endTime, total, awake, light, deep, rem, unknown, stageList, session.metadata.dataOrigin.packageName)
    }

    private fun exerciseTypeName(type: Int): String = when (type) {
        ExerciseSessionRecord.EXERCISE_TYPE_BIKING, ExerciseSessionRecord.EXERCISE_TYPE_BIKING_STATIONARY -> "Radfahren"
        ExerciseSessionRecord.EXERCISE_TYPE_RUNNING, ExerciseSessionRecord.EXERCISE_TYPE_RUNNING_TREADMILL -> "Laufen"
        ExerciseSessionRecord.EXERCISE_TYPE_WALKING -> "Gehen"
        ExerciseSessionRecord.EXERCISE_TYPE_HIKING -> "Wandern"
        ExerciseSessionRecord.EXERCISE_TYPE_SWIMMING_POOL, ExerciseSessionRecord.EXERCISE_TYPE_SWIMMING_OPEN_WATER -> "Schwimmen"
        ExerciseSessionRecord.EXERCISE_TYPE_STRENGTH_TRAINING, ExerciseSessionRecord.EXERCISE_TYPE_WEIGHTLIFTING -> "Krafttraining"
        ExerciseSessionRecord.EXERCISE_TYPE_ELLIPTICAL -> "Crosstrainer"
        ExerciseSessionRecord.EXERCISE_TYPE_ROWING, ExerciseSessionRecord.EXERCISE_TYPE_ROWING_MACHINE -> "Rudern"
        else -> "Training"
    }
}
