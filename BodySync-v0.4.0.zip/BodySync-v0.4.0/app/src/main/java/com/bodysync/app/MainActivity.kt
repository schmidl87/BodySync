package com.bodysync.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.launch

private val Bg = Color(0xFF07090C)
private val Surface = Color(0xFF11151B)
private val Surface2 = Color(0xFF171C23)
private val TextPrimary = Color(0xFFF4F7FA)
private val TextMuted = Color(0xFF8D98A7)
private val Lime = Color(0xFFB8F34A)
private val Blue = Color(0xFF62B7FF)
private val Purple = Color(0xFFB78CFF)
private val Cyan = Color(0xFF58E0D0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        scheduleBackgroundSync(this)
        setContent { BodySyncApp() }
    }
}

private enum class Tab(val label: String) { TODAY("Heute"), HEALTH("Health"), TRAINING("Training"), ANALYSIS("Analyse"), MORE("Mehr") }

@Composable
fun BodySyncApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf(Tab.TODAY) }
    var manager by remember { mutableStateOf<HealthConnectManager?>(null) }
    var snapshot by remember { mutableStateOf<HealthSnapshot?>(null) }
    var selectedWorkout by remember { mutableStateOf<WorkoutSummary?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var availability by remember { mutableStateOf(HealthConnectClient.SDK_UNAVAILABLE) }
    var permissionState by remember { mutableStateOf("Nicht verbunden") }

    val permissionLauncher = rememberLauncherForActivityResult(PermissionController.createRequestPermissionResultContract()) {
        scope.launch {
            manager?.let { m ->
                permissionState = permissionStatus(m)
                if (permissionState != "Nicht verbunden") loadSnapshot(m, { loading = it }, { error = it }) { snapshot = it }
            }
        }
    }

    fun connect() {
        scope.launch {
            availability = HealthConnectManager.availability(context)
            if (availability != HealthConnectClient.SDK_AVAILABLE) { openHealthConnectStore(context); return@launch }
            val m = runCatching { HealthConnectManager.create(context) }.getOrNull()
            manager = m
            if (m == null) { error = "Health Connect konnte nicht gestartet werden."; return@launch }
            permissionLauncher.launch(m.permissions + "android.permission.health.READ_HEALTH_DATA_IN_BACKGROUND")
        }
    }

    fun refresh() {
        scope.launch {
            availability = HealthConnectManager.availability(context)
            if (availability != HealthConnectClient.SDK_AVAILABLE) { permissionState = "Health Connect nicht verfügbar"; return@launch }
            val m = manager ?: runCatching { HealthConnectManager.create(context) }.getOrNull()
            manager = m
            if (m == null) { error = "Health Connect konnte nicht gestartet werden."; return@launch }
            permissionState = permissionStatus(m)
            if (permissionState != "Nicht verbunden") loadSnapshot(m, { loading = it }, { error = it }) { snapshot = it }
        }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_RESUME) refresh() }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    LaunchedEffect(Unit) { refresh() }

    if (selectedWorkout != null) {
        WorkoutDetailScreen(selectedWorkout!!, onBack = { selectedWorkout = null })
        return
    }

    Scaffold(containerColor = Bg, bottomBar = {
        NavigationBar(containerColor = Surface, tonalElevation = 0.dp) {
            Tab.values().forEach { tab ->
                NavigationBarItem(selected = selected == tab, onClick = { selected = tab }, icon = { Text(iconFor(tab), fontSize = 18.sp) }, label = { Text(tab.label) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Lime, selectedTextColor = Lime, indicatorColor = Surface2, unselectedIconColor = TextMuted, unselectedTextColor = TextMuted))
            }
        }
    }) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (selected) {
                Tab.TODAY -> TodayScreen(snapshot, permissionState, loading, error, ::connect, ::refresh)
                Tab.HEALTH -> HealthScreen(snapshot, loading, ::refresh)
                Tab.TRAINING -> TrainingScreen(snapshot) { selectedWorkout = it }
                Tab.ANALYSIS -> AnalysisScreen(snapshot)
                Tab.MORE -> MoreScreen(manager, availability, permissionState, permissionLauncher, ::refresh, context)
            }
        }
    }
}

private suspend fun permissionStatus(manager: HealthConnectManager): String {
    val granted = manager.grantedPermissions()
    val count = granted.intersect(manager.permissions).size
    return when { count == manager.permissions.size -> "Verbunden"; count > 0 -> "Teilweise verbunden"; else -> "Nicht verbunden" }
}

private suspend fun loadSnapshot(manager: HealthConnectManager, setLoading: (Boolean) -> Unit, setError: (String?) -> Unit, setSnapshot: (HealthSnapshot) -> Unit) {
    setLoading(true); setError(null)
    runCatching { manager.readSnapshot(30) }.onSuccess(setSnapshot).onFailure { setError(friendlyError(it)) }
    setLoading(false)
}

private fun scheduleBackgroundSync(context: Context) {
    val request = PeriodicWorkRequestBuilder<HealthSyncWorker>(15, TimeUnit.MINUTES).build()
    WorkManager.getInstance(context).enqueueUniquePeriodicWork("BodySyncHealthSync", ExistingPeriodicWorkPolicy.KEEP, request)
}

@Composable
private fun TodayScreen(snapshot: HealthSnapshot?, permissionState: String, loading: Boolean, error: String?, onConnect: () -> Unit, onRefresh: () -> Unit) {
    val date = DateTimeFormatter.ofPattern("EEEE, d. MMMM", java.util.Locale.GERMANY).format(java.time.LocalDate.now())
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), contentPadding = PaddingValues(top = 22.dp, bottom = 30.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Guten Tag", color = TextMuted, fontSize = 14.sp); Text("Dein Body Sync", color = TextPrimary, fontSize = 32.sp, fontWeight = FontWeight.Bold); Text(date.replaceFirstChar { it.uppercase() }, color = TextMuted) }
        item { SyncCard(permissionState, loading, error, onConnect, onRefresh, snapshot?.lastSync) }
        item { HeroRecoveryCard(snapshot) }
        item { SectionTitle("Heute") }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) { MetricCard("Schritte", snapshot?.steps?.let { "% ,d".format(it).replace(",", ".") } ?: "—", "Schritte", Lime, Modifier.weight(1f)); MetricCard("Aktiv", snapshot?.activeCalories?.let { "$it kcal" } ?: "—", "Kalorien", Blue, Modifier.weight(1f)) } }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) { MetricCard("Gesamt", snapshot?.totalCalories?.let { "$it kcal" } ?: "—", "Verbrauch", Purple, Modifier.weight(1f)); MetricCard("Distanz", snapshot?.distanceKm?.let { "%.1f km".format(it) } ?: "—", "Heute", Cyan, Modifier.weight(1f)) } }
        item { SleepCard(snapshot?.sleep) }
        item { SectionTitle("Letzte Trainings") }
        if (snapshot?.workoutList.isNullOrEmpty()) item { EmptyCard("Noch keine Trainingsdaten gefunden.") }
        else items(snapshot!!.workoutList.take(3), key = { it.id }) { WorkoutRow(it, {}) }
    }
}

@Composable private fun SyncCard(status: String, loading: Boolean, error: String?, onConnect: () -> Unit, onRefresh: () -> Unit, lastSync: Instant?) {
    Card(colors = CardDefaults.cardColors(Surface), shape = RoundedCornerShape(26.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(10.dp).clip(CircleShape).background(if (status == "Verbunden") Lime else Color(0xFFFFB74D))); Spacer(Modifier.width(10.dp)); Text(if (status == "Verbunden") "Health Connect verbunden" else status, color = TextPrimary, fontWeight = FontWeight.SemiBold) }
            Spacer(Modifier.height(8.dp)); Text(if (loading) "Synchronisiere deine Gesundheitsdaten …" else "Body Sync aktualisiert Daten automatisch beim Öffnen und im Hintergrund.", color = TextMuted, fontSize = 13.sp)
            lastSync?.let { Text("Letzte Synchronisierung: ${formatTime(it)}", color = TextMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp)) }
            if (!error.isNullOrBlank()) Text(error, color = Color(0xFFFF8A80), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { if (status == "Nicht verbunden") Button(onClick = onConnect, colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Color.Black)) { Text("Verbinden") } else OutlinedButton(onClick = onRefresh) { Text("Jetzt synchronisieren") } }
        }
    }
}

@Composable private fun HeroRecoveryCard(snapshot: HealthSnapshot?) {
    Card(colors = CardDefaults.cardColors(Surface2), shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(22.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("BODY STATUS", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold); Text("Datengrundlage", color = TextPrimary, fontSize = 23.sp, fontWeight = FontWeight.Bold); Text("Noch kein medizinischer Score – Body Sync sammelt zuerst deine Basisdaten.", color = TextMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp)) }
            Text("${snapshot?.sources ?: 0}", color = Lime, fontSize = 38.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable private fun HealthScreen(snapshot: HealthSnapshot?, loading: Boolean, onRefresh: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), contentPadding = PaddingValues(top = 22.dp, bottom = 30.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Health", fontSize = 32.sp, fontWeight = FontWeight.Bold); Text("Deine wichtigsten Körperdaten", color = TextMuted) }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) { MetricCard("Ruhepuls", snapshot?.restingHeartRate?.let { "$it bpm" } ?: "—", "Basis", Blue, Modifier.weight(1f)); MetricCard("HRV", snapshot?.hrvMs?.let { "%.0f ms".format(it) } ?: "—", "RMSSD", Purple, Modifier.weight(1f)) } }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) { MetricCard("SpO₂", snapshot?.oxygenPercent?.let { "%.1f %%".format(it) } ?: "—", "Sauerstoff", Cyan, Modifier.weight(1f)); MetricCard("VO₂max", snapshot?.vo2Max?.let { "%.1f".format(it) } ?: "—", "ml/kg/min", Lime, Modifier.weight(1f)) } }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) { MetricCard("Gewicht", snapshot?.weightKg?.let { "%.1f kg".format(it) } ?: "—", "Körper", Purple, Modifier.weight(1f)); MetricCard("Etagen", snapshot?.floors?.let { "%.0f".format(it) } ?: "—", "Heute", Blue, Modifier.weight(1f)) } }
        item { SleepCard(snapshot?.sleep) }
        item { Text("Kalorien", fontSize = 20.sp, fontWeight = FontWeight.Bold); DetailMetric("Aktiv", snapshot?.activeCalories?.let { "$it kcal" } ?: "—"); DetailMetric("Gesamt", snapshot?.totalCalories?.let { "$it kcal" } ?: "—"); DetailMetric("Ruhe/BMR", snapshot?.restingCalories?.let { "$it kcal / Tag" } ?: "—") }
    }
}

@Composable private fun SleepCard(sleep: SleepSummary?) {
    Card(colors = CardDefaults.cardColors(Surface), shape = RoundedCornerShape(26.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Text("SCHLAF LETZTE NACHT", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            if (sleep == null) { Spacer(Modifier.height(8.dp)); Text("Keine Schlafsession gefunden.", color = TextPrimary); return@Column }
            Text(formatSleep(sleep.totalMinutes), color = TextPrimary, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Text("${formatTime(sleep.start)} – ${formatTime(sleep.end)}", color = TextMuted, fontSize = 12.sp)
            Spacer(Modifier.height(16.dp))
            val total = sleep.stages.sumOf { it.minutes }.coerceAtLeast(1)
            Row(Modifier.fillMaxWidth().height(18.dp).clip(RoundedCornerShape(9.dp))) {
                sleep.stages.forEach { stage -> Box(Modifier.weight(stage.minutes.toFloat().coerceAtLeast(0.1f)).fillMaxHeight().background(stageColor(stage.type))) }
            }
            Spacer(Modifier.height(14.dp))
            sleep.stages.forEach { stage -> Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(9.dp).clip(CircleShape).background(stageColor(stage.type))); Spacer(Modifier.width(9.dp)); Text(stage.label, color = TextMuted, modifier = Modifier.weight(1f)); Text(formatSleep(stage.minutes), color = TextPrimary, fontWeight = FontWeight.SemiBold) } }
        }
    }
}

@Composable private fun TrainingScreen(snapshot: HealthSnapshot?, onSelect: (WorkoutSummary) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), contentPadding = PaddingValues(top = 22.dp, bottom = 30.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Training", fontSize = 32.sp, fontWeight = FontWeight.Bold); Text("Deine letzten Aktivitäten", color = TextMuted) }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) { MetricCard("Sessions", snapshot?.workouts?.toString() ?: "0", "30 Tage", Lime, Modifier.weight(1f)); MetricCard("Distanz", snapshot?.distanceKm?.let { "%.1f km".format(it) } ?: "—", "Heute", Blue, Modifier.weight(1f)) } }
        if (snapshot?.workoutList.isNullOrEmpty()) item { EmptyCard("Noch keine Trainingsdaten gefunden.") }
        else items(snapshot!!.workoutList, key = { it.id }) { WorkoutRow(it) { onSelect(it) } }
    }
}

@Composable private fun WorkoutRow(workout: WorkoutSummary, onClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(Surface), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).clip(CircleShape).background(Surface2), contentAlignment = Alignment.Center) { Text(workoutIcon(workout.type), fontSize = 20.sp) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) { Text(workout.type, color = TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.SemiBold); Text("${formatDate(workout.start)} · ${workout.durationMinutes} min", color = TextMuted, fontSize = 12.sp); Text(workoutSummaryLine(workout), color = TextPrimary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
            Text("›", color = TextMuted, fontSize = 26.sp)
        }
    }
}

@Composable private fun WorkoutDetailScreen(workout: WorkoutSummary, onBack: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().background(Bg).padding(horizontal = 18.dp), contentPadding = PaddingValues(top = 22.dp, bottom = 30.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("‹  Training", color = Lime, fontSize = 16.sp, modifier = Modifier.clickable { onBack() }); Spacer(Modifier.height(8.dp)); Text(workout.type, color = TextPrimary, fontSize = 34.sp, fontWeight = FontWeight.Bold); Text(formatDate(workout.start), color = TextMuted) }
        item { Card(colors = CardDefaults.cardColors(Surface2), shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(22.dp)) { Text("DAUER", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold); Text("${workout.durationMinutes} min", color = TextPrimary, fontSize = 32.sp, fontWeight = FontWeight.Bold); Text("Quelle: ${sourceName(workout.source)}", color = TextMuted, fontSize = 12.sp) } } }
        item { DetailMetric("Distanz", workout.distanceKm?.let { "%.2f km".format(it) } ?: "—"); DetailMetric("Ø Geschwindigkeit", workout.avgSpeedKmh?.let { "%.1f km/h".format(it) } ?: "—"); DetailMetric("Max. Geschwindigkeit", workout.maxSpeedKmh?.let { "%.1f km/h".format(it) } ?: "—"); DetailMetric("Ø Leistung", workout.avgPowerW?.let { "%.0f W".format(it) } ?: "—"); DetailMetric("Max. Leistung", workout.maxPowerW?.let { "%.0f W".format(it) } ?: "—"); DetailMetric("Höhenmeter", workout.elevationM?.let { "%.0f m".format(it) } ?: "—"); DetailMetric("Kalorien", workout.calories?.let { "%.0f kcal".format(it) } ?: "—"); DetailMetric("Ø Herzfrequenz", workout.avgHeartRate?.let { "$it bpm" } ?: "—"); DetailMetric("Max. Herzfrequenz", workout.maxHeartRate?.let { "$it bpm" } ?: "—"); DetailMetric("Ø Kadenz", workout.avgCadenceRpm?.let { "%.0f rpm".format(it) } ?: "—"); DetailMetric("Max. Kadenz", workout.maxCadenceRpm?.let { "%.0f rpm".format(it) } ?: "—") }
    }
}

@Composable private fun AnalysisScreen(snapshot: HealthSnapshot?) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), contentPadding = PaddingValues(top = 22.dp, bottom = 30.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Analyse", fontSize = 32.sp, fontWeight = FontWeight.Bold); Text("Die nächste Ebene von Body Sync", color = TextMuted) }
        item { Card(colors = CardDefaults.cardColors(Surface2), shape = RoundedCornerShape(26.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp)) { Text("DATENBASIS", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold); Text("${snapshot?.sources ?: 0} Quellen", color = Lime, fontSize = 30.sp, fontWeight = FontWeight.Bold); Text("${snapshot?.workouts ?: 0} Trainings in 30 Tagen", color = TextMuted) } } }
        item { DetailMetric("HRV", snapshot?.hrvMs?.let { "%.0f ms".format(it) } ?: "—"); DetailMetric("Ruhepuls", snapshot?.restingHeartRate?.let { "$it bpm" } ?: "—"); DetailMetric("VO₂max", snapshot?.vo2Max?.let { "%.1f ml/kg/min".format(it) } ?: "—") }
        item { EmptyCard("Als Nächstes kommen Training Load, Recovery, Trends und die intelligente Auswertung deiner Daten.") }
    }
}

@Composable private fun MoreScreen(manager: HealthConnectManager?, availability: Int, permissionState: String, launcher: androidx.activity.result.ActivityResultLauncher<Set<String>>, onRefresh: () -> Unit, context: Context) {
    Column(Modifier.fillMaxSize().padding(18.dp)) { Text("Mehr", fontSize = 32.sp, fontWeight = FontWeight.Bold); Text("Verbindungen & Einstellungen", color = TextMuted); Spacer(Modifier.height(18.dp)); Card(colors = CardDefaults.cardColors(Surface), shape = RoundedCornerShape(26.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp)) { Text("Health Connect", fontSize = 20.sp, fontWeight = FontWeight.SemiBold); Text("Status: $permissionState", color = TextMuted); Spacer(Modifier.height(14.dp)); Button(enabled = manager != null, onClick = { manager?.let { launcher.launch(it.permissions + "android.permission.health.READ_HEALTH_DATA_IN_BACKGROUND") } }, colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Color.Black)) { Text("Berechtigungen verwalten") }; Spacer(Modifier.height(8.dp)); OutlinedButton(onClick = { openHealthConnectSettings(context) }) { Text("Health-Connect-Einstellungen") }; Spacer(Modifier.height(8.dp)); OutlinedButton(onClick = onRefresh) { Text("Jetzt synchronisieren") } } } }
}

@Composable private fun MetricCard(title: String, value: String, subtitle: String, accent: Color, modifier: Modifier) { Card(colors = CardDefaults.cardColors(Surface), shape = RoundedCornerShape(24.dp), modifier = modifier) { Column(Modifier.padding(18.dp)) { Box(Modifier.size(8.dp).clip(CircleShape).background(accent)); Spacer(Modifier.height(12.dp)); Text(title, color = TextMuted, fontSize = 12.sp); Text(value, color = TextPrimary, fontSize = 23.sp, fontWeight = FontWeight.Bold); Text(subtitle, color = TextMuted, fontSize = 11.sp) } } }
@Composable private fun DetailMetric(title: String, value: String) { Card(colors = CardDefaults.cardColors(Surface), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth().padding(17.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(title, color = TextMuted); Text(value, color = TextPrimary, fontWeight = FontWeight.Bold) } } }
@Composable private fun SectionTitle(text: String) { Text(text, color = TextPrimary, fontSize = 21.sp, fontWeight = FontWeight.Bold) }
@Composable private fun EmptyCard(text: String) { Card(colors = CardDefaults.cardColors(Surface), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) { Text(text, color = TextMuted, modifier = Modifier.padding(20.dp)) } }

private fun iconFor(tab: Tab) = when (tab) { Tab.TODAY -> "⌂"; Tab.HEALTH -> "♥"; Tab.TRAINING -> "↗"; Tab.ANALYSIS -> "◔"; Tab.MORE -> "⋯" }
private fun workoutIcon(type: String) = when { type.contains("Rad") -> "🚴"; type.contains("Lauf") -> "🏃"; type.contains("Kraft") -> "🏋"; type.contains("Schwimm") -> "🏊"; else -> "⚡" }
private fun formatSleep(minutes: Long): String = "${minutes / 60}h ${minutes % 60}m"
private fun formatTime(i: Instant): String = DateTimeFormatter.ofPattern("HH:mm").withZone(ZoneId.systemDefault()).format(i)
private fun formatDate(i: Instant): String = DateTimeFormatter.ofPattern("dd.MM.yyyy · HH:mm").withZone(ZoneId.systemDefault()).format(i)
private fun friendlyError(t: Throwable): String = if (t is SecurityException || t.message?.contains("permission", true) == true) "Health Connect hat nicht alle benötigten Berechtigungen freigegeben." else t.message ?: "Health Connect konnte nicht gelesen werden."
private fun sourceName(s: String) = when { s.contains("healthdata") -> "Health Connect"; s.contains("google", true) -> "Google / Health Connect"; else -> s.substringAfterLast('.').ifBlank { "Unbekannte Quelle" } }
private fun workoutSummaryLine(w: WorkoutSummary): String = buildList { w.distanceKm?.let { add("%.1f km".format(it)) }; w.avgPowerW?.let { add("%.0f W".format(it)) }; w.avgHeartRate?.let { add("$it bpm") }; w.calories?.let { add("%.0f kcal".format(it)) } }.joinToString(" · ").ifBlank { "Details öffnen" }
private fun stageColor(type: Int): Color = when (type) { 1, 7, 3 -> Color(0xFFFFB74D); 4 -> Blue; 5 -> Purple; 6 -> Cyan; else -> Color(0xFF657080) }

private fun openHealthConnectSettings(context: Context) { runCatching { context.startActivity(Intent(HealthConnectClient.ACTION_HEALTH_CONNECT_SETTINGS)) }.onFailure { openHealthConnectStore(context) } }
private fun openHealthConnectStore(context: Context) { val pkg = HealthConnectManager.PROVIDER_PACKAGE; runCatching { context.startActivity(Intent(Intent.ACTION_VIEW).apply { data = Uri.parse("market://details?id=$pkg") }) }.onFailure { context.startActivity(Intent(Intent.ACTION_VIEW).apply { data = Uri.parse("https://play.google.com/store/apps/details?id=$pkg") }) } }
