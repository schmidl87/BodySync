# Body Sync v0.3.1

Health Connect data foundation with expanded metrics, workout details, cycling power/speed/cadence, automatic background sync, and robust permission handling.
