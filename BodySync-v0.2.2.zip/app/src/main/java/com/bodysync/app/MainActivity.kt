package com.bodysync.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import kotlinx.coroutines.launch

private val Bg = Color(0xFF080A0D)
private val Card = Color(0xFF12161B)
private val Muted = Color(0xFF8E98A6)
private val Accent = Color(0xFFB7FF4A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BodySyncApp() }
    }
}

private enum class Tab(val label: String) {
    TODAY("Heute"), HEALTH("Health"), TRAINING("Training"), ANALYSIS("Analyse"), MORE("Mehr")
}

@Composable
fun BodySyncApp() {
    var selected by remember { mutableStateOf(Tab.TODAY) }
    var manager by remember { mutableStateOf<HealthConnectManager?>(null) }
    var snapshot by remember { mutableStateOf<HealthSnapshot?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var availability by remember { mutableStateOf(HealthConnectClient.SDK_UNAVAILABLE) }
    var permissionState by remember { mutableStateOf("Noch nicht verbunden") }
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current

    fun refresh() {
        val m = manager ?: return
        scope.launch {
            loading = true
            error = null
            runCatching {
                val granted = m.grantedPermissions()
                permissionState = when {
                    granted.containsAll(m.permissions) -> "Verbunden"
                    granted.intersect(m.permissions).isNotEmpty() -> "Teilweise verbunden"
                    else -> "Noch nicht verbunden"
                }
                if (granted.intersect(m.permissions).isNotEmpty()) {
                    snapshot = m.readLastSevenDays()
                } else {
                    snapshot = null
                }
            }.onFailure {
                snapshot = null
                error = friendlyError(it)
            }
            loading = false
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = PermissionController.createRequestPermissionResultContract()
    ) { granted ->
        val m = manager ?: return@rememberLauncherForActivityResult
        permissionState = when {
            granted.containsAll(m.permissions) -> "Verbunden"
            granted.intersect(m.permissions).isNotEmpty() -> "Teilweise verbunden"
            else -> "Nicht verbunden"
        }
        refresh()
    }

    LaunchedEffect(Unit) {
        availability = runCatching { HealthConnectManager.availability(context) }
            .getOrDefault(HealthConnectClient.SDK_UNAVAILABLE)

        if (availability == HealthConnectClient.SDK_AVAILABLE) {
            manager = runCatching { HealthConnectManager.create(context) }
                .onFailure { error = friendlyError(it) }
                .getOrNull()
            manager?.let { m ->
                runCatching {
                    val granted = m.grantedPermissions()
                    permissionState = when {
                        granted.containsAll(m.permissions) -> "Verbunden"
                        granted.intersect(m.permissions).isNotEmpty() -> "Teilweise verbunden"
                        else -> "Noch nicht verbunden"
                    }
                }.onFailure { error = friendlyError(it) }
                refresh()
            } ?: run { loading = false }
        } else {
            loading = false
        }
    }

    fun connectHealthConnect() {
        when (availability) {
            HealthConnectClient.SDK_AVAILABLE -> {
                manager?.let { permissionLauncher.launch(it.permissions) }
            }
            HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED -> {
                openHealthConnectStore(context)
            }
            else -> {
                openHealthConnectStore(context)
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Card, primary = Accent,
        onPrimary = Color.Black, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0D1014)) {
                    Tab.entries.forEach { tab ->
                        NavigationBarItem(
                            selected = selected == tab,
                            onClick = { selected = tab },
                            icon = { Text(if (tab == Tab.TODAY) "⌂" else if (tab == Tab.HEALTH) "♥" else if (tab == Tab.TRAINING) "◉" else if (tab == Tab.ANALYSIS) "⌁" else "⚙") },
                            label = { Text(tab.label) }
                        )
                    }
                }
            }
        ) { padding ->
            when (selected) {
                Tab.TODAY -> TodayScreen(snapshot, loading, error, permissionState, availability, ::connectHealthConnect, ::refresh)
                Tab.HEALTH -> HealthScreen(snapshot, loading, ::refresh)
                Tab.TRAINING -> TrainingScreen(snapshot)
                Tab.ANALYSIS -> AnalysisScreen()
                Tab.MORE -> MoreScreen(manager, availability, permissionState, permissionLauncher, ::refresh, context)
            }
        }
    }
}

@Composable
private fun TodayScreen(
    snapshot: HealthSnapshot?,
    loading: Boolean,
    error: String?,
    permissionState: String,
    availability: Int,
    onConnect: () -> Unit,
    onRefresh: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 22.dp, bottom = 20.dp)
    ) {
        item {
            Text("BODY SYNC", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Muted)
            Text("Heute", fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(18.dp))
        }
        item {
            Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(22.dp)) {
                    Text("HEALTH CONNECT", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    when {
                        availability != HealthConnectClient.SDK_AVAILABLE -> {
                            Text("Health Connect ist auf diesem Gerät noch nicht bereit.", fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(8.dp))
                            Text("Body Sync prüft automatisch, ob Health Connect installiert bzw. aktuell ist.", color = Muted)
                            Spacer(Modifier.height(12.dp))
                            Button(onClick = onConnect) { Text("Health Connect öffnen") }
                        }
                        snapshot != null -> {
                            Text("Health Connect verbunden", fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
                            Text("${snapshot.sourceCount} Datenquellen erkannt · letzte 7 Tage", color = Muted)
                            Spacer(Modifier.height(12.dp))
                            OutlinedButton(onClick = onRefresh) { Text("Daten aktualisieren") }
                        }
                        else -> {
                            Text("Deine echten Gesundheitsdaten sind noch nicht verbunden.", fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(6.dp))
                            Text("Status: $permissionState", color = Muted)
                            Spacer(Modifier.height(12.dp))
                            Button(onClick = onConnect) { Text("Health Connect verbinden") }
                        }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Metric("Schritte", snapshot?.steps?.toString() ?: "—", Modifier.weight(1f))
                Metric("Ø Puls", snapshot?.heartRate?.let { "$it bpm" } ?: "—", Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Metric("Schlaf", snapshot?.sleepMinutes?.let { formatSleep(it) } ?: "—", Modifier.weight(1f))
                Metric("Training", snapshot?.workouts?.toString() ?: "—", Modifier.weight(1f))
            }
            Spacer(Modifier.height(14.dp))
        }
        if (loading) item { LinearProgressIndicator(modifier = Modifier.fillMaxWidth()) }
        if (error != null) item {
            Text(error, color = Color(0xFFFF9B9B), modifier = Modifier.padding(vertical = 10.dp))
        }
        item {
            Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("KI-ANALYSE", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("Die KI kommt als nächste Ebene.", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Text("Sobald deine Daten sauber zusammengeführt sind, analysiert Body Sync Recovery, Training, Trends und Fitness Age.", color = Muted)
                }
            }
        }
    }
}

@Composable private fun HealthScreen(snapshot: HealthSnapshot?, loading: Boolean, onRefresh: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item {
            Text("Gesundheit", fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Text("Echte Werte aus Health Connect", color = Muted)
            Spacer(Modifier.height(16.dp))
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
        }
        item { DetailMetric("Schritte", snapshot?.steps?.toString() ?: "Noch keine Daten") }
        item { DetailMetric("Ø Herzfrequenz", snapshot?.heartRate?.let { "$it bpm" } ?: "Noch keine Daten") }
        item { DetailMetric("Aktive Kalorien", snapshot?.activeCalories?.let { "$it kcal" } ?: "Noch keine Daten") }
        item { DetailMetric("Schlaf", snapshot?.sleepMinutes?.let { formatSleep(it) } ?: "Noch keine Daten") }
        item { DetailMetric("Gewicht", snapshot?.weightKg?.let { "%.1f kg".format(it) } ?: "Noch keine Daten") }
        item { DetailMetric("SpO₂", snapshot?.oxygenPercent?.let { "%.1f %%".format(it) } ?: "Noch keine Daten") }
        item { DetailMetric("Workouts", snapshot?.workouts?.toString() ?: "Noch keine Daten") }
        item { Spacer(Modifier.height(8.dp)); OutlinedButton(onClick = onRefresh) { Text("Daten aktualisieren") } }
    }
}

@Composable private fun TrainingScreen(snapshot: HealthSnapshot?) = SimpleScreen("Training", "Trainingsdaten werden hier quellenübergreifend zusammengeführt.\n\nWorkouts letzte 7 Tage: ${snapshot?.workouts?.toString() ?: "—"}")

@Composable private fun AnalysisScreen() = SimpleScreen("Analyse", "Hier entstehen später Recovery, Training Load, Trends und Fitness Age.")

@Composable
private fun MoreScreen(
    manager: HealthConnectManager?,
    availability: Int,
    permissionState: String,
    launcher: androidx.activity.result.ActivityResultLauncher<Set<String>>,
    onRefresh: () -> Unit,
    context: android.content.Context
) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Mehr", fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp)) {
                Text("Health Connect", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Text("Status: $permissionState", color = Muted)
                Spacer(Modifier.height(12.dp))
                Button(enabled = manager != null, onClick = { manager?.let { launcher.launch(it.permissions) } }) {
                    Text("Berechtigungen verwalten")
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = onRefresh) { Text("Daten neu einlesen") }
                Spacer(Modifier.height(8.dp))
                Text("Health Connect ist die zentrale Datenquelle. Strava, Wahoo und Speediance folgen später.", color = Muted)
            }
        }
        Spacer(Modifier.height(14.dp))
        if (availability != HealthConnectClient.SDK_AVAILABLE) {
            OutlinedButton(onClick = { openHealthConnectStore(context) }) {
                Text("Health Connect installieren / aktualisieren")
            }
        }
    }
}

@Composable private fun SimpleScreen(title: String, subtitle: String) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text(title, fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(subtitle, color = Muted)
        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp)) {
                Text("Noch im Aufbau", fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                Text("Diese Ansicht wird mit deinen echten Daten gefüllt.", color = Muted)
            }
        }
    }
}

@Composable private fun Metric(title: String, value: String, modifier: Modifier) {
    Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(22.dp), modifier = modifier) {
        Column(Modifier.padding(18.dp)) {
            Text(title, color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(7.dp))
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable private fun DetailMetric(title: String, value: String) {
    Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
        Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = Muted)
            Text(value, fontWeight = FontWeight.Bold)
        }
    }
}

private fun formatSleep(minutes: Long): String {
    val h = minutes / 60
    val m = minutes % 60
    return "${h}h ${m}m"
}

private fun friendlyError(t: Throwable): String = when {
    t.message?.contains("SecurityException", ignoreCase = true) == true ->
        "Health Connect hat den Datenzugriff noch nicht freigegeben. Bitte die Berechtigungen öffnen und erneut zulassen."
    else -> t.message ?: "Health Connect konnte nicht erreicht werden."
}

private fun openHealthConnectStore(context: android.content.Context) {
    val packageName = HealthConnectManager.PROVIDER_PACKAGE
    runCatching {
        context.startActivity(Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse("market://details?id=$packageName")
        })
    }.onFailure {
        context.startActivity(Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse("https://play.google.com/store/apps/details?id=$packageName")
        })
    }
}
