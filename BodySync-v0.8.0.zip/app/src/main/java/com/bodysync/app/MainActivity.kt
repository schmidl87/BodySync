package com.bodysync.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalConfiguration
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF080B10)
private val Card = Color(0xFF121821)
private val Card2 = Color(0xFF18212C)
private val TextMain = Color(0xFFF4F7FA)
private val Muted = Color(0xFF91A0AE)
private val Accent = Color(0xFFB9FF4A)
private val Blue = Color(0xFF67B7FF)
private val Purple = Color(0xFFB894FF)
private val Cyan = Color(0xFF55E6D2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        scheduleBackgroundSync(this)
        setContent { BodySyncApp() }
    }
}

private enum class MetricKey(val title: String, val icon: String, val column: String, val unit: String, val decimals: Int = 0) {
    STEPS("Schritte", "👣", "steps", "Schritte"),
    HR("Herzfrequenz", "❤️", "heart_rate_avg", "bpm"),
    RHR("Ruhepuls", "❤️", "resting_heart_rate", "bpm"),
    HRV("HRV", "💓", "hrv_ms", "ms"),
    RESP("Atemfrequenz", "🌬️", "respiratory_rate", "/min", 1),
    ACTIVE_CAL("Aktive Kalorien", "🔥", "active_calories", "kcal"),
    TOTAL_CAL("Gesamtkalorien", "🔥", "total_calories", "kcal"),
    REST_CAL("Ruhekalorien", "🧘", "resting_calories", "kcal"),
    SLEEP("Schlaf", "😴", "sleep_minutes", "Minuten"),
    WEIGHT("Gewicht", "⚖️", "weight_kg", "kg", 1),
    FAT("Körperfett", "🧈", "body_fat_percent", "%", 1),
    LEAN("Magermasse", "💪", "lean_body_mass_kg", "kg", 1),
    WATER("Körperwasser", "💧", "body_water_kg", "kg", 1),
    BONE("Knochenmasse", "🦴", "bone_mass_kg", "kg", 1),
    SPO2("SpO₂", "🫁", "oxygen_percent", "%", 1),
    VO2("VO₂max", "🫀", "vo2_max", "ml/kg/min", 1),
    DISTANCE("Distanz", "🚶", "distance_km", "km", 1),
    SKIN_TEMP("Hauttemperatur", "🌡️", "skin_temperature_delta", "°C", 2),
    WORKOUTS("Training", "⚡", "workout_count", "Einheiten")
}

private enum class Tab(val label: String, val icon: String) {
    TODAY("Heute", "⌂"), HEALTH("Health", "♥"), TRAINING("Training", "⚡"), ANALYSIS("Analyse", "◔"), MORE("Mehr", "•••")
}

@Composable
fun BodySyncApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf(Tab.TODAY) }
    var manager by remember { mutableStateOf<HealthConnectManager?>(null) }
    var snapshot by remember { mutableStateOf<HealthSnapshot?>(null) }
    var selectedWorkout by remember { mutableStateOf<WorkoutSummary?>(null) }
    var selectedMetric by remember { mutableStateOf<MetricKey?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var availability by remember { mutableStateOf(HealthConnectClient.SDK_UNAVAILABLE) }
    var permissionState by remember { mutableStateOf("Noch nicht verbunden") }

    BackHandler(enabled = selectedWorkout != null || selectedMetric != null) {
        if (selectedWorkout != null) selectedWorkout = null else selectedMetric = null
    }

    val permissionLauncher = rememberLauncherForActivityResult(PermissionController.createRequestPermissionResultContract()) {
        scope.launch { manager?.let { m -> permissionState = permissionStatus(m); if (permissionState != "Nicht verbunden") loadSnapshot(m, { loading = it }, { error = it }) { snapshot = it } } }
    }

    fun connect() = scope.launch {
        availability = HealthConnectManager.availability(context)
        if (availability != HealthConnectClient.SDK_AVAILABLE) { openHealthConnectStore(context); return@launch }
        val m = runCatching { HealthConnectManager.create(context) }.getOrNull()
        manager = m
        if (m == null) { error = "Health Connect konnte nicht gestartet werden."; return@launch }
        permissionLauncher.launch(m.permissions + "android.permission.health.READ_HEALTH_DATA_IN_BACKGROUND")
    }

    fun refresh() = scope.launch {
        availability = HealthConnectManager.availability(context)
        if (availability != HealthConnectClient.SDK_AVAILABLE) { permissionState = "Health Connect nicht verfügbar"; return@launch }
        val m = manager ?: runCatching { HealthConnectManager.create(context) }.getOrNull()
        manager = m
        if (m == null) { error = "Health Connect konnte nicht gestartet werden."; return@launch }
        permissionState = permissionStatus(m)
        if (permissionState != "Nicht verbunden") loadSnapshot(m, { loading = it }, { error = it }) { snapshot = it }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_RESUME) refresh() }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    LaunchedEffect(Unit) { refresh() }

    Scaffold(containerColor = Bg, bottomBar = {
        NavigationBar(containerColor = Color(0xFF10151C)) {
            Tab.values().forEach { tab ->
                NavigationBarItem(selected = selected == tab, onClick = { selected = tab; selectedWorkout = null }, icon = { Text(tab.icon, fontSize = 19.sp) }, label = { Text(tab.label) })
            }
        }
    }) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            if (selectedWorkout != null) SwipeBackContainer(onBack = { selectedWorkout = null }) { WorkoutDetail(selectedWorkout!!, onBack = { selectedWorkout = null }) }
            else if (selectedMetric != null) SwipeBackContainer(onBack = { selectedMetric = null }) { HistoryDetail(selectedMetric!!, context, onBack = { selectedMetric = null }) }
            else when (selected) {
                Tab.TODAY -> TodayScreen(snapshot, permissionState, loading, error, ::connect, ::refresh, onWorkout = { selected = Tab.TRAINING; selectedWorkout = it }, onMetric = { selectedMetric = it })
                Tab.HEALTH -> HealthScreen(snapshot, loading, ::refresh, onMetric = { selectedMetric = it })
                Tab.TRAINING -> TrainingScreen(snapshot, onWorkout = { selectedWorkout = it })
                Tab.ANALYSIS -> AnalysisScreen(snapshot)
                Tab.MORE -> MoreScreen(manager, availability, permissionState, permissionLauncher, ::connect, ::refresh, context)
            }
        }
    }
}

private suspend fun permissionStatus(manager: HealthConnectManager): String {
    val granted = manager.grantedPermissions()
    return when { granted.containsAll(manager.permissions) -> "Verbunden"; granted.intersect(manager.permissions).isNotEmpty() -> "Teilweise verbunden"; else -> "Nicht verbunden" }
}

private suspend fun loadSnapshot(manager: HealthConnectManager, setLoading: (Boolean) -> Unit, setError: (String?) -> Unit, setSnapshot: (HealthSnapshot) -> Unit) {
    setLoading(true); setError(null)
    runCatching {
        manager.readSnapshot()
    }.onSuccess { snapshot ->
        setSnapshot(snapshot)
        val history = BodySyncDatabase(managerContext(manager))
        history.saveSnapshot(snapshot)
        history.close()
    }.onFailure { setError(friendlyError(it)) }
    setLoading(false)
}

private fun managerContext(manager: HealthConnectManager): Context = manager.contextForHistory()

private fun scheduleBackgroundSync(context: Context) {
    val request = PeriodicWorkRequestBuilder<HealthSyncWorker>(15, TimeUnit.MINUTES).build()
    WorkManager.getInstance(context).enqueueUniquePeriodicWork("BodySyncHealthSync", ExistingPeriodicWorkPolicy.KEEP, request)
}

@Composable private fun AppHeader(title: String, subtitle: String? = null) {
    Text(title, color = TextMain, fontSize = 32.sp, fontWeight = FontWeight.Bold)
    subtitle?.let { Text(it, color = Muted, fontSize = 14.sp) }
    Spacer(Modifier.height(18.dp))
}

@Composable private fun DailyRingsCard(snapshot: HealthSnapshot?) {
    val steps = ((snapshot?.steps ?: 0L) / 10000f).coerceIn(0f, 1f)
    val sleep = ((snapshot?.sleep?.totalMinutes ?: 0L) / 480f).coerceIn(0f, 1f)
    val trainingMinutes = (snapshot?.workoutList?.filter { it.start.atZone(ZoneId.systemDefault()).toLocalDate() == java.time.LocalDate.now() }?.sumOf { it.durationMinutes } ?: 0L)
    val training = (trainingMinutes / 30f).coerceIn(0f, 1f)
    Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(26.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text("TAGESRINGE", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                StatusRing(steps, "Aktivität", "${snapshot?.steps ?: 0} Schritte", Accent)
                StatusRing(sleep, "Schlaf", snapshot?.sleep?.let { formatSleep(it.totalMinutes) } ?: "—", Blue)
                StatusRing(training, "Training", "${trainingMinutes} min", Purple)
            }
        }
    }
}

@Composable private fun StatusRing(progress: Float, label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(100.dp)) {
        Box(Modifier.size(82.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                drawArc(Card2, -90f, 360f, false, style = androidx.compose.ui.graphics.drawscope.Stroke(10f))
                drawArc(color, -90f, 360f * progress, false, style = androidx.compose.ui.graphics.drawscope.Stroke(10f, cap = androidx.compose.ui.graphics.StrokeCap.Round))
            }
            Text("${(progress * 100).roundToInt()}%", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(6.dp))
        Text(label, color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Text(value, color = Muted, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable private fun FitnessAgeCard() {
    Card(colors = CardDefaults.cardColors(Card2), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("🧬", fontSize = 30.sp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Fitnessalter", color = Muted, fontSize = 12.sp)
                Text("Noch nicht berechnet", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Wird mit persönlicher Basislinie und mehr Verlauf aufgebaut.", color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable private fun TodayScreen(snapshot: HealthSnapshot?, permissionState: String, loading: Boolean, error: String?, onConnect: () -> Unit, onRefresh: () -> Unit, onWorkout: (WorkoutSummary) -> Unit, onMetric: (MetricKey) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), contentPadding = PaddingValues(top = 20.dp, bottom = 30.dp)) {
        item { AppHeader("Guten Morgen 👋", "Dein Body-Sync Überblick") }
        item { DailyRingsCard(snapshot) }
        item { Spacer(Modifier.height(14.dp)); FitnessAgeCard() }
        item { Spacer(Modifier.height(18.dp)); SectionTitle("Heute") }
        item {
            MetricGrid(listOf(
                { m -> MetricCard("👣", "Schritte", snapshot?.steps?.formatNumber() ?: "—", Accent, m) { onMetric(MetricKey.STEPS) } },
                { m -> MetricCard("🔥", "Gesamt", snapshot?.totalCalories?.let { "$it kcal" } ?: "—", Color(0xFFFF9D5C), m) { onMetric(MetricKey.TOTAL_CAL) } },
                { m -> MetricCard("⚡", "Aktiv", snapshot?.activeCalories?.let { "$it kcal" } ?: "—", Color(0xFFFF9D5C), m) { onMetric(MetricKey.ACTIVE_CAL) } },
                { m -> MetricCard("🧘", "Ruhe", snapshot?.restingCalories?.let { "$it kcal" } ?: "—", Purple, m) { onMetric(MetricKey.REST_CAL) } },
                { m -> MetricCard("❤️", "Ruhepuls", snapshot?.restingHeartRate?.let { "$it bpm" } ?: "—", Color(0xFFFF6B7A), m) { onMetric(MetricKey.RHR) } },
                { m -> MetricCard("💓", "HRV", snapshot?.hrvMs?.let { "%.0f ms".format(it) } ?: "—", Purple, m) { onMetric(MetricKey.HRV) } },
                { m -> MetricCard("😴", "Schlaf", snapshot?.sleep?.let { formatSleep(it.totalMinutes) } ?: "—", Blue, m) { onMetric(MetricKey.SLEEP) } },
                { m -> MetricCard("🏃", "Strecke", snapshot?.distanceKm?.let { "%.1f km".format(it) } ?: "—", Cyan, m) { onMetric(MetricKey.DISTANCE) } }
            ))
        }
        item { Spacer(Modifier.height(18.dp)); SectionTitle("Letzter Schlaf") }
        item { Spacer(Modifier.height(10.dp)); SleepCard(snapshot?.sleep) }
        item { Spacer(Modifier.height(18.dp)); SectionTitle("Letzte Aktivitäten") }
        items(snapshot?.workoutList?.take(5) ?: emptyList()) { WorkoutCard(it, onWorkout) }
        if (loading) item { Spacer(Modifier.height(12.dp)); LinearProgressIndicator(Modifier.fillMaxWidth()) }
        if (error != null) item { Spacer(Modifier.height(12.dp)); Text(error, color = Color(0xFFFF8E9A)) }
    }
}

@Composable private fun ConnectionCard(status: String, onConnect: () -> Unit, onRefresh: () -> Unit) {
    Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(26.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Text("●", color = if (status == "Verbunden") Accent else Color(0xFFFFB45C), fontSize = 18.sp); Spacer(Modifier.width(10.dp)); Column { Text("Health Connect", color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.SemiBold); Text(status, color = Muted, fontSize = 13.sp) } }
            Spacer(Modifier.height(14.dp))
            if (status == "Nicht verbunden") Button(onClick = onConnect, colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.Black), modifier = Modifier.fillMaxWidth()) { Text("Health Connect verbinden", fontWeight = FontWeight.Bold) }
            else OutlinedButton(onClick = onRefresh, modifier = Modifier.fillMaxWidth()) { Text("Synchronisieren") }
        }
    }
}

@Composable private fun HealthScreen(snapshot: HealthSnapshot?, loading: Boolean, onRefresh: () -> Unit, onMetric: (MetricKey) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), contentPadding = PaddingValues(bottom = 30.dp)) {
        item { AppHeader("Health", "Deine wichtigsten Körperdaten") }
        item { HealthHero(snapshot) }
        item { Spacer(Modifier.height(18.dp)); SectionTitle("Körper & Kreislauf") }
        item {
            MetricGrid(listOf(
                { m -> MetricCard("⚖️", "Gewicht", snapshot?.weightKg?.let { "%.1f kg".format(it) } ?: "—", Accent, m) { onMetric(MetricKey.WEIGHT) } },
                { m -> MetricCard("🫁", "SpO₂", snapshot?.oxygenPercent?.let { "%.0f %%".format(it) } ?: "—", Cyan, m) { onMetric(MetricKey.SPO2) } },
                { m -> MetricCard("🫀", "VO₂max", snapshot?.vo2Max?.let { "%.1f".format(it) } ?: "—", Blue, m) { onMetric(MetricKey.VO2) } },
                { m -> MetricCard("🌬️", "Atemfrequenz", snapshot?.respiratoryRate?.let { "%.1f/min".format(it) } ?: "—", Purple, m) { onMetric(MetricKey.RESP) } },
                { m -> MetricCard("📏", "Größe", snapshot?.heightCm?.let { "%.0f cm".format(it) } ?: "—", Color(0xFFFFB45C), m) },
                { m -> MetricCard("❤️", "Ø Puls", snapshot?.heartRateAvg?.let { "$it bpm" } ?: "—", Color(0xFFFF6B7A), m) { onMetric(MetricKey.HR) } },
                { m -> MetricCard("🌡️", "Hauttemperatur", snapshot?.skinTemperatureDelta?.let { "${if (it >= 0) "+" else ""}${"%.2f".format(it)} °C" } ?: "—", Color(0xFFFFB45C), m) { onMetric(MetricKey.SKIN_TEMP) } }
            ))
        }
        item { Spacer(Modifier.height(18.dp)); SectionTitle("Schlaf") }
        item { Spacer(Modifier.height(10.dp)); SleepCard(snapshot?.sleep, large = true) }
        item { Spacer(Modifier.height(18.dp)); InfoCard("Letzte Synchronisierung", snapshot?.lastSync?.let { formatSyncTime(it) } ?: "—", "Health Connect wird automatisch im Hintergrund aktualisiert") }
        if (loading) item { Spacer(Modifier.height(12.dp)); LinearProgressIndicator(Modifier.fillMaxWidth()) }
        item { Spacer(Modifier.height(18.dp)); OutlinedButton(onClick = onRefresh, modifier = Modifier.fillMaxWidth()) { Text("Daten aktualisieren") } }
    }
}

@Composable private fun HealthHero(snapshot: HealthSnapshot?) {
    Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(22.dp)) {
            Text("HEUTE", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(snapshot?.steps?.let { "${it.formatNumber()} Schritte" } ?: "Noch keine Tagesdaten", color = TextMain, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("${snapshot?.totalCalories?.let { "$it gesamt" } ?: "— gesamt"}  ·  ${snapshot?.activeCalories?.let { "$it aktiv" } ?: "— aktiv"}  ·  ${snapshot?.restingCalories?.let { "$it Ruhe" } ?: "— Ruhe"}  ·  ${snapshot?.distanceKm?.let { "%.1f km".format(it) } ?: "— km"}", color = Muted, fontSize = 14.sp)
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MiniPill("Ruhepuls", snapshot?.restingHeartRate?.let { "$it bpm" } ?: "—", Color(0xFFFF6B7A), Modifier.weight(1f))
                MiniPill("HRV", snapshot?.hrvMs?.let { "%.0f ms".format(it) } ?: "—", Purple, Modifier.weight(1f))
                MiniPill("Training", snapshot?.workouts?.toString() ?: "—", Blue, Modifier.weight(1f))
            }
        }
    }
}

@Composable private fun MiniPill(label: String, value: String, color: Color, modifier: Modifier) {
    Card(colors = CardDefaults.cardColors(Card2), shape = RoundedCornerShape(16.dp), modifier = modifier) {
        Column(Modifier.padding(12.dp)) { Text(value, color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold); Text(label, color = color, fontSize = 10.sp, fontWeight = FontWeight.SemiBold) }
    }
}

@Composable private fun TrainingScreen(snapshot: HealthSnapshot?, onWorkout: (WorkoutSummary) -> Unit) {
    val workouts = snapshot?.workoutList ?: emptyList()
    val now = Instant.now()
    val weekStart = now.minusSeconds(7L * 24L * 60L * 60L)
    val week = workouts.filter { it.start.isAfter(weekStart) }
    val weekMinutes = week.sumOf { it.durationMinutes }
    val weekDistance = week.sumOf { it.distanceKm ?: 0.0 }
    val weekCalories = week.sumOf { it.calories ?: 0.0 }
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), contentPadding = PaddingValues(bottom = 30.dp)) {
        item { AppHeader("Training", "Deine letzten Einheiten") }
        item { TrainingSummary(week.size, weekMinutes, weekDistance, weekCalories) }
        item { Spacer(Modifier.height(20.dp)); SectionTitle("Aktivitäten") }
        if (workouts.isEmpty()) item { Spacer(Modifier.height(10.dp)); EmptyCard("Noch keine Trainingsdaten gefunden") }
        items(workouts) { WorkoutCard(it, onWorkout) }
    }
}

@Composable private fun TrainingSummary(count: Int, minutes: Long, distance: Double, calories: Double) {
    Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(26.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Text("LETZTE 7 TAGE", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SummaryStat("$count", "Einheiten", Modifier.weight(1f)); SummaryStat(formatDuration(minutes), "Zeit", Modifier.weight(1f)); SummaryStat("%.1f km".format(distance), "Distanz", Modifier.weight(1f)); SummaryStat("%.0f".format(calories), "kcal", Modifier.weight(1f))
            }
        }
    }
}

@Composable private fun SummaryStat(value: String, label: String, modifier: Modifier) { Column(modifier) { Text(value, color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text(label, color = Muted, fontSize = 10.sp) } }

@Composable private fun WorkoutCard(workout: WorkoutSummary, onClick: (WorkoutSummary) -> Unit) {
    Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { onClick(workout) }) {
        Column(Modifier.padding(17.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Text(workoutIcon(workout.type), fontSize = 28.sp); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(workout.type, color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.SemiBold); Text(workout.start.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("dd.MM. · HH:mm")), color = Muted, fontSize = 12.sp) }; Text("›", color = Accent, fontSize = 28.sp) }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) { SmallStat(formatDuration(workout.durationMinutes), "Dauer"); workout.distanceKm?.let { SmallStat("%.1f km".format(it), "Distanz") }; workout.avgPowerW?.let { SmallStat("%.0f W".format(it), "Ø Leistung") }; workout.avgHeartRate?.let { SmallStat("$it", "Ø Puls") } }
        }
    }
}

@Composable private fun WorkoutDetail(workout: WorkoutSummary, onBack: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), contentPadding = PaddingValues(bottom = 30.dp)) {
        item { Text("‹  Zurück", color = Accent, modifier = Modifier.clickable { onBack() }.padding(vertical = 8.dp)); Spacer(Modifier.height(10.dp)); Text(workoutIcon(workout.type), fontSize = 46.sp); Text(workout.type, color = TextMain, fontSize = 34.sp, fontWeight = FontWeight.Bold); Text(workout.start.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("EEEE, dd.MM.yyyy · HH:mm")), color = Muted); Spacer(Modifier.height(20.dp)) }
        item { DetailHero(workout) }
        item { Spacer(Modifier.height(18.dp)); SectionTitle("Leistung & Belastung") }
        item { Spacer(Modifier.height(10.dp)); DetailGrid(workout) }
        item { Spacer(Modifier.height(18.dp)); Text("Quelle", color = Muted, fontSize = 12.sp); Text(sourceName(workout.source), color = TextMain, fontSize = 15.sp) }
    }
}

@Composable private fun DetailHero(w: WorkoutSummary) { Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(26.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(22.dp)) { Text(w.distanceKm?.let { "%.2f km".format(it) } ?: formatDuration(w.durationMinutes), color = TextMain, fontSize = 36.sp, fontWeight = FontWeight.Bold); Text("${formatDuration(w.durationMinutes)} · ${w.avgSpeedKmh?.let { "%.1f km/h".format(it) } ?: "Training"}", color = Muted); Spacer(Modifier.height(16.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { DetailMetric("Ø Puls", w.avgHeartRate?.let { "$it bpm" } ?: "—", Modifier.weight(1f)); DetailMetric("Kalorien", w.calories?.let { "%.0f".format(it) } ?: "—", Modifier.weight(1f)) } } } }

@Composable private fun DetailGrid(w: WorkoutSummary) { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { DetailMetric("Ø Leistung", w.avgPowerW?.let { "%.0f W".format(it) } ?: "—", Modifier.weight(1f)); DetailMetric("Max Leistung", w.maxPowerW?.let { "%.0f W".format(it) } ?: "—", Modifier.weight(1f)) }; Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { DetailMetric("Ø Puls", w.avgHeartRate?.let { "$it bpm" } ?: "—", Modifier.weight(1f)); DetailMetric("Max Puls", w.maxHeartRate?.let { "$it bpm" } ?: "—", Modifier.weight(1f)) }; Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { DetailMetric("Höhenmeter", w.elevationM?.let { "%.0f m".format(it) } ?: "—", Modifier.weight(1f)); DetailMetric("Kalorien", w.calories?.let { "%.0f kcal".format(it) } ?: "—", Modifier.weight(1f)) }; Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { DetailMetric("Kadenz", w.avgCadenceRpm?.let { "%.0f rpm".format(it) } ?: "—", Modifier.weight(1f)); DetailMetric("Max Speed", w.maxSpeedKmh?.let { "%.1f km/h".format(it) } ?: "—", Modifier.weight(1f)) } } }

@Composable private fun AnalysisScreen(snapshot: HealthSnapshot?) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val workouts = snapshot?.workoutList ?: emptyList()
    val now = Instant.now()
    val week = workouts.filter { it.start.isAfter(now.minusSeconds(7L * 24L * 60L * 60L)) }
    val trainingMinutes = week.sumOf { it.durationMinutes }
    val trainingCalories = week.sumOf { it.calories ?: 0.0 }
    ReadinessAnalysisContent(snapshot, context, week.size, trainingMinutes, trainingCalories)
}

@Composable private fun ReadinessAnalysisContent(snapshot: HealthSnapshot?, context: Context, workoutCount: Int, trainingMinutes: Long, trainingCalories: Double) {
    var score by remember { mutableStateOf<Int?>(null) }
    var explanation by remember { mutableStateOf("Persönliche Basislinie wird aufgebaut.") }
    LaunchedEffect(snapshot?.lastSync) {
        val db = BodySyncDatabase(context)
        val history = withContext(Dispatchers.IO) { db.history("hrv_ms", 30) }
        val rhrHistory = withContext(Dispatchers.IO) { db.history("resting_heart_rate", 30) }
        val tempHistory = withContext(Dispatchers.IO) { db.history("skin_temperature_delta", 30) }
        db.close()
        val result = calculateReadiness(snapshot, history.map { it.value }, rhrHistory.map { it.value }, tempHistory.map { it.value })
        score = result.first; explanation = result.second
    }
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), contentPadding = PaddingValues(bottom = 30.dp)) {
        item { AppHeader("Analyse", "Deine persönliche Tagesform & Trends") }
        item { ReadinessHero(score, explanation) }
        item { Spacer(Modifier.height(14.dp)); InsightCard("🌡️ Vitals", snapshot?.skinTemperatureDelta?.let { "${if (it >= 0) "+" else ""}${"%.2f".format(it)} °C" } ?: "Keine Hauttemperatur", "Hauttemperatur wird als Trend gegenüber deiner persönlichen Basislinie betrachtet.", Color(0xFFFFB45C)) }
        item { Spacer(Modifier.height(12.dp)); InsightCard("Schlaf", snapshot?.sleep?.let { formatSleep(it.totalMinutes) } ?: "Keine Nacht gefunden", "Schlafdauer und Schlafphasen fließen in die Tagesform ein.", Cyan) }
        item { Spacer(Modifier.height(12.dp)); InsightCard("Cardio", snapshot?.vo2Max?.let { "VO₂max %.1f".format(it) } ?: "Noch keine VO₂max", "Herz-Kreislauf-Daten aus Health Connect.", Blue) }
        item { Spacer(Modifier.height(12.dp)); InsightCard("Training", "$trainingMinutes min", "Letzte 7 Tage · $workoutCount Einheiten · ${"%.0f".format(trainingCalories)} Trainings-kcal", Purple) }
        item { Spacer(Modifier.height(12.dp)); InfoCard("KI-Analyse", "Persönliche Muster statt starre Grenzwerte", "Body Sync baut zuerst deine eigene Basislinie auf. Die Analyse kann später um ein echtes Sprachmodell erweitert werden.") }
    }
}

@Composable private fun ReadinessHero(score: Int?, explanation: String) {
    val value = score ?: 0
    val label = when { value >= 80 -> "Sehr gute Tagesform"; value >= 65 -> "Gute Tagesform"; value >= 50 -> "Mittlere Tagesform"; value >= 35 -> "Heute etwas ruhiger"; else -> "Regeneration im Fokus" }
    val color = when { value >= 65 -> Accent; value >= 50 -> Color(0xFFFFD166); value >= 35 -> Color(0xFFFFB45C); else -> Color(0xFFFF6B7A) }
    Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(22.dp)) {
            Text("TAGESFORM", color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.Bottom) { Text(if (score == null) "—" else "$value", color = TextMain, fontSize = 52.sp, fontWeight = FontWeight.Bold); Text(" / 100", color = Muted, fontSize = 18.sp, modifier = Modifier.padding(bottom = 8.dp)) }
            Text(label, color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp)); Text(explanation, color = Muted, fontSize = 13.sp)
        }
    }
}

private fun calculateReadiness(snapshot: HealthSnapshot?, hrvHistory: List<Double>, rhrHistory: List<Double>, tempHistory: List<Double>): Pair<Int, String> {
    if (snapshot == null) return 0 to "Noch keine Gesundheitsdaten verfügbar."
    var score = 70.0
    val notes = mutableListOf<String>()
    snapshot.sleep?.totalMinutes?.let {
        when { it >= 450 -> score += 10; it >= 360 -> score += 3; it < 300 -> { score -= 15; notes += "deutlich weniger Schlaf" } }
    }
    snapshot.hrvMs?.let { current ->
        val baseline = hrvHistory.filter { it > 0 }.averageOrNull()
        if (baseline != null) { val ratio = current / baseline; when { ratio >= 1.05 -> score += 8; ratio < 0.85 -> { score -= 12; notes += "HRV unter deiner Basislinie" } } }
    }
    snapshot.restingHeartRate?.let { current ->
        val baseline = rhrHistory.filter { it > 0 }.averageOrNull()
        if (baseline != null) { val delta = current - baseline; when { delta <= -2 -> score += 5; delta >= 5 -> { score -= 12; notes += "Ruhepuls über deiner Basislinie" } } }
    }
    snapshot.skinTemperatureDelta?.let { current ->
        val baseline = tempHistory.averageOrNull()
        if (baseline != null) { val delta = current - baseline; if (delta >= 0.25) { score -= 10; notes += "Hauttemperatur über deinem üblichen Trend" } else if (delta <= -0.2) score += 2 }
    }
    snapshot.respiratoryRate?.let { current ->
        val baseline = 14.0
        if (current >= baseline + 2.5) { score -= 7; notes += "Atemfrequenz erhöht" }
    }
    val final = score.coerceIn(0.0, 100.0).roundToInt()
    val text = when { notes.isEmpty() -> "Mehrere Werte wirken heute unauffällig. Trainiere nach Gefühl und Belastbarkeit."; notes.size == 1 -> "Heute fällt vor allem ${notes[0]} auf. Eine lockere Einheit kann sinnvoller sein als maximale Intensität."; else -> "Heute fallen ${notes.joinToString(" und ")}. Eher Belastung reduzieren und Regeneration priorisieren." }
    return final to text
}

private fun List<Double>.averageOrNull(): Double? = if (isEmpty()) null else average()

@Composable private fun AnalysisHero(snapshot: HealthSnapshot?, workoutCount: Int, trainingMinutes: Long) {
    Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(22.dp)) {
            Text("BODY SYNC STATUS", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(snapshot?.sleep?.let { formatSleep(it.totalMinutes) } ?: "—", color = TextMain, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Text("letzter Schlaf", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { SummaryStat("$workoutCount", "Workouts / 7T", Modifier.weight(1f)); SummaryStat(formatDuration(trainingMinutes), "Training / 7T", Modifier.weight(1f)); SummaryStat(snapshot?.restingHeartRate?.let { "$it" } ?: "—", "Ruhepuls", Modifier.weight(1f)) }
        }
    }
}

@Composable private fun MoreScreen(manager: HealthConnectManager?, availability: Int, permissionState: String, launcher: androidx.activity.result.ActivityResultLauncher<Set<String>>, connect: () -> Unit, refresh: () -> Unit, context: Context) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), contentPadding = PaddingValues(bottom = 30.dp)) {
        item { AppHeader("Mehr", "Einstellungen & Datenquellen") }
        item { InfoCard("Health Connect", permissionState, "Verbindung und Berechtigungen") }
        if (permissionState == "Nicht verbunden" || permissionState == "Noch nicht verbunden") {
            item { Spacer(Modifier.height(10.dp)); Button(onClick = connect, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.Black)) { Text("Health Connect verbinden", fontWeight = FontWeight.Bold) } }
        }
        item { Spacer(Modifier.height(10.dp)); InfoCard("Synchronisierung", "Automatisch", "Body Sync synchronisiert regelmäßig im Hintergrund · ca. alle 15 Minuten") }
        item { Spacer(Modifier.height(10.dp)); InfoCard("Datenquellen", "Health Connect", "Die Architektur ist vorbereitet für Withings, Wahoo, Strava und Speediance") }
        item { Spacer(Modifier.height(10.dp)); InfoCard("Aktuelle Daten", "Viele Messwerte", "Schritte, Puls, HRV, Schlafphasen, Kalorien, Distanz, SpO₂, VO₂max, Hauttemperatur und Trainingsdetails") }
        item { Spacer(Modifier.height(12.dp)); OutlinedButton(onClick = { manager?.let { launcher.launch(it.permissions + "android.permission.health.READ_HEALTH_DATA_IN_BACKGROUND") } }, modifier = Modifier.fillMaxWidth()) { Text("Health-Connect-Berechtigungen prüfen") } }
        item { Spacer(Modifier.height(10.dp)); OutlinedButton(onClick = refresh, modifier = Modifier.fillMaxWidth()) { Text("Jetzt synchronisieren") } }
    }
}

@Composable private fun SleepCard(sleep: SleepBreakdown?, large: Boolean = false) { Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(if (large) 22.dp else 18.dp)) { if (sleep == null) { Text("Keine Schlafsession gefunden", color = Muted); return@Column }; Text(formatSleep(sleep.totalMinutes), color = TextMain, fontSize = if (large) 34.sp else 28.sp, fontWeight = FontWeight.Bold); Text("${sleep.start.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("HH:mm"))} – ${sleep.end.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("HH:mm"))}", color = Muted); Spacer(Modifier.height(18.dp)); SleepBar(sleep); Spacer(Modifier.height(14.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Stage("Tief", sleep.deepMinutes, Purple); Stage("Leicht", sleep.lightMinutes, Blue); Stage("REM", sleep.remMinutes, Cyan); Stage("Wach", sleep.awakeMinutes, Color(0xFFFFB45C)) } } } }

@Composable private fun SleepBar(s: SleepBreakdown) { val total = (s.deepMinutes+s.lightMinutes+s.remMinutes+s.awakeMinutes).coerceAtLeast(1); Row(Modifier.fillMaxWidth().height(18.dp).background(Card2, RoundedCornerShape(10.dp))) { if (s.deepMinutes>0) Box(Modifier.weight(s.deepMinutes.toFloat()).fillMaxHeight().background(Purple)); if (s.lightMinutes>0) Box(Modifier.weight(s.lightMinutes.toFloat()).fillMaxHeight().background(Blue)); if (s.remMinutes>0) Box(Modifier.weight(s.remMinutes.toFloat()).fillMaxHeight().background(Cyan)); if (s.awakeMinutes>0) Box(Modifier.weight(s.awakeMinutes.toFloat()).fillMaxHeight().background(Color(0xFFFFB45C))) } }

@Composable private fun Stage(label: String, minutes: Long, color: Color) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("●", color = color); Text(label, color = Muted, fontSize = 11.sp); Text(formatSleep(minutes), color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) } }

@Composable private fun BodyCompositionCard(snapshot: HealthSnapshot?) {
    Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("KÖRPERZUSAMMENSETZUNG", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text("Health Connect", color = Muted, fontSize = 10.sp)
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CompositionStat("Fett", snapshot?.bodyFatPercent?.let { "%.1f %%".format(it) } ?: "—", Purple, Modifier.weight(1f))
                CompositionStat("Magermasse", snapshot?.leanBodyMassKg?.let { "%.1f kg".format(it) } ?: "—", Blue, Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CompositionStat("Körperwasser", snapshot?.bodyWaterKg?.let { "%.1f kg".format(it) } ?: "—", Cyan, Modifier.weight(1f))
                CompositionStat("Knochenmasse", snapshot?.boneMassKg?.let { "%.1f kg".format(it) } ?: "—", Color(0xFFFFB45C), Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Text("Wenn Withings diese Werte an Health Connect liefert, übernimmt Body Sync sie automatisch.", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable private fun CompositionStat(label: String, value: String, color: Color, modifier: Modifier) {
    Card(colors = CardDefaults.cardColors(Card2), shape = RoundedCornerShape(16.dp), modifier = modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(value, color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(label, color = color, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable private fun MetricGrid(items: List<@Composable (Modifier) -> Unit>) {
    val wide = LocalConfiguration.current.screenWidthDp >= 600
    val columns = if (wide) 3 else 2
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items.chunked(columns).forEach { rowItems ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                rowItems.forEach { item -> Box(Modifier.weight(1f)) { item(Modifier.fillMaxWidth()) } }
                repeat(columns - rowItems.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable private fun MetricCard(icon: String, label: String, value: String, color: Color, modifier: Modifier, onClick: () -> Unit = {}) {
    val wide = LocalConfiguration.current.screenWidthDp >= 600
    Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(if (wide) 18.dp else 22.dp), modifier = modifier.clickable(onClick = onClick)) {
        Column(Modifier.padding(if (wide) 12.dp else 16.dp)) {
            Text(icon, fontSize = if (wide) 18.sp else 22.sp); Spacer(Modifier.height(if (wide) 5.dp else 8.dp)); Text(value, color = TextMain, fontSize = if (wide) 19.sp else 22.sp, fontWeight = FontWeight.Bold); Text(label, color = Muted, fontSize = if (wide) 11.sp else 12.sp); Spacer(Modifier.height(6.dp)); Box(Modifier.height(3.dp).fillMaxWidth().background(color, RoundedCornerShape(3.dp)))
        }
    }
}
@Composable private fun DetailMetric(label: String, value: String, modifier: Modifier = Modifier) { Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(18.dp), modifier = modifier) { Column(Modifier.padding(16.dp)) { Text(value, color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text(label, color = Muted, fontSize = 12.sp) } } }
@Composable private fun SmallStat(value: String, label: String) { Column { Text(value, color = TextMain, fontWeight = FontWeight.SemiBold, fontSize = 14.sp); Text(label, color = Muted, fontSize = 10.sp) } }
@Composable private fun SectionTitle(text: String) { Text(text, color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
@Composable private fun InfoCard(title: String, value: String, detail: String) { Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) { Text(title, color = Muted, fontSize = 12.sp); Text(value, color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.SemiBold); Text(detail, color = Muted, fontSize = 13.sp) } } }
@Composable private fun InsightCard(title: String, value: String, detail: String, color: Color) { Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp)) { Text(title, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(5.dp)); Text(value, color = TextMain, fontSize = 24.sp, fontWeight = FontWeight.Bold); Text(detail, color = Muted, fontSize = 13.sp) } } }
@Composable private fun EmptyCard(text: String) { Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) { Text(text, color = Muted, modifier = Modifier.padding(20.dp)) } }


@Composable private fun SwipeBackContainer(onBack: () -> Unit, content: @Composable () -> Unit) {
    var drag by remember { mutableStateOf(0f) }
    Box(Modifier.fillMaxSize().pointerInput(Unit) {
        detectHorizontalDragGestures(
            onHorizontalDrag = { _, amount -> if (drag >= 0f || amount > 0f) drag = (drag + amount).coerceAtLeast(0f) },
            onDragEnd = { if (drag > 110f) onBack(); drag = 0f },
            onDragCancel = { drag = 0f }
        )
    }) { content() }
}

@Composable private fun ReadinessCard(snapshot: HealthSnapshot?, context: Context): Unit {
    var score by remember { mutableStateOf<Int?>(null) }
    var text by remember { mutableStateOf("Basislinie wird aufgebaut …") }
    LaunchedEffect(snapshot?.lastSync) {
        val db = BodySyncDatabase(context)
        val hrv = withContext(Dispatchers.IO) { db.history("hrv_ms", 30).map { it.value } }
        val rhr = withContext(Dispatchers.IO) { db.history("resting_heart_rate", 30).map { it.value } }
        val temp = withContext(Dispatchers.IO) { db.history("skin_temperature_delta", 30).map { it.value } }
        db.close()
        val result = calculateReadiness(snapshot, hrv, rhr, temp); score = result.first; text = result.second
    }
    val s = score ?: 0
    Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(26.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Text("TAGESFORM", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (score == null) "—" else "$s", color = TextMain, fontSize = 38.sp, fontWeight = FontWeight.Bold)
                Text(" / 100", color = Muted, fontSize = 15.sp)
                Spacer(Modifier.width(14.dp))
                Column { Text(readinessLabel(s), color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.SemiBold); Text(text, color = Muted, fontSize = 11.sp, maxLines = 2) }
            }
        }
    }
}

private fun readinessLabel(value: Int): String = when { value >= 80 -> "Sehr gute Tagesform"; value >= 65 -> "Gute Tagesform"; value >= 50 -> "Mittlere Tagesform"; value >= 35 -> "Heute etwas ruhiger"; else -> "Regeneration im Fokus" }

@Composable private fun HistoryDetail(metric: MetricKey, context: Context, onBack: () -> Unit) {
    var points by remember(metric) { mutableStateOf<List<BodySyncDatabase.HistoryPoint>>(emptyList()) }
    LaunchedEffect(metric) {
        points = withContext(Dispatchers.IO) { BodySyncDatabase(context).use { it.history(metric.column, 90) } }
    }
    val latest = points.lastOrNull()?.value
    val first = points.firstOrNull()?.value
    val change = if (latest != null && first != null && first != 0.0) ((latest - first) / first) * 100.0 else null
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), contentPadding = PaddingValues(bottom = 30.dp)) {
        item { Row(verticalAlignment = Alignment.CenterVertically) { Text("‹", color = TextMain, fontSize = 34.sp, modifier = Modifier.clickable { onBack() }); Spacer(Modifier.width(10.dp)); Column { Text(metric.title, color = TextMain, fontSize = 28.sp, fontWeight = FontWeight.Bold); Text("Persönlicher Verlauf", color = Muted, fontSize = 13.sp) } } }
        item { Spacer(Modifier.height(18.dp)); Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(26.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp)) { Text(metric.icon, fontSize = 28.sp); Spacer(Modifier.height(8.dp)); Text(latest?.let { formatMetricValue(metric, it) } ?: "Noch keine Historie", color = TextMain, fontSize = 34.sp, fontWeight = FontWeight.Bold); Text(metric.unit, color = Muted); change?.let { Text("${if (it >= 0) "+" else ""}${"%.1f".format(it)} % seit dem ersten gespeicherten Wert", color = if (it >= 0) Accent else Color(0xFFFF9D5C), fontSize = 12.sp) } } } }
        item { Spacer(Modifier.height(14.dp)); Text("Letzte Messungen", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        item { Spacer(Modifier.height(10.dp)); if (points.size >= 2) HistoryChart(points, metric) else EmptyCard("Noch nicht genug gespeicherte Daten für ein Diagramm. Lass Body Sync ein paar Synchronisierungen sammeln.") }
        item { Spacer(Modifier.height(14.dp)); InfoCard("Body Sync erklärt", "Deine persönliche Entwicklung", "Später analysiert Body Sync hier Trends, Veränderungen und Zusammenhänge mit Schlaf, Training, HRV und Erholung.") }
    }
}

@Composable private fun HistoryChart(points: List<BodySyncDatabase.HistoryPoint>, metric: MetricKey) {
    val min = points.minOf { it.value }; val max = points.maxOf { it.value }; val span = (max - min).takeIf { it > 0 } ?: 1.0
    Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("Verlauf · letzte ${points.size} Messungen", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            Canvas(Modifier.fillMaxWidth().height(190.dp)) {
                val left = 12f; val right = size.width - 12f; val top = 12f; val bottom = size.height - 12f
                for (i in 0 until points.lastIndex) {
                    val x1 = left + (right-left) * i / points.lastIndex
                    val x2 = left + (right-left) * (i+1) / points.lastIndex
                    val y1 = bottom - ((points[i].value-min)/span).toFloat() * (bottom-top)
                    val y2 = bottom - ((points[i+1].value-min)/span).toFloat() * (bottom-top)
                    drawLine(Accent, Offset(x1,y1), Offset(x2,y2), 4f, cap = androidx.compose.ui.graphics.StrokeCap.Round)
                    drawCircle(TextMain, 4f, Offset(x1,y1))
                    if (i == points.lastIndex - 1) drawCircle(TextMain, 4f, Offset(x2,y2))
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(formatMetricValue(metric, min), color = Muted, fontSize = 11.sp); Text(formatMetricValue(metric, max), color = Muted, fontSize = 11.sp) }
            Spacer(Modifier.height(10.dp))
            points.takeLast(7).forEach { point ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(point.timestamp.let { Instant.ofEpochMilli(it).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("EEE, dd.MM.")) }, color = Muted, fontSize = 11.sp)
                    Text(formatMetricValue(metric, point.value), color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

private fun formatMetricValue(metric: MetricKey, value: Double): String = when (metric.decimals) {
    0 -> "${value.roundToInt()} ${metric.unit}"
    1 -> "${"%.1f".format(value)} ${metric.unit}"
    else -> "${"%.2f".format(value)} ${metric.unit}"
}

private fun formatSyncTime(instant: Instant): String = instant.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("dd.MM.yyyy · HH:mm:ss"))
private fun sourceName(source: String): String = when {
    source.contains("healthdata") -> "Google Health Connect"
    source.contains("google.android.apps.fitness") -> "Google Fit"
    source.isBlank() -> "Unbekannte Quelle"
    else -> source.substringAfterLast('.')
}
private fun Long.formatNumber(): String = "%,d".format(this)

private fun formatSleep(minutes: Long): String = "${minutes / 60}h ${minutes % 60}m"
private fun formatDuration(minutes: Long): String = "${minutes / 60}h ${minutes % 60}m"
private fun workoutIcon(type: String): String = when { type.contains("Rad") -> "🚴"; type.contains("Lauf") -> "🏃"; type.contains("Schwimm") -> "🏊"; type.contains("Kraft") -> "🏋️"; type.contains("Wand") -> "🥾"; else -> "⚡" }
private fun openHealthConnectStore(context: Context) { val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.apps.healthdata")); context.startActivity(intent) }
private fun friendlyError(t: Throwable): String = t.message ?: "Health-Daten konnten nicht gelesen werden."
