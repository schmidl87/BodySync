# Body Sync v0.5.2

Foundation release for reliable calorie display and local health history.

- Active, resting and total calories use sensible fallbacks when a provider publishes only a subset.
- HRV reads the latest available value from the previous 48 hours.
- A local SQLite history database stores health snapshots during background sync.
- The history layer is the foundation for upcoming clickable metrics, charts, trends and personal analysis.
