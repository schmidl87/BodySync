# Body Sync v0.7.0

## Highlights
- Daily values are bounded to the current calendar day (00:00–24:00) for steps, distance and calories.
- Active, resting and total calories are grouped together on the dashboard.
- History is stored locally and displayed as one point per calendar day.
- History charts show daily values and concrete date/value rows.
- Health Connect status was moved off the Today screen into More.
- Android/system back gesture is supported on workout and metric detail screens via BackHandler.
- Foldable layouts use 3-column compact metric cards on wide screens and 2 columns on narrow screens.
- SpO₂ is read from the latest available record in the last 7 days; VO₂max remains source-dependent.
- A Body Sync daily-rings card was added for activity, sleep and training goals.
- Fitness Age is surfaced as a future model until enough personal baseline data is available.
- A new Body Sync app icon is included.
- Application ID remains `com.bodysync.app`.
- Version code is 15 / version name 0.7.0.
- A stable test signing key is included so future test builds from this project can update the installed app without changing the signing key.

## Important update note
The previous 0.6.0 APK was built with GitHub's temporary debug signing key. Therefore 0.7.0 may require a one-time uninstall/reinstall when moving from 0.6.0 to this stable test-signed build. From 0.7.0 onward, keep the same signing setup and versionCode increments so later APKs can be installed as updates without deleting the local Body Sync history.

The included keystore is for personal/test use only and is not suitable for a public Play Store release. A future Play Store release should use a private signing key stored as a GitHub Actions secret.
