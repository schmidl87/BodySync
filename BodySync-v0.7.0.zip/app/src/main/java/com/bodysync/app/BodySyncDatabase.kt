package com.bodysync.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.time.Instant
import java.time.ZoneId

/** Lightweight local history store. Keeps daily health snapshots independent of Health Connect's retention window. */
class BodySyncDatabase(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE health_snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp INTEGER NOT NULL,
                steps INTEGER,
                heart_rate_avg INTEGER,
                resting_heart_rate INTEGER,
                hrv_ms REAL,
                respiratory_rate REAL,
                active_calories INTEGER,
                total_calories INTEGER,
                resting_calories INTEGER,
                sleep_minutes INTEGER,
                deep_sleep_minutes INTEGER,
                light_sleep_minutes INTEGER,
                rem_sleep_minutes INTEGER,
                awake_minutes INTEGER,
                weight_kg REAL,
                body_fat_percent REAL,
                lean_body_mass_kg REAL,
                body_water_kg REAL,
                bone_mass_kg REAL,
                height_cm REAL,
                oxygen_percent REAL,
                vo2_max REAL,
                distance_km REAL,
                workout_count INTEGER NOT NULL DEFAULT 0,
                source_count INTEGER NOT NULL DEFAULT 0
            )"""
        )
        db.execSQL("CREATE INDEX idx_health_snapshots_timestamp ON health_snapshots(timestamp)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Never delete health history during a normal app update.
        // v2 only changes the application versioning strategy; the existing schema is compatible.
    }

    fun saveSnapshot(snapshot: HealthSnapshot) {
        val values = ContentValues().apply {
            put("timestamp", (snapshot.lastSync?.toEpochMilli() ?: System.currentTimeMillis()))
            snapshot.steps?.let { put("steps", it) }
            snapshot.heartRateAvg?.let { put("heart_rate_avg", it) }
            snapshot.restingHeartRate?.let { put("resting_heart_rate", it) }
            snapshot.hrvMs?.let { put("hrv_ms", it) }
            snapshot.respiratoryRate?.let { put("respiratory_rate", it) }
            snapshot.activeCalories?.let { put("active_calories", it) }
            snapshot.totalCalories?.let { put("total_calories", it) }
            snapshot.restingCalories?.let { put("resting_calories", it) }
            snapshot.sleep?.let {
                put("sleep_minutes", it.totalMinutes)
                put("deep_sleep_minutes", it.deepMinutes)
                put("light_sleep_minutes", it.lightMinutes)
                put("rem_sleep_minutes", it.remMinutes)
                put("awake_minutes", it.awakeMinutes)
            }
            snapshot.weightKg?.let { put("weight_kg", it) }
            snapshot.bodyFatPercent?.let { put("body_fat_percent", it) }
            snapshot.leanBodyMassKg?.let { put("lean_body_mass_kg", it) }
            snapshot.bodyWaterKg?.let { put("body_water_kg", it) }
            snapshot.boneMassKg?.let { put("bone_mass_kg", it) }
            snapshot.heightCm?.let { put("height_cm", it) }
            snapshot.oxygenPercent?.let { put("oxygen_percent", it) }
            snapshot.vo2Max?.let { put("vo2_max", it) }
            snapshot.distanceKm?.let { put("distance_km", it) }
            put("workout_count", snapshot.workouts)
            put("source_count", snapshot.sources)
        }
        writableDatabase.insert("health_snapshots", null, values)
    }

    data class HistoryPoint(val timestamp: Long, val value: Double)

    fun history(metric: String, limit: Int = 90): List<HistoryPoint> {
        val allowed = setOf("steps","heart_rate_avg","resting_heart_rate","hrv_ms","respiratory_rate","active_calories","total_calories","resting_calories","sleep_minutes","weight_kg","body_fat_percent","lean_body_mass_kg","body_water_kg","bone_mass_kg","oxygen_percent","vo2_max","distance_km","workout_count")
        if (metric !in allowed) return emptyList()
        val daily = linkedMapOf<String, HistoryPoint>()
        val c = readableDatabase.query("health_snapshots", arrayOf("timestamp", metric), "$metric IS NOT NULL", null, null, null, "timestamp ASC", null)
        c.use {
            while (it.moveToNext()) {
                val ts = it.getLong(0)
                val date = Instant.ofEpochMilli(ts).atZone(ZoneId.systemDefault()).toLocalDate().toString()
                daily[date] = HistoryPoint(ts, it.getDouble(1))
            }
        }
        return daily.values.takeLast(limit)
    }

    fun availableMetrics(): Set<String> {
        val cols = setOf("steps","heart_rate_avg","resting_heart_rate","hrv_ms","respiratory_rate","active_calories","total_calories","resting_calories","sleep_minutes","weight_kg","body_fat_percent","lean_body_mass_kg","body_water_kg","bone_mass_kg","oxygen_percent","vo2_max","distance_km","workout_count")
        val found = mutableSetOf<String>()
        val c = readableDatabase.rawQuery("SELECT ${cols.joinToString(",") } FROM health_snapshots ORDER BY timestamp DESC LIMIT 30", null)
        c.use { if (it.moveToFirst()) cols.forEachIndexed { i, name -> if (!it.isNull(i)) found += name } }
        return found
    }

    companion object {
        private const val DB_NAME = "bodysync_history.db"
        private const val DB_VERSION = 2
    }
}
