# Body Sync v0.5.0

Body Sync is an Android fitness and health dashboard using Health Connect as the current data hub.

## v0.5.0
- redesigned Health dashboard with more metrics
- active and resting calories visible
- richer training summary for the last 7 days
- improved workout cards and detail view
- clearer source names
- sync timestamp in the app
- more polished Analysis screen
- background Health Connect sync remains enabled

Build with the GitHub Actions workflow supplied with this release.
