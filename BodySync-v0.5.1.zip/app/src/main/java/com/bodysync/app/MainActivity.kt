package com.bodysync.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.launch

private val Bg = Color(0xFF080B10)
private val Card = Color(0xFF121821)
private val Card2 = Color(0xFF18212C)
private val TextMain = Color(0xFFF4F7FA)
private val Muted = Color(0xFF91A0AE)
private val Accent = Color(0xFFB9FF4A)
private val Blue = Color(0xFF67B7FF)
private val Purple = Color(0xFFB894FF)
private val Cyan = Color(0xFF55E6D2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        scheduleBackgroundSync(this)
        setContent { BodySyncApp() }
    }
}

private enum class Tab(val label: String, val icon: String) {
    TODAY("Heute", "⌂"), HEALTH("Health", "♥"), TRAINING("Training", "⚡"), ANALYSIS("Analyse", "◔"), MORE("Mehr", "•••")
}

@Composable
fun BodySyncApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf(Tab.TODAY) }
    var manager by remember { mutableStateOf<HealthConnectManager?>(null) }
    var snapshot by remember { mutableStateOf<HealthSnapshot?>(null) }
    var selectedWorkout by remember { mutableStateOf<WorkoutSummary?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var availability by remember { mutableStateOf(HealthConnectClient.SDK_UNAVAILABLE) }
    var permissionState by remember { mutableStateOf("Noch nicht verbunden") }

    val permissionLauncher = rememberLauncherForActivityResult(PermissionController.createRequestPermissionResultContract()) {
        scope.launch { manager?.let { m -> permissionState = permissionStatus(m); if (permissionState != "Nicht verbunden") loadSnapshot(m, { loading = it }, { error = it }) { snapshot = it } } }
    }

    fun connect() = scope.launch {
        availability = HealthConnectManager.availability(context)
        if (availability != HealthConnectClient.SDK_AVAILABLE) { openHealthConnectStore(context); return@launch }
        val m = runCatching { HealthConnectManager.create(context) }.getOrNull()
        manager = m
        if (m == null) { error = "Health Connect konnte nicht gestartet werden."; return@launch }
        permissionLauncher.launch(m.permissions + "android.permission.health.READ_HEALTH_DATA_IN_BACKGROUND")
    }

    fun refresh() = scope.launch {
        availability = HealthConnectManager.availability(context)
        if (availability != HealthConnectClient.SDK_AVAILABLE) { permissionState = "Health Connect nicht verfügbar"; return@launch }
        val m = manager ?: runCatching { HealthConnectManager.create(context) }.getOrNull()
        manager = m
        if (m == null) { error = "Health Connect konnte nicht gestartet werden."; return@launch }
        permissionState = permissionStatus(m)
        if (permissionState != "Nicht verbunden") loadSnapshot(m, { loading = it }, { error = it }) { snapshot = it }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_RESUME) refresh() }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    LaunchedEffect(Unit) { refresh() }

    Scaffold(containerColor = Bg, bottomBar = {
        NavigationBar(containerColor = Color(0xFF10151C)) {
            Tab.values().forEach { tab ->
                NavigationBarItem(selected = selected == tab, onClick = { selected = tab; selectedWorkout = null }, icon = { Text(tab.icon, fontSize = 19.sp) }, label = { Text(tab.label) })
            }
        }
    }) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            if (selectedWorkout != null) WorkoutDetail(selectedWorkout!!, onBack = { selectedWorkout = null })
            else when (selected) {
                Tab.TODAY -> TodayScreen(snapshot, permissionState, loading, error, ::connect, ::refresh, onWorkout = { selected = Tab.TRAINING; selectedWorkout = it })
                Tab.HEALTH -> HealthScreen(snapshot, loading, ::refresh)
                Tab.TRAINING -> TrainingScreen(snapshot, onWorkout = { selectedWorkout = it })
                Tab.ANALYSIS -> AnalysisScreen(snapshot)
                Tab.MORE -> MoreScreen(manager, availability, permissionState, permissionLauncher, ::refresh, context)
            }
        }
    }
}

private suspend fun permissionStatus(manager: HealthConnectManager): String {
    val granted = manager.grantedPermissions()
    return when { granted.containsAll(manager.permissions) -> "Verbunden"; granted.intersect(manager.permissions).isNotEmpty() -> "Teilweise verbunden"; else -> "Nicht verbunden" }
}

private suspend fun loadSnapshot(manager: HealthConnectManager, setLoading: (Boolean) -> Unit, setError: (String?) -> Unit, setSnapshot: (HealthSnapshot) -> Unit) {
    setLoading(true); setError(null)
    runCatching { manager.readSnapshot() }.onSuccess(setSnapshot).onFailure { setError(friendlyError(it)) }
    setLoading(false)
}

private fun scheduleBackgroundSync(context: Context) {
    val request = PeriodicWorkRequestBuilder<HealthSyncWorker>(15, TimeUnit.MINUTES).build()
    WorkManager.getInstance(context).enqueueUniquePeriodicWork("BodySyncHealthSync", ExistingPeriodicWorkPolicy.KEEP, request)
}

@Composable private fun AppHeader(title: String, subtitle: String? = null) {
    Text(title, color = TextMain, fontSize = 32.sp, fontWeight = FontWeight.Bold)
    subtitle?.let { Text(it, color = Muted, fontSize = 14.sp) }
    Spacer(Modifier.height(18.dp))
}

@Composable private fun TodayScreen(snapshot: HealthSnapshot?, permissionState: String, loading: Boolean, error: String?, onConnect: () -> Unit, onRefresh: () -> Unit, onWorkout: (WorkoutSummary) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), contentPadding = PaddingValues(top = 20.dp, bottom = 30.dp)) {
        item { AppHeader("Guten Morgen 👋", "Dein Body-Sync Überblick") }
        item { ConnectionCard(permissionState, onConnect, onRefresh) }
        item { Spacer(Modifier.height(18.dp)); SectionTitle("Heute") }
        item { Spacer(Modifier.height(10.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricCard("👣", "Schritte", snapshot?.steps?.toString() ?: "—", Accent, Modifier.weight(1f)); MetricCard("🔥", "Kalorien", snapshot?.totalCalories?.let { "$it" } ?: "—", Color(0xFFFF9D5C), Modifier.weight(1f)) } }
        item { Spacer(Modifier.height(10.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricCard("❤️", "Ruhepuls", snapshot?.restingHeartRate?.let { "$it bpm" } ?: "—", Color(0xFFFF6B7A), Modifier.weight(1f)); MetricCard("💓", "HRV", snapshot?.hrvMs?.let { "%.0f ms".format(it) } ?: "—", Purple, Modifier.weight(1f)) } }
        item { Spacer(Modifier.height(10.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricCard("😴", "Schlaf", snapshot?.sleep?.let { formatSleep(it.totalMinutes) } ?: "—", Blue, Modifier.weight(1f)); MetricCard("🚶", "Distanz", snapshot?.distanceKm?.let { "%.1f km".format(it) } ?: "—", Cyan, Modifier.weight(1f)) } }
        item { Spacer(Modifier.height(10.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricCard("⚡", "Aktiv", snapshot?.activeCalories?.let { "$it kcal" } ?: "—", Color(0xFFFF9D5C), Modifier.weight(1f)); MetricCard("🧘", "Ruhe", snapshot?.restingCalories?.let { "$it kcal" } ?: "—", Purple, Modifier.weight(1f)) } }
        item { Spacer(Modifier.height(18.dp)); SectionTitle("Letzter Schlaf") }
        item { Spacer(Modifier.height(10.dp)); SleepCard(snapshot?.sleep) }
        item { Spacer(Modifier.height(18.dp)); SectionTitle("Letzte Aktivitäten") }
        items(snapshot?.workoutList?.take(5) ?: emptyList()) { WorkoutCard(it, onWorkout) }
        if (loading) item { Spacer(Modifier.height(12.dp)); LinearProgressIndicator(Modifier.fillMaxWidth()) }
        if (error != null) item { Spacer(Modifier.height(12.dp)); Text(error, color = Color(0xFFFF8E9A)) }
    }
}

@Composable private fun ConnectionCard(status: String, onConnect: () -> Unit, onRefresh: () -> Unit) {
    Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(26.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Text("●", color = if (status == "Verbunden") Accent else Color(0xFFFFB45C), fontSize = 18.sp); Spacer(Modifier.width(10.dp)); Column { Text("Health Connect", color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.SemiBold); Text(status, color = Muted, fontSize = 13.sp) } }
            Spacer(Modifier.height(14.dp))
            if (status == "Nicht verbunden") Button(onClick = onConnect, colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.Black), modifier = Modifier.fillMaxWidth()) { Text("Health Connect verbinden", fontWeight = FontWeight.Bold) }
            else OutlinedButton(onClick = onRefresh, modifier = Modifier.fillMaxWidth()) { Text("Synchronisieren") }
        }
    }
}

@Composable private fun HealthScreen(snapshot: HealthSnapshot?, loading: Boolean, onRefresh: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), contentPadding = PaddingValues(bottom = 30.dp)) {
        item { AppHeader("Health", "Deine wichtigsten Körperdaten") }
        item { HealthHero(snapshot) }
        item { Spacer(Modifier.height(18.dp)); SectionTitle("Körper & Kreislauf") }
        item { Spacer(Modifier.height(10.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricCard("⚖️", "Gewicht", snapshot?.weightKg?.let { "%.1f kg".format(it) } ?: "—", Accent, Modifier.weight(1f)); MetricCard("🫁", "SpO₂", snapshot?.oxygenPercent?.let { "%.0f %%".format(it) } ?: "—", Cyan, Modifier.weight(1f)) } }
        item { Spacer(Modifier.height(10.dp)); BodyCompositionCard(snapshot) }
        item { Spacer(Modifier.height(10.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricCard("🫀", "VO₂max", snapshot?.vo2Max?.let { "%.1f".format(it) } ?: "—", Blue, Modifier.weight(1f)); MetricCard("🌬️", "Atemfrequenz", snapshot?.respiratoryRate?.let { "%.1f/min".format(it) } ?: "—", Purple, Modifier.weight(1f)) } }
        item { Spacer(Modifier.height(10.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricCard("📏", "Größe", snapshot?.heightCm?.let { "%.0f cm".format(it) } ?: "—", Color(0xFFFFB45C), Modifier.weight(1f)); MetricCard("❤️", "Ø Puls", snapshot?.heartRateAvg?.let { "$it bpm" } ?: "—", Color(0xFFFF6B7A), Modifier.weight(1f)) } }
        item { Spacer(Modifier.height(18.dp)); SectionTitle("Schlaf") }
        item { Spacer(Modifier.height(10.dp)); SleepCard(snapshot?.sleep, large = true) }
        item { Spacer(Modifier.height(18.dp)); InfoCard("Letzte Synchronisierung", snapshot?.lastSync?.let { formatSyncTime(it) } ?: "—", "Health Connect wird automatisch im Hintergrund aktualisiert") }
        if (loading) item { Spacer(Modifier.height(12.dp)); LinearProgressIndicator(Modifier.fillMaxWidth()) }
        item { Spacer(Modifier.height(18.dp)); OutlinedButton(onClick = onRefresh, modifier = Modifier.fillMaxWidth()) { Text("Daten aktualisieren") } }
    }
}

@Composable private fun HealthHero(snapshot: HealthSnapshot?) {
    Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(22.dp)) {
            Text("HEUTE", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(snapshot?.steps?.let { "${it.formatNumber()} Schritte" } ?: "Noch keine Tagesdaten", color = TextMain, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("${snapshot?.activeCalories?.let { "$it aktive kcal" } ?: "— aktive kcal"}  ·  ${snapshot?.distanceKm?.let { "%.1f km".format(it) } ?: "— km"}", color = Muted, fontSize = 14.sp)
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MiniPill("Ruhepuls", snapshot?.restingHeartRate?.let { "$it bpm" } ?: "—", Color(0xFFFF6B7A), Modifier.weight(1f))
                MiniPill("HRV", snapshot?.hrvMs?.let { "%.0f ms".format(it) } ?: "—", Purple, Modifier.weight(1f))
                MiniPill("Training", snapshot?.workouts?.toString() ?: "—", Blue, Modifier.weight(1f))
            }
        }
    }
}

@Composable private fun MiniPill(label: String, value: String, color: Color, modifier: Modifier) {
    Card(colors = CardDefaults.cardColors(Card2), shape = RoundedCornerShape(16.dp), modifier = modifier) {
        Column(Modifier.padding(12.dp)) { Text(value, color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold); Text(label, color = color, fontSize = 10.sp, fontWeight = FontWeight.SemiBold) }
    }
}

@Composable private fun TrainingScreen(snapshot: HealthSnapshot?, onWorkout: (WorkoutSummary) -> Unit) {
    val workouts = snapshot?.workoutList ?: emptyList()
    val now = Instant.now()
    val weekStart = now.minusSeconds(7L * 24L * 60L * 60L)
    val week = workouts.filter { it.start.isAfter(weekStart) }
    val weekMinutes = week.sumOf { it.durationMinutes }
    val weekDistance = week.sumOf { it.distanceKm ?: 0.0 }
    val weekCalories = week.sumOf { it.calories ?: 0.0 }
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), contentPadding = PaddingValues(bottom = 30.dp)) {
        item { AppHeader("Training", "Deine letzten Einheiten") }
        item { TrainingSummary(week.size, weekMinutes, weekDistance, weekCalories) }
        item { Spacer(Modifier.height(20.dp)); SectionTitle("Aktivitäten") }
        if (workouts.isEmpty()) item { Spacer(Modifier.height(10.dp)); EmptyCard("Noch keine Trainingsdaten gefunden") }
        items(workouts) { WorkoutCard(it, onWorkout) }
    }
}

@Composable private fun TrainingSummary(count: Int, minutes: Long, distance: Double, calories: Double) {
    Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(26.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Text("LETZTE 7 TAGE", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SummaryStat("$count", "Einheiten", Modifier.weight(1f)); SummaryStat(formatDuration(minutes), "Zeit", Modifier.weight(1f)); SummaryStat("%.1f km".format(distance), "Distanz", Modifier.weight(1f)); SummaryStat("%.0f".format(calories), "kcal", Modifier.weight(1f))
            }
        }
    }
}

@Composable private fun SummaryStat(value: String, label: String, modifier: Modifier) { Column(modifier) { Text(value, color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text(label, color = Muted, fontSize = 10.sp) } }

@Composable private fun WorkoutCard(workout: WorkoutSummary, onClick: (WorkoutSummary) -> Unit) {
    Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { onClick(workout) }) {
        Column(Modifier.padding(17.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Text(workoutIcon(workout.type), fontSize = 28.sp); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(workout.type, color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.SemiBold); Text(workout.start.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("dd.MM. · HH:mm")), color = Muted, fontSize = 12.sp) }; Text("›", color = Accent, fontSize = 28.sp) }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) { SmallStat(formatDuration(workout.durationMinutes), "Dauer"); workout.distanceKm?.let { SmallStat("%.1f km".format(it), "Distanz") }; workout.avgPowerW?.let { SmallStat("%.0f W".format(it), "Ø Leistung") }; workout.avgHeartRate?.let { SmallStat("$it", "Ø Puls") } }
        }
    }
}

@Composable private fun WorkoutDetail(workout: WorkoutSummary, onBack: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), contentPadding = PaddingValues(bottom = 30.dp)) {
        item { Text("‹  Zurück", color = Accent, modifier = Modifier.clickable { onBack() }.padding(vertical = 8.dp)); Spacer(Modifier.height(10.dp)); Text(workoutIcon(workout.type), fontSize = 46.sp); Text(workout.type, color = TextMain, fontSize = 34.sp, fontWeight = FontWeight.Bold); Text(workout.start.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("EEEE, dd.MM.yyyy · HH:mm")), color = Muted); Spacer(Modifier.height(20.dp)) }
        item { DetailHero(workout) }
        item { Spacer(Modifier.height(18.dp)); SectionTitle("Leistung & Belastung") }
        item { Spacer(Modifier.height(10.dp)); DetailGrid(workout) }
        item { Spacer(Modifier.height(18.dp)); Text("Quelle", color = Muted, fontSize = 12.sp); Text(sourceName(workout.source), color = TextMain, fontSize = 15.sp) }
    }
}

@Composable private fun DetailHero(w: WorkoutSummary) { Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(26.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(22.dp)) { Text(w.distanceKm?.let { "%.2f km".format(it) } ?: formatDuration(w.durationMinutes), color = TextMain, fontSize = 36.sp, fontWeight = FontWeight.Bold); Text("${formatDuration(w.durationMinutes)} · ${w.avgSpeedKmh?.let { "%.1f km/h".format(it) } ?: "Training"}", color = Muted); Spacer(Modifier.height(16.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { DetailMetric("Ø Puls", w.avgHeartRate?.let { "$it bpm" } ?: "—", Modifier.weight(1f)); DetailMetric("Kalorien", w.calories?.let { "%.0f".format(it) } ?: "—", Modifier.weight(1f)) } } } }

@Composable private fun DetailGrid(w: WorkoutSummary) { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { DetailMetric("Ø Leistung", w.avgPowerW?.let { "%.0f W".format(it) } ?: "—", Modifier.weight(1f)); DetailMetric("Max Leistung", w.maxPowerW?.let { "%.0f W".format(it) } ?: "—", Modifier.weight(1f)) }; Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { DetailMetric("Ø Puls", w.avgHeartRate?.let { "$it bpm" } ?: "—", Modifier.weight(1f)); DetailMetric("Max Puls", w.maxHeartRate?.let { "$it bpm" } ?: "—", Modifier.weight(1f)) }; Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { DetailMetric("Höhenmeter", w.elevationM?.let { "%.0f m".format(it) } ?: "—", Modifier.weight(1f)); DetailMetric("Kalorien", w.calories?.let { "%.0f kcal".format(it) } ?: "—", Modifier.weight(1f)) }; Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { DetailMetric("Kadenz", w.avgCadenceRpm?.let { "%.0f rpm".format(it) } ?: "—", Modifier.weight(1f)); DetailMetric("Max Speed", w.maxSpeedKmh?.let { "%.1f km/h".format(it) } ?: "—", Modifier.weight(1f)) } } }

@Composable private fun AnalysisScreen(snapshot: HealthSnapshot?) {
    val workouts = snapshot?.workoutList ?: emptyList()
    val now = Instant.now()
    val week = workouts.filter { it.start.isAfter(now.minusSeconds(7L * 24L * 60L * 60L)) }
    val trainingMinutes = week.sumOf { it.durationMinutes }
    val trainingCalories = week.sumOf { it.calories ?: 0.0 }
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), contentPadding = PaddingValues(bottom = 30.dp)) {
        item { AppHeader("Analyse", "Was deine Daten aktuell zeigen") }
        item { AnalysisHero(snapshot, week.size, trainingMinutes) }
        item { Spacer(Modifier.height(14.dp)); InsightCard("Schlaf", snapshot?.sleep?.let { formatSleep(it.totalMinutes) } ?: "Keine Nacht gefunden", "Letzte Schlafsession · Tief, Leicht, REM und Wach werden getrennt erfasst.", Cyan) }
        item { Spacer(Modifier.height(12.dp)); InsightCard("Cardio", snapshot?.vo2Max?.let { "VO₂max %.1f".format(it) } ?: "Noch keine VO₂max", "Herz-Kreislauf · Body Sync zeigt den aktuell verfügbaren Health-Connect-Wert.", Blue) }
        item { Spacer(Modifier.height(12.dp)); InsightCard("Training", "$trainingMinutes min", "Letzte 7 Tage · ${week.size} Einheiten · ${"%.0f".format(trainingCalories)} Trainings-kcal", Purple) }
        item { Spacer(Modifier.height(12.dp)); InfoCard("Datenbasis", "Health Connect", "Die Analyse verwendet aktuell die Daten, die deine verbundenen Quellen an Health Connect liefern.") }
    }
}

@Composable private fun AnalysisHero(snapshot: HealthSnapshot?, workoutCount: Int, trainingMinutes: Long) {
    Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(22.dp)) {
            Text("BODY SYNC STATUS", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(snapshot?.sleep?.let { formatSleep(it.totalMinutes) } ?: "—", color = TextMain, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Text("letzter Schlaf", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { SummaryStat("$workoutCount", "Workouts / 7T", Modifier.weight(1f)); SummaryStat(formatDuration(trainingMinutes), "Training / 7T", Modifier.weight(1f)); SummaryStat(snapshot?.restingHeartRate?.let { "$it" } ?: "—", "Ruhepuls", Modifier.weight(1f)) }
        }
    }
}

@Composable private fun MoreScreen(manager: HealthConnectManager?, availability: Int, permissionState: String, launcher: androidx.activity.result.ActivityResultLauncher<Set<String>>, refresh: () -> Unit, context: Context) { LazyColumn(Modifier.fillMaxSize().padding(18.dp), contentPadding = PaddingValues(bottom = 30.dp)) { item { AppHeader("Mehr", "Einstellungen & Datenquellen") }; item { InfoCard("Health Connect", permissionState, "Verbindung und Berechtigungen") }; item { Spacer(Modifier.height(10.dp)); InfoCard("Synchronisierung", "Automatisch", "Body Sync synchronisiert regelmäßig im Hintergrund · ca. alle 15 Minuten") }; item { Spacer(Modifier.height(10.dp)); InfoCard("Datenquellen", "Health Connect", "Die Architektur ist vorbereitet für Wahoo, Strava und Speediance") }; item { Spacer(Modifier.height(10.dp)); InfoCard("Aktuelle Daten", "Viele Messwerte", "Schritte, Puls, HRV, Schlafphasen, Kalorien, Distanz, VO₂max und Trainingsdetails") }; item { Spacer(Modifier.height(18.dp)); OutlinedButton(onClick = refresh, modifier = Modifier.fillMaxWidth()) { Text("Jetzt synchronisieren") } } } }

@Composable private fun SleepCard(sleep: SleepBreakdown?, large: Boolean = false) { Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(if (large) 22.dp else 18.dp)) { if (sleep == null) { Text("Keine Schlafsession gefunden", color = Muted); return@Column }; Text(formatSleep(sleep.totalMinutes), color = TextMain, fontSize = if (large) 34.sp else 28.sp, fontWeight = FontWeight.Bold); Text("${sleep.start.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("HH:mm"))} – ${sleep.end.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("HH:mm"))}", color = Muted); Spacer(Modifier.height(18.dp)); SleepBar(sleep); Spacer(Modifier.height(14.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Stage("Tief", sleep.deepMinutes, Purple); Stage("Leicht", sleep.lightMinutes, Blue); Stage("REM", sleep.remMinutes, Cyan); Stage("Wach", sleep.awakeMinutes, Color(0xFFFFB45C)) } } } }

@Composable private fun SleepBar(s: SleepBreakdown) { val total = (s.deepMinutes+s.lightMinutes+s.remMinutes+s.awakeMinutes).coerceAtLeast(1); Row(Modifier.fillMaxWidth().height(18.dp).background(Card2, RoundedCornerShape(10.dp))) { if (s.deepMinutes>0) Box(Modifier.weight(s.deepMinutes.toFloat()).fillMaxHeight().background(Purple)); if (s.lightMinutes>0) Box(Modifier.weight(s.lightMinutes.toFloat()).fillMaxHeight().background(Blue)); if (s.remMinutes>0) Box(Modifier.weight(s.remMinutes.toFloat()).fillMaxHeight().background(Cyan)); if (s.awakeMinutes>0) Box(Modifier.weight(s.awakeMinutes.toFloat()).fillMaxHeight().background(Color(0xFFFFB45C))) } }

@Composable private fun Stage(label: String, minutes: Long, color: Color) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("●", color = color); Text(label, color = Muted, fontSize = 11.sp); Text(formatSleep(minutes), color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) } }

@Composable private fun BodyCompositionCard(snapshot: HealthSnapshot?) {
    Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("KÖRPERZUSAMMENSETZUNG", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text("Health Connect", color = Muted, fontSize = 10.sp)
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CompositionStat("Fett", snapshot?.bodyFatPercent?.let { "%.1f %%".format(it) } ?: "—", Purple, Modifier.weight(1f))
                CompositionStat("Magermasse", snapshot?.leanBodyMassKg?.let { "%.1f kg".format(it) } ?: "—", Blue, Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CompositionStat("Körperwasser", snapshot?.bodyWaterKg?.let { "%.1f kg".format(it) } ?: "—", Cyan, Modifier.weight(1f))
                CompositionStat("Knochenmasse", snapshot?.boneMassKg?.let { "%.1f kg".format(it) } ?: "—", Color(0xFFFFB45C), Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Text("Wenn Withings diese Werte an Health Connect liefert, übernimmt Body Sync sie automatisch.", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable private fun CompositionStat(label: String, value: String, color: Color, modifier: Modifier) {
    Card(colors = CardDefaults.cardColors(Card2), shape = RoundedCornerShape(16.dp), modifier = modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(value, color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(label, color = color, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable private fun MetricCard(icon: String, label: String, value: String, color: Color, modifier: Modifier) { Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(22.dp), modifier = modifier) { Column(Modifier.padding(16.dp)) { Text(icon, fontSize = 22.sp); Spacer(Modifier.height(8.dp)); Text(value, color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text(label, color = Muted, fontSize = 12.sp); Spacer(Modifier.height(7.dp)); Box(Modifier.height(3.dp).fillMaxWidth().background(color, RoundedCornerShape(3.dp))) } } }
@Composable private fun DetailMetric(label: String, value: String, modifier: Modifier = Modifier) { Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(18.dp), modifier = modifier) { Column(Modifier.padding(16.dp)) { Text(value, color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text(label, color = Muted, fontSize = 12.sp) } } }
@Composable private fun SmallStat(value: String, label: String) { Column { Text(value, color = TextMain, fontWeight = FontWeight.SemiBold, fontSize = 14.sp); Text(label, color = Muted, fontSize = 10.sp) } }
@Composable private fun SectionTitle(text: String) { Text(text, color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
@Composable private fun InfoCard(title: String, value: String, detail: String) { Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) { Text(title, color = Muted, fontSize = 12.sp); Text(value, color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.SemiBold); Text(detail, color = Muted, fontSize = 13.sp) } } }
@Composable private fun InsightCard(title: String, value: String, detail: String, color: Color) { Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp)) { Text(title, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(5.dp)); Text(value, color = TextMain, fontSize = 24.sp, fontWeight = FontWeight.Bold); Text(detail, color = Muted, fontSize = 13.sp) } } }
@Composable private fun EmptyCard(text: String) { Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) { Text(text, color = Muted, modifier = Modifier.padding(20.dp)) } }

private fun formatSyncTime(instant: Instant): String = instant.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("dd.MM.yyyy · HH:mm:ss"))
private fun sourceName(source: String): String = when {
    source.contains("healthdata") -> "Google Health Connect"
    source.contains("google.android.apps.fitness") -> "Google Fit"
    source.isBlank() -> "Unbekannte Quelle"
    else -> source.substringAfterLast('.')
}
private fun Long.formatNumber(): String = "%,d".format(this)

private fun formatSleep(minutes: Long): String = "${minutes / 60}h ${minutes % 60}m"
private fun formatDuration(minutes: Long): String = "${minutes / 60}h ${minutes % 60}m"
private fun workoutIcon(type: String): String = when { type.contains("Rad") -> "🚴"; type.contains("Lauf") -> "🏃"; type.contains("Schwimm") -> "🏊"; type.contains("Kraft") -> "🏋️"; type.contains("Wand") -> "🥾"; else -> "⚡" }
private fun openHealthConnectStore(context: Context) { val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.apps.healthdata")); context.startActivity(intent) }
private fun friendlyError(t: Throwable): String = t.message ?: "Health-Daten konnten nicht gelesen werden."
