package com.bodysync.app

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.*
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import kotlin.math.roundToInt

private data class MetricAccumulator(
    var count: Int = 0,
    var sum: Double = 0.0,
) {
    fun add(value: Double) { count++; sum += value }
    fun avg(): Double? = if (count == 0) null else sum / count
}

data class SleepBreakdown(
    val start: Instant,
    val end: Instant,
    val totalMinutes: Long,
    val deepMinutes: Long,
    val lightMinutes: Long,
    val remMinutes: Long,
    val awakeMinutes: Long,
    val source: String
)

data class WorkoutSummary(
    val type: String,
    val start: Instant,
    val end: Instant,
    val durationMinutes: Long,
    val distanceKm: Double? = null,
    val avgSpeedKmh: Double? = null,
    val maxSpeedKmh: Double? = null,
    val avgPowerW: Double? = null,
    val maxPowerW: Double? = null,
    val elevationM: Double? = null,
    val calories: Double? = null,
    val avgHeartRate: Int? = null,
    val maxHeartRate: Int? = null,
    val source: String = "",
    val avgCadenceRpm: Double? = null,
    val maxCadenceRpm: Double? = null
)

data class HealthSnapshot(
    val steps: Long? = null,
    val heartRateAvg: Int? = null,
    val restingHeartRate: Int? = null,
    val hrvMs: Double? = null,
    val respiratoryRate: Double? = null,
    val activeCalories: Int? = null,
    val totalCalories: Int? = null,
    val restingCalories: Int? = null,
    val sleep: SleepBreakdown? = null,
    val weightKg: Double? = null,
    val bodyFatPercent: Double? = null,
    val leanBodyMassKg: Double? = null,
    val bodyWaterKg: Double? = null,
    val boneMassKg: Double? = null,
    val heightCm: Double? = null,
    val oxygenPercent: Double? = null,
    val vo2Max: Double? = null,
    val distanceKm: Double? = null,
    val workouts: Int = 0,
    val sources: Int = 0,
    val lastSync: Instant? = null,
    val workoutList: List<WorkoutSummary> = emptyList()
)

class HealthConnectManager private constructor(private val client: HealthConnectClient) {
    companion object {
        const val PROVIDER_PACKAGE = "com.google.android.apps.healthdata"
        fun availability(context: Context): Int = HealthConnectClient.getSdkStatus(context, PROVIDER_PACKAGE)
        fun create(context: Context): HealthConnectManager = HealthConnectManager(HealthConnectClient.getOrCreate(context))
    }

    val permissions: Set<String> = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(RestingHeartRateRecord::class),
        HealthPermission.getReadPermission(HeartRateVariabilityRmssdRecord::class),
        HealthPermission.getReadPermission(RespiratoryRateRecord::class),
        HealthPermission.getReadPermission(OxygenSaturationRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class),
        HealthPermission.getReadPermission(ExerciseSessionRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getReadPermission(SpeedRecord::class),
        HealthPermission.getReadPermission(PowerRecord::class),
        HealthPermission.getReadPermission(ElevationGainedRecord::class),
        HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(TotalCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(BasalMetabolicRateRecord::class),
        HealthPermission.getReadPermission(WeightRecord::class),
        HealthPermission.getReadPermission(BodyFatRecord::class),
        HealthPermission.getReadPermission(LeanBodyMassRecord::class),
        HealthPermission.getReadPermission(BodyWaterMassRecord::class),
        HealthPermission.getReadPermission(BoneMassRecord::class),
        HealthPermission.getReadPermission(HeightRecord::class),
        HealthPermission.getReadPermission(Vo2MaxRecord::class),
        HealthPermission.getReadPermission(StepsCadenceRecord::class),
        HealthPermission.getReadPermission(CyclingPedalingCadenceRecord::class),
        HealthPermission.getReadPermission(FloorsClimbedRecord::class)
    )

    suspend fun grantedPermissions(): Set<String> = client.permissionController.getGrantedPermissions()

    suspend fun readSnapshot(): HealthSnapshot {
        val now = Instant.now()
        val zone = ZoneId.systemDefault()
        val todayStart = now.atZone(zone).toLocalDate().atStartOfDay(zone).toInstant()
        val dayRange = TimeRangeFilter.between(todayStart, now)
        val historyStart = now.minusSeconds(30L * 24L * 60L * 60L)
        val historyRange = TimeRangeFilter.between(historyStart, now)
        val origins = mutableSetOf<String>()

        fun origin(record: Record) { origins += record.metadata.dataOrigin.packageName }

        var steps = 0L
        var activeKcal = 0.0
        var totalKcal = 0.0
        var distanceKm = 0.0
        var bmrWatts: Double? = null
        val hr = MetricAccumulator()
        val hrv = MetricAccumulator()
        var latestHrv: HeartRateVariabilityRmssdRecord? = null
        val resp = MetricAccumulator()
        val spo2 = MetricAccumulator()
        val resting = MetricAccumulator()

        client.readRecords(ReadRecordsRequest(StepsRecord::class, dayRange)).records.forEach { steps += it.count; origin(it) }
        client.readRecords(ReadRecordsRequest(HeartRateRecord::class, dayRange)).records.forEach { r -> origin(r); r.samples.forEach { hr.add(it.beatsPerMinute.toDouble()) } }
        client.readRecords(ReadRecordsRequest(RestingHeartRateRecord::class, dayRange)).records.forEach { r -> origin(r); resting.add(r.beatsPerMinute.toDouble()) }
        val hrvRange = TimeRangeFilter.between(now.minusSeconds(48L * 60L * 60L), now)
        client.readRecords(ReadRecordsRequest(HeartRateVariabilityRmssdRecord::class, hrvRange)).records.forEach { r ->
            origin(r)
            hrv.add(r.heartRateVariabilityMillis)
            if (latestHrv == null || r.time.isAfter(latestHrv!!.time)) latestHrv = r
        }
        client.readRecords(ReadRecordsRequest(RespiratoryRateRecord::class, dayRange)).records.forEach { r -> origin(r); resp.add(r.rate) }
        client.readRecords(ReadRecordsRequest(OxygenSaturationRecord::class, dayRange)).records.forEach { r -> origin(r); spo2.add(r.percentage.value) }
        client.readRecords(ReadRecordsRequest(ActiveCaloriesBurnedRecord::class, dayRange)).records.forEach { r -> origin(r); activeKcal += r.energy.inKilocalories }
        client.readRecords(ReadRecordsRequest(TotalCaloriesBurnedRecord::class, dayRange)).records.forEach { r -> origin(r); totalKcal += r.energy.inKilocalories }
        client.readRecords(ReadRecordsRequest(DistanceRecord::class, dayRange)).records.forEach { r -> origin(r); distanceKm += r.distance.inKilometers }
        client.readRecords(ReadRecordsRequest(BasalMetabolicRateRecord::class, dayRange)).records.forEach { r -> origin(r); bmrWatts = r.basalMetabolicRate.inWatts }

        val sleeps = client.readRecords(ReadRecordsRequest(SleepSessionRecord::class, TimeRangeFilter.between(now.minusSeconds(48L * 60L * 60L), now))).records
        sleeps.forEach { origin(it) }
        val latestSleep = sleeps.filter { it.endTime.isAfter(now.minusSeconds(36L * 60L * 60L)) }.maxByOrNull { it.endTime }
        val sleep = latestSleep?.let { session ->
            var deep = 0L; var light = 0L; var rem = 0L; var awake = 0L; var sleeping = 0L
            session.stages.forEach { stage ->
                val minutes = Duration.between(stage.startTime, stage.endTime).toMinutes().coerceAtLeast(0)
                when (stage.stage) {
                    SleepSessionRecord.STAGE_TYPE_DEEP -> deep += minutes
                    SleepSessionRecord.STAGE_TYPE_LIGHT -> light += minutes
                    SleepSessionRecord.STAGE_TYPE_REM -> rem += minutes
                    SleepSessionRecord.STAGE_TYPE_AWAKE,
                    SleepSessionRecord.STAGE_TYPE_AWAKE_IN_BED,
                    SleepSessionRecord.STAGE_TYPE_OUT_OF_BED -> awake += minutes
                    SleepSessionRecord.STAGE_TYPE_SLEEPING -> sleeping += minutes
                }
            }
            val total = (deep + light + rem + sleeping).takeIf { it > 0 } ?: Duration.between(session.startTime, session.endTime).toMinutes().coerceAtLeast(0)
            SleepBreakdown(session.startTime, session.endTime, total, deep, light, rem, awake, session.metadata.dataOrigin.packageName)
        }

        var latestWeight: WeightRecord? = null
        var latestBodyFat: BodyFatRecord? = null
        var latestLeanMass: LeanBodyMassRecord? = null
        var latestWaterMass: BodyWaterMassRecord? = null
        var latestBoneMass: BoneMassRecord? = null
        var latestHeight: HeightRecord? = null
        var latestVo2: Vo2MaxRecord? = null
        client.readRecords(ReadRecordsRequest(WeightRecord::class, historyRange)).records.forEach { r -> origin(r); if (latestWeight == null || r.time.isAfter(latestWeight!!.time)) latestWeight = r }
        client.readRecords(ReadRecordsRequest(BodyFatRecord::class, historyRange)).records.forEach { r -> origin(r); if (latestBodyFat == null || r.time.isAfter(latestBodyFat!!.time)) latestBodyFat = r }
        client.readRecords(ReadRecordsRequest(LeanBodyMassRecord::class, historyRange)).records.forEach { r -> origin(r); if (latestLeanMass == null || r.time.isAfter(latestLeanMass!!.time)) latestLeanMass = r }
        client.readRecords(ReadRecordsRequest(BodyWaterMassRecord::class, historyRange)).records.forEach { r -> origin(r); if (latestWaterMass == null || r.time.isAfter(latestWaterMass!!.time)) latestWaterMass = r }
        client.readRecords(ReadRecordsRequest(BoneMassRecord::class, historyRange)).records.forEach { r -> origin(r); if (latestBoneMass == null || r.time.isAfter(latestBoneMass!!.time)) latestBoneMass = r }
        client.readRecords(ReadRecordsRequest(HeightRecord::class, historyRange)).records.forEach { r -> origin(r); if (latestHeight == null || r.time.isAfter(latestHeight!!.time)) latestHeight = r }
        client.readRecords(ReadRecordsRequest(Vo2MaxRecord::class, historyRange)).records.forEach { r -> origin(r); if (latestVo2 == null || r.time.isAfter(latestVo2!!.time)) latestVo2 = r }

        val workouts = client.readRecords(ReadRecordsRequest(ExerciseSessionRecord::class, historyRange)).records.sortedByDescending { it.startTime }
        workouts.forEach { origin(it) }
        val workoutSummaries = workouts.take(50).map { session -> readWorkout(session, ::origin) }

        val restingCalories = bmrWatts?.let { it * 86400.0 / 4184.0 }
        return HealthSnapshot(
            steps = steps.takeIf { it > 0 },
            heartRateAvg = hr.avg()?.roundToInt(),
            restingHeartRate = resting.avg()?.roundToInt(),
            hrvMs = latestHrv?.heartRateVariabilityMillis ?: hrv.avg(),
            respiratoryRate = resp.avg(),
            activeCalories = activeKcal.roundToInt().takeIf { it > 0 },
            totalCalories = totalKcal.roundToInt().takeIf { it > 0 },
            restingCalories = restingCalories?.roundToInt(),
            sleep = sleep,
            weightKg = latestWeight?.weight?.inKilograms,
            bodyFatPercent = latestBodyFat?.percentage?.value,
            leanBodyMassKg = latestLeanMass?.mass?.inKilograms,
            bodyWaterKg = latestWaterMass?.mass?.inKilograms,
            boneMassKg = latestBoneMass?.mass?.inKilograms,
            heightCm = latestHeight?.height?.inMeters?.times(100.0),
            oxygenPercent = spo2.avg(),
            vo2Max = latestVo2?.vo2MillilitersPerMinuteKilogram,
            distanceKm = distanceKm.takeIf { it > 0 },
            workouts = workouts.size,
            sources = origins.size,
            lastSync = now,
            workoutList = workoutSummaries
        )
    }

    private suspend fun readWorkout(session: ExerciseSessionRecord, origin: (Record) -> Unit): WorkoutSummary {
        val range = TimeRangeFilter.between(session.startTime, session.endTime)
        val distances = client.readRecords(ReadRecordsRequest(DistanceRecord::class, range)).records
        val speeds = client.readRecords(ReadRecordsRequest(SpeedRecord::class, range)).records
        val powers = client.readRecords(ReadRecordsRequest(PowerRecord::class, range)).records
        val elevations = client.readRecords(ReadRecordsRequest(ElevationGainedRecord::class, range)).records
        val calories = client.readRecords(ReadRecordsRequest(ActiveCaloriesBurnedRecord::class, range)).records
        val hrs = client.readRecords(ReadRecordsRequest(HeartRateRecord::class, range)).records
        val cadences = client.readRecords(ReadRecordsRequest(CyclingPedalingCadenceRecord::class, range)).records
        distances.forEach(origin); speeds.forEach(origin); powers.forEach(origin); elevations.forEach(origin); calories.forEach(origin); hrs.forEach(origin); cadences.forEach(origin)
        val speedValues = speeds.flatMap { it.samples }.map { it.speed.inMetersPerSecond * 3.6 }
        val powerValues = powers.flatMap { it.samples }.map { it.power.inWatts }
        val hrValues = hrs.flatMap { it.samples }.map { it.beatsPerMinute.toDouble() }
        val cadenceValues = cadences.flatMap { it.samples }.map { it.revolutionsPerMinute.toDouble() }
        return WorkoutSummary(
            type = exerciseTypeName(session.exerciseType), start = session.startTime, end = session.endTime,
            durationMinutes = Duration.between(session.startTime, session.endTime).toMinutes().coerceAtLeast(0),
            distanceKm = distances.sumOf { it.distance.inKilometers }.takeIf { it > 0 },
            avgSpeedKmh = speedValues.takeIf { it.isNotEmpty() }?.average(), maxSpeedKmh = speedValues.maxOrNull(),
            avgPowerW = powerValues.takeIf { it.isNotEmpty() }?.average(), maxPowerW = powerValues.maxOrNull(),
            elevationM = elevations.sumOf { it.elevation.inMeters }.takeIf { it > 0 },
            calories = calories.sumOf { it.energy.inKilocalories }.takeIf { it > 0 },
            avgHeartRate = hrValues.takeIf { it.isNotEmpty() }?.average()?.roundToInt(), maxHeartRate = hrValues.maxOrNull()?.roundToInt(),
            source = session.metadata.dataOrigin.packageName,
            avgCadenceRpm = cadenceValues.takeIf { it.isNotEmpty() }?.average(), maxCadenceRpm = cadenceValues.maxOrNull()
        )
    }

    private fun exerciseTypeName(type: Int): String = when (type) {
        ExerciseSessionRecord.EXERCISE_TYPE_BIKING -> "Radfahren"
        ExerciseSessionRecord.EXERCISE_TYPE_RUNNING -> "Laufen"
        ExerciseSessionRecord.EXERCISE_TYPE_WALKING -> "Gehen"
        ExerciseSessionRecord.EXERCISE_TYPE_HIKING -> "Wandern"
        ExerciseSessionRecord.EXERCISE_TYPE_SWIMMING_POOL -> "Schwimmen"
        ExerciseSessionRecord.EXERCISE_TYPE_STRENGTH_TRAINING -> "Krafttraining"
        ExerciseSessionRecord.EXERCISE_TYPE_ELLIPTICAL -> "Crosstrainer"
        else -> "Training"
    }
}
