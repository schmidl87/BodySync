# Body Sync v0.3.0

Expanded Health Connect integration with:
- broader permissions and metrics
- 30-day health/training read window
- workout details including distance, speed, power, elevation, calories and heart rate where available
- foreground sync on app resume
- WorkManager background sync every 15 minutes when supported and permitted
- manual sync remains available
- foundation for future source prioritization and deduplication
