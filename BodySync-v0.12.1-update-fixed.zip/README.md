# Body Sync v0.12.0

Modern Android fitness/health dashboard using Health Connect.

## v0.12.0
- Personal step goal and weekly training-minute goal in Settings.
- Configurable 4/5 heart-rate zones used in workout analysis.
- Formula-based Sleep Score, Day Form and long-term Fitness Score.
- BMI calculation repaired and separate Body-Composition Score added.
- Expanded workout data: distance, speed, power, elevation, cadence, HR zones, steps and derived step length.
- Health Connect exercise-route permission and foreground route reading for workout route visualization.
- Application ID remains `com.bodysync.app` so updates install over previous versions.
