package com.bodysync.app

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class PermissionsRationaleActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = TextView(this).apply {
            text = "Body Sync nutzt Health Connect für Gesundheits- und Trainingsdaten wie Schritte, Kalorien, Herzfrequenz, HRV, Schlaf, Distanz, Geschwindigkeit, Leistung, Höhenmeter, Gewicht, SpO₂ und VO₂max. Die Daten werden für die Funktionen von Body Sync verarbeitet. Du kannst Berechtigungen jederzeit in Health Connect ändern."
            textSize = 18f
            setPadding(48, 48, 48, 48)
        }
        setContentView(text)
    }
}
