package com.bodysync.app

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.*
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import java.time.Instant

class HealthSyncWorker(appContext: Context, workerParams: WorkerParameters) : CoroutineWorker(appContext, workerParams) {
    override suspend fun doWork(): Result {
        return runCatching {
            if (HealthConnectManager.availability(applicationContext) != HealthConnectClient.SDK_AVAILABLE) return Result.success()
            val manager = HealthConnectManager.create(applicationContext)
            val granted = manager.grantedPermissions()
            if (granted.intersect(manager.permissions).isEmpty()) return Result.success()
            val snapshot = manager.readSnapshot(includeRoutes = false)
            val history = BodySyncDatabase(applicationContext)
            history.saveSnapshot(snapshot)
            history.close()
            applicationContext.getSharedPreferences("bodysync_sync", Context.MODE_PRIVATE)
                .edit()
                .putLong("last_background_sync", Instant.now().toEpochMilli())
                .apply()
            Result.success()
        }.getOrElse { error ->
            // Health Connect may temporarily rate-limit API access. Do not hammer it with immediate retries.
            Result.success()
        }
    }
}
